<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_POST["ULANGUAGE"] ;
$song_num = $_POST["SONG_NUM"];
$unit_title = $_POST["UNIT_TITLE"] ;
$unit_intro = $_POST["UNIT_INTRO"] ;
$unit_id = $_POST["UNIT_ID"] ;

$num_delete_song = $_POST["NUM_DELETE_SONG"] ;

$lid = strtoupper(substr($input_language, 0, 3));

// ----------------------------------------------------------- update the unit info --------------------------------
$query_updUnit = "UPDATE ML_Unit SET UNIT_TITLE='". addslashes($unit_title) ."', UNIT_INTRO='". addslashes($unit_intro) ."' WHERE UNIT_ID='". $unit_id . "' ;" ;
$result_existUnit = mysql_query($query_updUnit);	

echo $query_updUnit. "</br>";

// ----------------------------------------------------------- update the old song info ------------------------------
for ( $i = 1 ; $i <= 3 ; $i++)
{

	$sid = ( $_POST["SID". $i] != '' ) ? $_POST["SID". $i] : "" ;
	$song_title = ( $_POST["SONG_TITLE". $i] != '' ) ? $_POST["SONG_TITLE". $i] : "" ;
	
	echo "sid: ". $sid. " + song_title: ". $song_title. "</br>" ; 
	
	if ( $sid != '' && $song_title !='' )
	{
		$album = $_POST["ALBUM". $i];
		$artist = $_POST["ARTIST". $i];
		$song_overview = $_POST["OVERVIEW". $i];
		$lyrics = $_POST["LYRICS". $i];
		
		$query_updSong = "UPDATE ML_Song ". 
										   "SET SONG_TITLE='". addslashes($song_title) ."',  ALBUM='".  addslashes($album) ."', ARTIST='".  addslashes($artist) ."', SONG_OVERVIEW='". addslashes($song_overview) ."', LYRICS='".  addslashes($lyrics)."' ".
										   "WHERE SID='" . $sid  . "'; ";
		
		$result_updSong = mysql_query($query_updSong);
		
		echo $query_updSong. "</br>";
	}	
	
// ----------------------------------------------------------- insert the new song info ------------------------------	
	if ( $sid == '' && $song_title !='' )
	{
		$album = $_POST["ALBUM". $i];
		$artist = $_POST["ARTIST". $i];
		$song_overview = $_POST["OVERVIEW". $i];
		$lyrics = $_POST["LYRICS". $i];
		
		$query_songID = "SELECT MAX(SID) FROM ML_Song WHERE SID LIKE '". $unit_id ."_%'; ";
		$result_songID = mysql_query($query_songID);	
		$row = mysql_fetch_array($result_songID);
		$new_sid = sprintf($unit_id ."_%02d", (intval( substr($row[0], 7, 2) )+1));
		$query_addSong = "INSERT INTO ML_Song VALUES ". 
										   "('". addslashes($new_sid)."', '". addslashes($song_title) ."', '".  addslashes($album) ."', '".  addslashes($artist) ."', '". addslashes($song_overview)."', '".  addslashes($lyrics)."', ".
										   "'/', '-', '-', '-', '-'); ";
		
		$result_addSong = mysql_query($query_addSong);
		
		//echo "----------------> add new: ". $query_addSong. "</br>";
	}
}

// delete the old song from unit
for ( $i = 1 ; $i <= $song_num; $i++)
{
	$delete_sid = $_POST["DELETE_SONG". $i];
	
	if ( $delete_sid != '' ) 
	{
		$query_delSong = "DELETE FROM ML_Song WHERE SID='". $delete_sid ."'; " ;
		$result_delSong = mysql_query($query_delSong);		
		
		//echo $query_delSong."</br>";
	}
}

header('Location: _admMediaList.php?language='.$input_language); 

?>