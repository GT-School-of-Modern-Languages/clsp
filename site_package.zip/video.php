<?php
if($_COOKIE['main']!='true'){
        header("Location: index.php");
}
$input_language = $_REQUEST["ULANGUAGE"];
if ( $input_language == "" ){
header('Location:index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';
require ("config.php");
$link = connectDB();

if (!$link) {
echo "database connection fail!";
exit(-1);
}
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;

$query_hid = $_REQUEST["HID"];

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$len_song_title = mb_strlen($song_title,'UTF-8');
$s_song_title  = ($len_song_title > 30 ) ? substr($song_title, 0, 25) . "..." : $song_title ;

$target_dir = "listenings/".  strtoupper(substr($input_language, 0, 3))."/" ;
$target_file = mysql_result($result_song, 0, "FILE_NAME");
$chkEmSong = mysql_result($result_song, 0, "W_OTHER");

$media_av = ( mysql_result($result_song, 0, "W_AUDIO") == "y" ) ? "audio" : 
        ( mysql_result($result_song, 0, "W_VEDIO" == "y" ) ? "video" : "other" );

$strMediaSize = ( $media_av == "video" )? "height=\"250\" width=\"400\"" : "height=\"75\" width=\"600\"";
//$strMediaSize = ( $media_av == "video" )? $height=155 : $height=90;
?>
<html>
<body>
<center>
<?
if ($target_file != "/" ){
?>        
<video preload="load" controls="controls" <?=$strMediaSize?> >
<source src="./<?=$target_dir?><?=$target_file?>" >
</video></br></br>
<?
}else{
if ( $chkEmSong == "y" )
{
$query_selEmSong = "SELECT * FROM ML_SongEmbed WHERE SID='".$sid."' ;" ;
$result_selEmSong = mysql_query($query_selEmSong);
$emcode = mysql_result($result_selEmSong, 0, "EMCODE");
$emcodeSize = preg_replace('/width=\"\d{3}/','width="300',$emcode);
$emcodeSize = preg_replace('/height=\"\d{3}/','height="200',$emcodeSize);
echo "".$emcodeSize."</br>";
}
else
{
echo "<font color=\"#800000\" size=\"1\"> ( Currently, no media material uploaded in this song. )</font></br></br>";
}
}
?>
</center>
</body>
</html>
