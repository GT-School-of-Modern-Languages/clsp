<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>understandingTasks.php</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$input_language = $_REQUEST["ULANGUAGE"] ;
$lid = strtoupper(substr($input_language, 0, 3));
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;

//song info
$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;

// how many heading(s) under the song
$query_StartEnd = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='QU' ORDER BY H_ORDER;"; 
$result_StartEnd = mysql_query($query_StartEnd);
$num_StartEnd = mysql_num_rows($result_StartEnd);

$start_hid = 1;
$end_hid = 1;

$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;
if ( $num_StartEnd != 0){
	$start_hid = mysql_result($result_StartEnd, 0, "HID"); //the first heading id under the song
	$end_hid = mysql_result($result_StartEnd, ($num_StartEnd-1), "HID");  //the last heading id under the song
}

$query_hid = ( $_REQUEST["HID"] == "0" ) ? $start_hid : $_REQUEST["HID"];

$query_qu = "SELECT * FROM ML_ModuleQU, ML_Heading, ML_HeadingQU ".
						"WHERE ML_ModuleQU.QID = ML_HeadingQU.QID ".
						"AND ML_Heading.HID = ML_HeadingQU.HID ".
						"AND ML_ModuleQU.SID='".$sid."' ";

//number of tasks without heading
$query_nonHeading = $query_qu."AND ML_HeadingQU.HID ='1' ;";
$result_nonHeading= mysql_query($query_nonHeading);
$num_nonHeading = mysql_num_rows($result_nonHeading);

// tasks with heading									
$query_qu .=  "AND ML_Heading.HID='".$query_hid."' ORDER BY ML_ModuleQU.Q_ORDER;" ;			
$result_qu = mysql_query($query_qu);
$num_qu = mysql_num_rows($result_qu);

$heading = "";

$query_heading = "SELECT * FROM ML_Heading WHERE HID='".$query_hid."'; ";
$result_heading= mysql_query($query_heading);
$heading = ( $query_hid == 1 ) ? "Other Questions for Understanding" : mysql_result($result_heading, 0, "HEADING") ;
$current_order = mysql_result($result_heading, 0, "H_ORDER") ;

// if there are previous or next heading
$query_preHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='QU' AND H_ORDER < ".$current_order." ORDER BY H_ORDER DESC;" ;
$query_nextHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='QU' AND H_ORDER > ".$current_order." ORDER BY H_ORDER;"; 

$result_preHeading = mysql_query($query_preHeading);
$num_pre = mysql_num_rows($result_preHeading);
$result_nextHeading = mysql_query($query_nextHeading);
$num_next = mysql_num_rows($result_nextHeading);
$fontSize = ( $lid == "ARA" ) ? 13 : 10 ;
$strAlign = ( $lid == "ARA" ) ? "right" : "left" ;
$strDirRTL = ( $lid == "ARA" ) ? "direction: rtl" : "direction: ltr" ;
$strSize = ( $lid == "ARA" ) ? 4 : 2 ;
if($lid!="ARA"){
	if($lid=="CHI"){
		$fontSize=13;
		}
		}
include 'def/init.php';
?>
	<div <?=$strDirRTL?> align="center" >
    <table width="100%" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td align="center" valign="top" >
     <Form name="QUESTION_UNDERSTANDING" method="post"  id="TLIST">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="HID" type="hidden" value="<?=$query_hid?>">    
	 <input name="PWD" type="hidden" value="<?=$pwd?>">    	 
	 <input name="MODULE" type="hidden" value="QU">   	 
    <table width="100%" border="0" cellspacing="0" cellpadding="3">  
      <tr bgcolor="#<?=$color2?>">
        <td colspan="2" valign="bottom"><font color="#FFFFFF" size="4">&nbsp;&nbsp;<?=$heading?></font> 
        </td>
      </tr> 
      <tr bgcolor="#<?=$color2?>"> 
        <td colspan="2" align="right" valign="top">
	    <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr>
       		<td width="50%" align="left">
<?php
	if ( $num_qu >= 0 || ($num_qu == 1 && $num_nonHeading == 1 )  )
	{
		if ( $num_pre > 0 )
		{		
			$pre_hid = mysql_result($result_preHeading, 0, "HID") ;
?>
        	&nbsp;&nbsp; 
        	<input type="image" src="images/pre.png" width="10" height="10" title="Click PRINT below to print out your answer of this topic before go to previous topic" onclick="chgTopics('understandingTasks.php','QU','<?=$pre_hid ?>')"   style="cursor: pointer;">
        	<input type="submit" value="Previous Topic" title="Click PRINT below to print out your answer of this topic before go to previous topic" onclick="chgTopics('understandingTasks.php','QU','<?=$pre_hid ?>')"  
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: <?=$FONT_STYLE ?>;"> 
<?php
		}
		else
		{
			if ( $num_nonHeading != 0 && $query_hid == 1 && $end_hid != 1 )
			{
				$pre_hid = $end_hid;			
?>
        	&nbsp;&nbsp;
        	<input type="image" src="images/pre.png" width="10" height="10" title="Click PRINT below to print out your answer of this topic before go to previous topic" onclick="chgTopics('understandingTasks.php','QU','<?=$pre_hid ?>')"   style="cursor: pointer;">     
	        <input type="submit" value="Previous Topic" title="Click PRINT below to print out your answer of this topic before go to previous topic" onclick="chgTopics('understandingTasks.php','QU','<?=$pre_hid ?>')"  
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: <?=$FONT_STYLE ?>;">
<?php
			}
		}
?>
       		</td>
        	<td width="50%" align="right">
<?php
		if ( $num_next > 0 &&  $query_hid != 1 )
		{		
			$next_hid = mysql_result($result_nextHeading, 0, "HID") ;		
?>
	        <input type="submit" value="Next Topic" title="Click PRINT below to print out your answer of this topic before go to next topic" onclick="chgTopics('understandingTasks.php','QU','<?=$next_hid?>')"  
        	style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: <?=$FONT_STYLE ?>;">
        	<input type="image" src="images/next.png" width="10" height="10" title="Click PRINT below to print out your answer of this topic before go to next topic"onclick="chgTopics('understandingTasks.php','QU','<?=$next_hid?>')" style="cursor: pointer;">&nbsp;&nbsp;         	
<?php
		}
		else
		{
			if ( $num_nonHeading != 0 && $query_hid != 1 )
			{
				$next_hid = 1;	
?>
	        <input type="submit" value="Next Topic" title="Click PRINT below to print out your answer of this topic before go to next topic"
	        onclick="chgTopics('understandingTasks.php','QU','<?=$next_hid ?>')"  
        	style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: <?=$FONT_STYLE ?>;">
        	<input type="image" src="images/next.png" width="10" height="10" title="Click PRINT below to print out your answer of this topic before go to next topic"onclick="chgTopics('understandingTasks.php','QU','<?=$next_hid?>')" style="cursor: pointer;">&nbsp;&nbsp;
<?php
			}
			else
			{
				echo "</br>";
			}
		}
	}
	else
	{
		echo "</br>";
	}
?>
        	</td>
        </tr>
		</table>
        </td>
      </tr> 
<?php

$PagewithFeedback	 = 0;

for ( $i=0 ; $i < $num_qu ; $i++)
{
	$strAns = "";
	$strTask = "";
	$strFB = "";
	
	$qid = mysql_result($result_qu, $i, "QID") ;
	$q_content =str_replace("\n", "</br>", mysql_result($result_qu, $i, "Q_CONTENT")); 
	$q_types = mysql_result($result_qu, $i, "Q_TYPES") ;
	$q_option = str_replace("\n", "</br>", mysql_result($result_qu, $i, "Q_OPTION")); 	
	$hid = mysql_result($result_qu, $i, "HID");		
	$heading =  mysql_result($result_qu, $i, "HEADING"); 		

	$task_ans =  mysql_result($result_qu, $i, "ANS"); 		
	$preFeedback =  mysql_result($result_qu, $i, "FEEDBACK"); 			
	$PagewithFeedback	= ($preFeedback != "" )? $PagewithFeedback+1 : $PagewithFeedback;	
	
	$nextLine = array("\r\n", "\n\r", "\n");
	$task_feedback = str_replace($nextLine, "</br>", $preFeedback);	
	
	$task_optNum = substr_count(mysql_result($result_qu, $i, "Q_OPTION"),"\n") +1 ;
	$task_eachOpt = explode("\n", mysql_result($result_qu, $i, "Q_OPTION"));

	for ( $n = 0 ; $n < $task_optNum ; $n++)
	{	
		$strAnsChk = ( substr_count($task_ans, $n+1 ) == 0 ) ? "<font color='#FFFFFF'>_</font>" : "x" ; 	
		$strFB .= "<font color='#<?=$color2?>'>".$strAnsChk."</font>&nbsp;".$task_eachOpt[$n]."</br>"; 	
	}			
	$strFB = ( $q_types == 6 ) ? $task_feedback : $strFB."</br>".$task_feedback ;

	switch($q_types)	
	{
		case "1":		//Open-Ended Question		
			$strAns = "<textarea name=\"ANS".$qid."\"  rows=\"3\" cols=\"75\" style=\"color: #000000; font-size: ".$fontSize."pt; font-family: ".$FONT_STYLE."; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;\"></textarea> ";				
			$strTask = $q_content."</font></br></br>".$strAns;			
			break;
		case "2": 	//Blank Question
			$uline_count = substr_count($q_content, "_");
			$strTask = $q_content . "</br>";
			for ( $c=0 ; $c < $uline_count ; $c++){
				$strAns = "&nbsp;<input id=\"ANS".$qid."-".$c."\" name=\"ANS".$qid."-".$c."\" type=\"text\"style=\"color: #000000; font-size: ".$fontSize."pt; font-family: ".$FONT_STYLE."; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;\" size=\"15\" maxlength=\"20\" onblur=\"setBlankRes(".$qid.",".$uline_count.")\">&nbsp;";
				$strTask = preg_replace("/_/",  $strAns, $strTask,1);
			}	
			break;
		case "3":		//Multi-Choice Question
			$mc_count = substr_count($q_option, "</br>") +1 ;
			$strTask = "";
			$ifChk = ""; 
			for ( $c=0 ; $c < $mc_count ; $c++){
				$strAns = "<input id=\"CHK".$qid."_".($c+1)."\" name=\"CHK".$qid."\"  type=\"checkbox\" value=\"".($c+1)."\" ".$ifChk." onclick=\"setChkboxRes(".$qid.", ".$task_optNum.")\">";
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $q_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}	
			$strTask = $q_content . "</br></br>".$strTask;		
			break;
		case "4":		//Multiple Answer Question
			$sc_count = substr_count($q_option, "</br>") +1 ;
			$strTask = "";
			$ifChk = ""; 
			for ( $c=0 ; $c < $sc_count ; $c++){
				$strAns = "<input id=\"CHK".$qid."_".($c+1)."\" name=\"CHK".$qid."\" type=\"radio\" value=\"".($c+1)."\" ".$ifChk." onclick=\"setRadioRes(".$qid.", ".($c+1).")\">";					
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $q_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}
			$strTask = $q_content . "</br></br>".$strTask;	
			break;
		case "5":		//Plain Text
			$strTask = $q_content."</br></br>"; 	
			break;		
			
		case "6": 	//Fill-in-Blank Question
			$uline_count = substr_count($q_content, "_");
			$strTask = $q_content . "";
			for ( $c=0 ; $c < $uline_count ; $c++){
				$strAns = "&nbsp;<input id=\"ANS".$qid."-".$c."\" name=\"ANS".$qid."-".$c."\" type=\"text\"style=\"color: #000000; font-size: ".$fontSize."pt; font-family: optima; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;\" size=\"15\" maxlength=\"20\" onblur=\"setBlankRes(".$qid.",".$uline_count.")\">&nbsp;";
				$strTask = preg_replace("/_/",  $strAns, $strTask,1)."</br>";
			}	
			break;	
			
		case "7":		//Multi-Choice Question
			$mc_count = substr_count($q_option, "</br>") +1 ;
			$strTask = "";
			for ( $c=0 ; $c < $mc_count ; $c++){
				$strAns = "<input id=\"CHK".$qid."_".($c+1)."\" name=\"CHK".$qid."\" type=\"checkbox\" value=\"".($c+1)."\" onclick=\"setChkboxRes(".$qid.", ".$task_optNum.")\">";
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $q_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}	
			$strTask = $q_content . "</br></br>".$strTask;		
			break;
			
		case "8":		//Multiple Answer Question
			$sc_count = substr_count($q_option, "</br>") +1 ;
			$strTask = "";
			for ( $c=0 ; $c < $sc_count ; $c++){
				$strAns = "<input id=\"CHK".$qid."_".($c+1)."\" name=\"CHK".$qid."\"  type=\"radio\" value=\"".($c+1)."\" onclick=\"setRadioRes(".$qid.", ".($c+1).")\">";	
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $q_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}
			$strTask = $q_content . "</br></br>".$strTask;	
			break;							
	}	
?>
    <tr >
    <td colspan="3" valign="top">
        <hr noshade color="#<?=$color2?>" size="1"><br></font>
    </td>
    </tr>  
	<tr>        
    <td colspan="2" valign="top" align="center">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr  id="Q<?=$qid?>">
       	<td width="40" valign="top" align="right">&nbsp;&nbsp;</td>
       	<td valign="top"><font size="<?=$strArbSize?>"><?=$strTask?></font>
<?php
if ( $q_types != 1){
?>       	
       	<input id="ANS<?=$qid?>" name="ANS<?=$qid?>" type="hidden" value="">
<?
}
?>      
       	</td>
       	<td width="40" valign="top" align="right">&nbsp;&nbsp;</td>       	
        </tr>
		</table>
	</td>
	</tr>
<?php
}
?>
        </td>
      </tr>   
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
      <tr>
        <td colspan="2" align="right" valign="top">  
<?
if ( 	$PagewithFeedback	 != 0 ){
?>
			<input type="submit" value="CHECK ANSWERS" onclick="openFB()" 
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: <?=$FONT_STYLE ?>;"> 
<?
}
?>    	    
    	    &nbsp;&nbsp;      
<?
if ($PagewithFeedback ==0){
?>  
			<input type="submit" value="PRINT or SAVE" onclick="openPrint()" 
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: <?=$FONT_STYLE ?>;">    	    
<?
}
?>  
  	    &nbsp;</br></br>     
        </td>
      </tr>    
 </table> 
    </td>
  </tr> 
</table></br></br>
</Form>
</div>
</body>
</html>
