<?php

require ("config.php");
$link = connectDB();
if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$color1 = $_POST[color1];
$color2= $_POST[color2];
$color3 = $_POST[color3];
$color4= $_POST[color4];

if ($color1!=""){
	$updateString="Color Updated!";
	$insertQuery="INSERT INTO ML_Color(color1, color2, color3, color4, id) VALUES ('$color1','$color2', '$color3', '$color4' ,1) ON DUPLICATE KEY UPDATE color1=VALUES(color1), color2=VALUES(color2), color3=VALUES(color3), color4=VALUES(color4)";
	mysql_query($insertQuery);
}

$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
$color4=mysql_result($result_color, 0, "color4");

$query = "select LANGUAGE from ML_Lang order by LANGUAGE;" ;
$result = mysql_query($query);



?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Critical Languages Song Project</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    	</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
     <tr>
        <td><div class="leftMenu"><a href="_admMain.php"><span class="menu_head">Admin Main Page</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="index.php"><span class="menu_head">Students Main Page</span></a></div></td>
      </tr>   
       <tr>
        <td><div class="leftMenu"><a href="_admFront.php"><span class="menu_head">Modify Front Page</span></a></div></td>
      </tr>                  
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Change Theme</span></a></div></td>
      </tr>
      <tr>
            <td><div class="leftMenu"><a href="_admBackupFiles.php"><span class="menu_head">Back Up UI/DB</span></a></div></td>
          </tr>            
    </table>
    </td>
    <td align="center" valign="top"><p>&nbsp;</p><p>&nbsp;</p>
        <table width="650" border="0" cellspacing="3" cellpadding="5">

<script type="text/javascript" src="jscolor/jscolor.js"></script>
<? echo $updateString; ?>
<br>
<tr>
<td>First Color</td><td>Second Color</td><td>Third Color</td><td>Fourth Color</td>
<form action="" method="post">
<tr><td>

  <input class="color" name="color1" value="<?=$color1?>">
</td><td>
<input class="color" name="color2" value="<?=$color2?>">
</td><td>
<input class="color" name="color3" value="<?=$color3?>">
</td><td>
<input class="color" name="color4" value="<?=$color4?>">
</td>
</tr>
<tr>
<td>
<input type="submit" value="Change" />
</td>
</tr>
</form>
<br>

    </table>
    </td>
  </tr>
  <tr height="25" bgcolor="#<?=$color1?>">
    <td align="center" valign="middle">&nbsp;</td>
    <td align="right" valign="middle" >
    <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
    </table>
    </td>
  </tr> 
</table>
</body>
</html>