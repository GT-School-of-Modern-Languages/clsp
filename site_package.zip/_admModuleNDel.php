<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"];
$sid = $_REQUEST["SONG_ID"] ;
$nid = $_REQUEST["NID"] ;
$phrase = $_REQUEST["PHRASE"] ;

$query_cn = "SELECT * FROM ML_ModuleCN WHERE  NID='".$nid."';";
$result_cn = mysql_query($query_cn);
$atta_img = mysql_result($result_cn, 0, "ATTA_IMG") ;
$atta_doc = mysql_result($result_cn, 0, "ATTA_DOC") ;

unlink("attachment/".  strtoupper(substr($input_language, 0, 3))."/".$atta_img);
unlink("attachment/".  strtoupper(substr($input_language, 0, 3))."/".$atta_doc);

$query_delCN = "DELETE FROM ML_ModuleCN WHERE  NID='".$nid."';";
$result_delCN = mysql_query($query_delCN);

header('Location: _admEditModule-N.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
?>