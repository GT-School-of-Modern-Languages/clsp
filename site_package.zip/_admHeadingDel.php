<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"];
$sid = $_REQUEST["SONG_ID"] ;
$hid = $_REQUEST["HID"] ;
$module = $_REQUEST["MODULE"];
$submitLocation = "";

switch($module)	
{
	case "QU":		
		$submitLocation = "_admEditHeadingQ"; 
		break;
	case "LT": 
		$submitLocation = "_admEditHeadingL"; 
		break;
	case "GE":	
		$submitLocation = "_admEditHeadingG"; 
		break;
	case "DW":
		$submitLocation = "_admEditHeadingW"; 
		break;
}	
// ----------------------------------------------------------- update questions to none heading------------------------------
$query_updHeading = "UPDATE ML_Heading".$module." SET HID='1' WHERE HID='".$hid."' ;";
$result_updHeading = mysql_query($query_updHeading);


// ----------------------------------------------------------- delete the info ------------------------------

$query_delHeading = "DELETE FROM ML_Heading WHERE HID='".$hid."' ;";
$result_delHeading = mysql_query($query_delHeading);

echo $query_delHeading;

header('Location:'.$submitLocation.'.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
?>