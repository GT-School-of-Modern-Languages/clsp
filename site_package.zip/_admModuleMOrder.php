<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"];
$hid = $_REQUEST["HEADINGID"] ;
$current_hid = $_REQUEST["HID"] ;
$sid = $_REQUEST["SONG_ID"] ;
$question_id = $_REQUEST["QID"] ;
$module = $_REQUEST["MODULE"];
$func = $_REQUEST["FUNC"];

$submitLocation = "";

switch($module)	
{
	case "QU":		

		$submitLocation = "_admEditModule-Q"; 
		$column_name = "Q_ORDER";
		$column_requested = "QID";
		break;
	case "LT": 
		$submitLocation = "_admEditModule-L"; 
		$column_name = "L_ORDER";
		$column_requested = "LID";
		break;
	case "GE":	
		$submitLocation = "_admEditModule-G"; 
		$column_name = "G_ORDER";
		$column_requested = "GID";
		break;
	case "DW":
		$submitLocation = "_admEditModule-W"; 
		$column_name = "W_ORDER";
		$column_requested = "WID";
		break;
}	


// ----------------------------------------------------------- update order info ------------------------------

//select the order of the target question
$query_selOrder = "SELECT ".$column_name." FROM ML_Module".$module." WHERE ".$column_requested."='".$question_id."' ;";
$result_selOrder = mysql_query($query_selOrder);
$question_order = mysql_result($result_selOrder, 0, "".$column_name.""); 

$query_exchanged_Order = "SELECT * FROM ML_Module".$module.", ML_Heading, ML_Heading".$module." ".
						"WHERE ML_Module".$module.".".$column_requested." = ML_Heading".$module.".".$column_requested." ".
						"AND ML_Heading.HID = ML_Heading".$module.".HID ".
						"AND ML_Module".$module.".SID='".$sid."' " ;		
						
if ($func == "UP" ){
	$query_exchanged_Order .= "AND ML_Heading".$module.".HID ='".$hid."' AND ".$column_name." < '".$question_order."' ORDER BY ".$column_name." DESC;";
} else{
	$query_exchanged_Order .= "AND ML_Heading".$module.".HID ='".$hid."' AND ".$column_name." > '".$question_order."' ORDER BY ".$column_name.";";
}

echo $query_exchanged_Order;

$result_exchanged_Order= mysql_query($query_exchanged_Order);
$exchanged_order = mysql_result($result_exchanged_Order, 0, $column_name) or die(mysql_error()); 
$exchanged_question_id = mysql_result($result_exchanged_Order, 0, $column_requested) or die(mysql_error()); 						

$swap_tmpOrder = $question_order ;

$query_updOrder_target = "UPDATE ML_Module".$module." SET ".$column_name."='".$exchanged_order."' WHERE ".$column_requested."='".$question_id."' ;";
$result_updOrder_target = mysql_query($query_updOrder_target) or die(mysql_error()); 

$query_updOrder_exchanged = "UPDATE ML_Module".$module." SET ".$column_name."='".$swap_tmpOrder."' WHERE ".$column_requested."='".$exchanged_question_id."' ;";
$result_updOrder_exchanged = mysql_query($query_updOrder_exchanged) or die(mysql_error()); 

header('Location:'.$submitLocation.'.php?ULANGUAGE='.$input_language.'&SONG_ID='.$sid.'&HID='.$current_hid.'&#Q'.$question_id); 
?>