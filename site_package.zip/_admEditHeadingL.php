<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<?php

$sid = $_REQUEST["SONG_ID"] ;

$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_song =  "SELECT * FROM ML_Song WHERE  SID='".$sid."';";
$result_song = mysql_query($query_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE");	

$query_pwd =  "SELECT * FROM ML_LTPWD WHERE  SID='".$sid."';";
$result_pwd = mysql_query($query_pwd);
$pwd = mysql_result($result_pwd, 0, "PWD");	

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>"></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>"></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>         
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_L?></span></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr>     
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr> 
      <tr> 
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>     
    </table>		    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">        
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a>>> Edit Headings/Directions for Listening Tasks</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr bgcolor="#FFFFFF">
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
	 <tr bgcolor="#FFFFFF">
        <td colspan="2" align="center" valign="top">
        <div dir="ltr">
        <Form name="LT_PWD" method="post" action="_admLTpwdUpd.php">        
        <font color="#<?=$color2?>" size="3">The password for students to enter other sections after finishing the listening tasks. The default password is blank which will bypass the login feature in the notes section. </br></br>
        New Password: </font>
		<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">
    <input name="CID" type="hidden" value="<?=$cid?>">        
		<input name="SID" type="hidden" value="<?=$sid?>">        
        <input name="PWD" type="text" value="<?=$pwd?>" size="20" maxlength="20" dir="<?=$strInputRTL?>"
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" >
        <input type="submit" value="UPDATE" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">&nbsp;
        <font color="#383838" size="1"> current password: <?=$pwd?> </font>
        </Form>
      	</td>
      </tr>      	
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
	 </tr>  	 
      <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Song Title: </font></th>
        <td width="75%"><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>"
        style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr> 	 
     <Form name="HEADING" method="post" onsubmit="return chkHeading(this)">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">
     <input name="CID" type="hidden" value="<?=$cid?>">
     <input name="SONG_ID" type="hidden" value="<?=$sid?>">
     <input name="MODULE" type="hidden" value="LT">            
     <input name="HID" type="hidden" value="">        
     <input name="TARGET_HID" type="hidden" value="">                  
     <input name="MAIN_HID" type="hidden" value="">                
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Heading/Direction:</font></th>
        <td width="75%">
        <input name="HEADING" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="50" maxlength="100">
      	</td>
      </tr> 
      <tr> 
        <td colspan="2" align="right" valign="top"></br>
        
        <input type="submit" value="SUBMIT NEW HEADING" onclick="subAddHeading('_admHeadingAdd.php','')" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;</br></br>
        <input type="button" value="Skip creating new heading, and go to question page" onclick="javascript: window.location='_admEditModule-L.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>&HID='" style="background: #<?=$color3?>; border-width: 1px; border-style: solid; border-color:#254117; color: #254117; font-size: 8 pt; font-family: Verdana; cursor: pointer; "></br>     
        </td>
      </tr> 
    </form>
     <Form name="HEADINGLIST" method="post" >
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">
     <input name="CID" type="hidden" value="<?=$cid?>">        
     <input name="SONG_ID" type="hidden" value="<?=$sid?>">
     <input name="MODULE" type="hidden" value="LT">            
     <input name="HID" type="hidden" value="">   
     <input name="TARGET_HID" type="hidden" value="">                  
     <input name="MAIN_HID" type="hidden" value="">        
    <tr >
    <td colspan="2" valign="top" >
        <hr noshade color="#<?=$color2?>" size="1">
        <font size="2" color="#<?=$color2?>">Current Headings/Directions: </font>
        </td></tr>  
	<tr>   
    <td colspan="2" valign="top" align="center">	
<?php
$query_lt = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='LT' ORDER BY H_ORDER;";

$result_lt = mysql_query($query_lt);
$num_lt = mysql_num_rows($result_lt);

for ( $i=0 ; $i < $num_lt ; $i++)
{
	$hid = mysql_result($result_lt, $i, "HID") ;
	$heading = mysql_result($result_lt, $i, "HEADING") ;
	$order = mysql_result($result_lt, $i, "H_ORDER") ;

	$query_nextHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='LT' AND H_ORDER > '".$order."' ORDER BY H_ORDER;";
	$result_nextHeading= mysql_query($query_nextHeading);
	$num_nextHeading = mysql_num_rows($result_nextHeading);
	$next_hid = ( $num_nextHeading != 0 ) ? mysql_result($result_nextHeading, 0, "HID") : "";
	
	$query_preHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='LT' AND H_ORDER < '".$order."' ORDER BY H_ORDER DESC;";
	$result_preHeading= mysql_query($query_preHeading);
	$num_preHeading = mysql_num_rows($result_preHeading);				
	$pre_hid = ( $num_preHeading != 0 ) ? mysql_result($result_preHeading, 0, "HID") : "";	

	$strUpArrow = ( $num_preHeading != 0 ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;
	$strDnArrow = ( $num_nextHeading !== 0  ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;

	$strUpFunc = ( $num_preHeading != 0 ) ? "onclick=\"moveHeading('_admModuleMHeading.php','".$hid."','".$pre_hid."')\" " : "onclick=\"return false;\" " ;
	$strDnFunc = ( $num_nextHeading != 0 ) ? "onclick=\"moveHeading('_admModuleMHeading.php','".$hid."','".$next_hid."')\" " : "onclick=\"return false;\" " ;

	if ( $heading != "" )
	{ 
?>
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr>
       		<td width="10%" align="right" valign="top">
	        <input type="submit" value="up &and; " <?=$strUpFunc?> style="background: #<?=$color3?>; border-width: 0px; <?=$strUpArrow?> font-size: 8pt; font-family: Verdana;"></br>        	
 	        <input type="submit" value="down &or; "<?=$strDnFunc?> style="background: #<?=$color3?>; border-width: 0px; <?=$strDnArrow?> font-size: 8pt; font-family: Verdana;">    
 	        </br></br>
       		</td>       	
       		<td width="60%" valign="top">
 	       <input type="submit" value="<?=$heading?>" onclick="subEditHeading('_admEditModule-L.php','<?=$hid?>')" 
	        style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #FF8C00; font-size: 9pt; font-family: Verdana;">       		
       		</td>
       		<td width="30%"  align="<?=$strTHAlign?>"><font size="2">
 	       <input type="submit" value="[+]" title="edit current heading" onclick="subEditHeading('_admEditHeadingLUpd.php','<?=$hid?>')" 
	        style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
  	      <input type="submit" value="[-]" title="delet current heading" onclick="subEditHeading('_admHeadingDel.php','<?=$hid?>')"  
    	    style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">        	    
       		</td>       		
       	</tr>
		</table>
<?php
	}
}
?>
        </td>
      </tr>
	  </Form>      
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table></br></br>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
