<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>notesLines.php</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php
if($_COOKIE['main']!='true'){
        header("Location: index.php");
}
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
// password check

$query_pwd =  "SELECT * FROM ML_LTPWD WHERE  SID='".$sid."';";
$result_pwd = mysql_query($query_pwd);
$pwd2 = mysql_result($result_pwd, 0, "PWD");	

if($_COOKIE['password']!=$pwd2){
	header("Location: pwd.php?ULANGUAGE=".$input_language."&SID=".$sid."&PWD=&PAGE=N"); 
}
/*
if ( $pwd == "" ) {
	header("Location: pwd.php?ULANGUAGE=".$input_language."&SID=".$sid."&PWD=&PAGE=N"); 
}
*/

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$lyrics = str_replace( "'", "&#39;", trim(mysql_result($result_song, 0, "LYRICS")));	
$lyricswTip = $lyrics;

$patterns = array();
$patterns[0] = '/\'/';
$patterns[1] = '/\"/';				
$patterns[2] = '/[\n\r]{1,2}/';		
$replacements = array();
$replacements[0] = '&#39;';
$replacements[1] = '&#34;';		
$replacements[2] = '</br>';				

?>
  <div align="center">
      <Form name="CULTURE_NOTE" id="CULTURE_NOTE" method="post">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="PWD" type="hidden" value="<?=$pwd?>">    	 
	 <input name="MODULE" type="hidden" value="CN">   	 
    <table width="850" border="0" cellspacing="0" cellpadding="3">
	  <tr>
    <td align="center" valign="top" >
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php
$query_cn = "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."'; ";
$result_cn = mysql_query($query_cn);
$num_rows = mysql_num_rows($result_cn);

$file_link = "";
$atta_file_desc = "";

for ( $i=0 ; $i < $num_rows ; $i++)
{
	$phrase = mysql_result($result_cn, $i, "PHRASE") ;		
	$wholeline = mysql_result($result_cn, $i, "WHOLELINE") ;		
	$nid =  mysql_result($result_cn, $i, "NID") ;		
	$chk_link = mysql_result($result_cn, $i, "CHK_LINK") ;	
	$chk_doc = mysql_result($result_cn, $i, "CHK_DOC") ;	
	$chk_img = mysql_result($result_cn, $i, "CHK_IMG") ;	
	$chk_cont = mysql_result($result_cn, $i, "CHK_CONT") ;	
	$link = mysql_result($result_cn, $i, "LINK") ;	
	$content = trim(mysql_result($result_cn, $i, "CONTENT") ) ;	
				
	$content = preg_replace($patterns, $replacements, $content);
		
	$atta_img = mysql_result($result_cn, $i, "ATTA_IMG") ;	
	$img_size = mysql_result($result_cn, $i, "IMG_SIZE") ;	
		$img_size = ( round($img_size/(1024*1024),2) < 1 ) ? round($img_size/(1024),2). " KB" : round($img_size/(1024*1024),2). "MB";
	$img_mime = mysql_result($result_cn, $i, "IMG_MIME") ;	
	$atta_doc = mysql_result($result_cn, $i, "ATTA_DOC") ;	
	$doc_size = mysql_result($result_cn, $i, "DOC_SIZE") ;	
		$doc_size = ( round($doc_size/(1024*1024),2) < 1 ) ? round($doc_size/(1024),2). " KB" : round($doc_size/(1024*1024),2). "MB";
	$doc_mime = mysql_result($result_cn, $i, "DOC_MIME") ;	
	
	if ($atta_img != "/" || $atta_doc != "/" )
	{ 
		if ( $atta_img != "/" )
		{
			$file_link_img = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img;		
			$atta_file_desc .= "<a href='".$file_link_img."' target=\"_blank\"><b>".$atta_img."</b></a><font size='1'>&nbsp;[".$img_mime.", ". $img_size ."] </font></br>";				
		}
		if ( $atta_doc != "/" )
		{
			$file_link_doc = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc;		
			$atta_file_desc .= "<a href='".$file_link_doc."' target=\"_blank\"><b>".$atta_doc."</b></a><font size='1'>&nbsp;[".$doc_mime.", ". $doc_size ."] </font></br>";				
		}		
	}	
	
	$content_link = ( $chk_link == "Y" ) ? "</br></br> Click for more information.</br></br>" : "";
	$content_document = ( $chk_doc == "Y" ) ? "</br></br>Click to download related document. </br></br>" : "";
	$content_cont = ( $chk_cont == "Y" ) ? $content." </br></br>" : "";

	if ($chk_img == "Y")		
	{
			list($width, $height) = getimagesize($file_link_img);

			$newwidth =($width > 400 ) ? 400 : $width ;
			$newheight = ($width > 400 ) ? (($height/$width)*$newwidth) : $height ;		
			if ( $newheight > 400 ){
				$newheight = 400; 
				$newwidth = ($width/$height) * $newheight ;				
			}				
	}		
	
	$content_img = ( $chk_img == "Y" ) ? "<img src=\'".$file_link_img."\' width=\'".$newwidth."\' height=\'".$newheight."\'>" : "" ;	

	$tip_link = ( $chk_link == "Y" || $chk_doc == "Y" ) ? ( ( $chk_doc == "Y") ? $file_link_doc : $link ): "javascript:void(0);" ;
	$tip_width = ($atta_img != "/" ) ? ( ($width < 400 ) ? $width : $newwidth ) : ( (strlen($content) < 45 ) ? "0" : "400" );
	$tip_content = "'" . $content_document . $content_cont . $content_img . $content_link. "',PADDING, 10, WIDTH,".$tip_width ;  
	$strTips = "href=\"".$tip_link."\" onMouseOver=\"Tip(".$tip_content.");\" onMouseOut=\"UnTip();\" ";
	
	$lyricswTip = ( $phrase != "" ) ? preg_replace( '/'.$phrase.'/', "<font style='background-color: #FFFFFF'><b><a ".$strTips." target='_blank '>".$phrase."</a></b></font>", $lyricswTip, 1 ) : $lyricswTip;		
}

$numLine = substr_count ($lyrics,"\n") ;
$sublyrics_tip = explode("\n", $lyricswTip );	
$sublyrics = explode("\n", $lyrics );	

for ($line=0; $line <= $numLine; $line++)
{
	$trim_lyrics = trim($sublyrics[$line]);
	$query_line = ($trim_lyrics == "" ) ? "" : "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' AND WHOLELINE='". $trim_lyrics."' ";	
	$result_line = ($trim_lyrics == "" ) ? "" : mysql_query($query_line);
	$chk_wline = ($trim_lyrics == "" ) ? "0" : mysql_num_rows($result_line);
	
//	echo "-->". $chk_wline . "</br>";
	
	$nid_line = "";
	$strTips_line = "";
	
	if ( $chk_wline != 0 ) 
	{
		
		$nid_line = mysql_result($result_line, 0, "NID");		
		$link_line = mysql_result($result_line, 0, "LINK") ;	
		$content_line = addslashes(trim(mysql_result($result_line, 0, "CONTENT") ) );		
		$content_line = preg_replace($patterns, $replacements, $content_line);
	
		$atta_img_line = mysql_result($result_line, 0, "ATTA_IMG") ;	
		$atta_doc_line = mysql_result($result_line, 0, "ATTA_DOC") ;	
		$file_link_img_line = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img_line;		
		$file_link_doc_line = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc_line;	

		$content_link_line = ( $link_line != "http://" ) ? " </br></br> Click for more information. </br></br>" : ""; 
		$content_document_line = ( $atta_doc_line != "/" ) ? "Click to download related document. </br></br>" : "";
		$content_cont_line = ( ! empty($content_line) ) ? $content_line." </br></br>" : "";

		if ($atta_img_line != "/")		
		{
			list($width, $height) = getimagesize($file_link_img_line);
			$newwidth =($width > 400 ) ? 400 : $width ;
			$newheight = ($width > 400 ) ? (($height/$width)*$newwidth) : $height ;		
		}		
	
		$content_img_line = ( $atta_img_line != "/" ) ? "<img src=\'".$file_link_img_line."\' width=\'".$newwidth."\' height=\'".$newheight."\'>" : "" ;	

		$tip_link_line = ( $link_line != "http://" || $atta_doc_line != "/" ) ? ( ( $atta_doc_line != "/") ? $file_link_doc_line : $link_line ): "javascript:void(0);" ;
		$tip_width_line = ($atta_img_line != "/" ) ? ( ($width < 400 ) ? $width : $newwidth ) : ( (strlen($content_line) < 45 ) ? "0" : "400" );
		$tip_content_line = "'" . $content_document_line . $content_cont_line . $content_img_line . $content_link_line. "',PADDING, 10, WIDTH,".$tip_width_line ;  
		$strTips_line = "href=\"".$tip_link_line."\" onMouseOver=\"Tip(".$tip_content_line.");\" onMouseOut=\"UnTip();\" ";
	}	
	
	$strBtn_withLine = "<font style='background-color: #FFFFFF'>&nbsp; <a ".$strTips_line." target='_blank '> &diams;</a>&nbsp;</font>&nbsp;";
			        	   
	$strBtn_noLine = "";

	$strBtn_Line = ( $chk_wline != 0 ) ? $strBtn_withLine : ( $trim_lyrics == ""  ? "&nbsp;" : $strBtn_noLine) ;
	
	if ( $input_language != "Arabic" ){
	
?>
        			<tr>
       				 <td width="80" align="right" ><font size="3"><?=$strBtn_Line?>&nbsp;</font></td>
			        <td><font color="#000000" size="2"><?=$sublyrics_tip[$line]?></font></td>
			        </tr>
<?
	}else{
?>
        			<tr>
			        <td  align="right"><font color="#000000" size="5"><?=$sublyrics_tip[$line]?></font></td>
       				 <td width="80" align="left" ><font size="3"><?=$strBtn_Line?>&nbsp;</font></td>
			        </tr>
<?	
	}
}
?>
 		       </table>   
    </td>
    </tr>
    <tr>
      <td align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3" width="800"></td>
    </tr>  
    <tr>
    <td align="right">    
    	    &nbsp;&nbsp;        
			<input type="submit" value="PRINT NOTES" onclick="openNotes()" 
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: <?=$FONT_STYLE ?>;">    	    
    	    &nbsp;</br></br>     
 		       
    </td>
    </tr>
   
 </table> 
</Form>
</div>
</body>
</html>
