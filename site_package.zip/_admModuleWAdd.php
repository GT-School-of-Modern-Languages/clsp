<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$hid = ( $_REQUEST["HID"] == "0" || $_REQUEST["HID"] == "" ) ? "1" : $_REQUEST["HID"];
$w_content = trim($_REQUEST["W_CONTENT"]);

$query_num = "SELECT * FROM ML_ModuleDW WHERE SID='".$sid."'; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

$query_addDW = "INSERT INTO ML_ModuleDW VALUES('".$sid."','','".addslashes($w_content)."','".($num_question+1)."'); " ;
$result_addDW = mysql_query($query_addDW);

$query_selDW = "SELECT * FROM ML_ModuleDW WHERE SID='".$sid."' AND W_CONTENT='".addslashes($w_content)."' ;" ;
$result_selDW = mysql_query($query_selDW);
$wid = mysql_result($result_selDW, 0, "WID");

$query_addheadingDW = "INSERT INTO ML_HeadingDW VALUES('".$hid."','".$wid."');" ;
$result_addheadingDW = mysql_query($query_addheadingDW);

echo $query_addDW."</br>";
echo $query_selDW."</br>";
echo $query_addheadingDW."</br>";

header('Location: _admEditModule-W.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='.$hid.'&#Q'.$wid); 
?>