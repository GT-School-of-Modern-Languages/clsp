<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$status = $_REQUEST["STATUS"] ;
$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$s_content = trim($_REQUEST["S_CONTENT"]);

// ----------------------------------------------------------- update the ls info ------------------------------

if ( $s_content != "" ) {
	if ( $status == "0" ) 	// 0 - S, 1- SUpd
	{

		$query_ls =  "SELECT * FROM ML_ModuleLS WHERE  SID='".$sid."';";
		$result_ls = mysql_query($query_ls);
		$old_s_content = mysql_result($result_ls, 0, "S_CONTENT") ;	
		$s_content = $old_s_content . "\n" . $s_content;	
	
	}
	
	$query_updLS = "UPDATE ML_ModuleLS SET S_CONTENT='".addslashes($s_content)."' WHERE SID='".$sid."' ;";
	$result_updLS= mysql_query($query_updLS);
	
	echo $query_updLS;

}
else
{
	if ( $status == "1" ) 	// 0 - S, 1- SUpd
	{	
		$query_delSL = "DELETE FROM ML_ModuleLS WHERE SID='".$sid."';";
		$result_delSL = mysql_query($query_delSL);
	}
	echo $query_delSL;	
}

header('Location: _admEditModule-S.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 	

?>