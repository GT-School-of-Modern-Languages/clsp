<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$file_name = $_REQUEST["FILE_NAME"] ;
$sid = $_REQUEST["SONG_ID"] ;


// ----------------------------------------------------------- update the song info ------------------------------

$query_updSong = "UPDATE ML_Song". 
								   " SET FILE_NAME='/', W_PRAAT='-', W_AUDIO='-', W_VEDIO='-', W_OTHER='-'".
								   " WHERE SID='" . $sid  . "'; ";
echo "query_updSong: ".$query_updSong ."</br>";
$result_updSong = mysql_query($query_updSong);

// ----------------------------------------------------------- delete the song detail ------------------------------
$query_delSongDetail = "DELETE FROM ML_SongDetail WHERE SID='".$sid."';" ;
echo "query_delSongDetail: ".$query_delSongDetail."</br>";
$result_delSongDetail = mysql_query($query_delSongDetail);

unlink("listenings/".  strtoupper(strtoupper(substr($input_language, 0, 3)))."/".$file_name);

header('Location: _admMediaList.php?language='.$input_language); 
?>