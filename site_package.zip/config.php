<?php

if (ereg("config.php", $_SERVER["PHP_SELF"])){ 
		exit();
}

  /*Database Setup*/

	// SERVER
define ("MYSQL_CONNECT_HOST", "ENTER_HOST");
	
	//USER
define ("MYSQL_CONNECT_USER", "ENTER_USER");
	
	//PASSWD
define ("MYSQL_CONNECT_PASS", "ENTER_PASS");
	
	//DATABASE
define ("MYSQL_DB_NAME", "ENTER_DATABASE");

	// connect to MySQL
function connectDB() {
	$db = mysql_connect(MYSQL_CONNECT_HOST, MYSQL_CONNECT_USER, MYSQL_CONNECT_PASS)
		or die ("cannot connect to MySQL server ");
		$query_utf8 = "SET COLLATION_SERVER='utf8_unicode_ci';";
		mysql_query($query_utf8);
		$query_utf8 = "SET COLLATION_CONNECTION='utf8_unicode_ci';";
		mysql_query($query_utf8);
		$query_utf8 =  "SET COLLATION_DATABASE='utf8_unicode_ci';";	
		mysql_query($query_utf8);
		$query_utf8 =  "SET CHARACTER_SET_RESULTS = 'utf8', CHARACTER_SET_CLIENT = 'utf8', CHARACTER_SET_CONNECTION = 'utf8', CHARACTER_SET_DATABASE = 'utf8', CHARACTER_SET_SERVER = 'utf8'";
		mysql_query($query_utf8);
		return mysql_select_db (MYSQL_DB_NAME, $db)
		or die ("cannot connect to Database " . MYSQL_DB_NAME);
}

  /* FTP Setup */

  // FTP SERVER
  define("SFTP_CONNECT_HOST", "localhost");
  define("FTP_CONNECT_PORT", 22);
  define("FTP_LOGIN_USER", "gra");
  define("FTP_LOGIN_PASS", "graml@today");

  /* Set up directory */

  // ���ݦ��A���W�����եؿ�
  define("FTP_REMOTE_DIR", "/var/www/html/test2/listening/");


?>
