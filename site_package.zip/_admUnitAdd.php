<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$song_num = $_REQUEST["SONG_NUM"];
$unit_title = $_REQUEST["UNIT_TITLE"] ;
$unit_intro = trim($_REQUEST["UNIT_INTRO"] );
$cid = $_REQUEST["CID"] ;
$lid = strtoupper(substr($input_language, 0, 3));

$query_existUnit = "SELECT MAX(UNIT_ID) FROM ML_Unit WHERE UNIT_ID like '". $lid . "%' ;"  ;
$result_existUnit = mysql_query($query_existUnit);
$arrMaxUid = mysql_fetch_array($result_existUnit);
$num_query_existUnit = intval(substr($arrMaxUid[0], 4, 2));

//-- unit order #
$query_UnitOrd = "SELECT * FROM ML_Unit WHERE UNIT_ID like '". $lid . "%' ;"  ;
$result_UnitOrd  = mysql_query($query_UnitOrd);
$num_UnitOrd = mysql_num_rows($result_UnitOrd);
$unitOrd = $num_UnitOrd + 1 ;
		
$numUnit =  ( ($num_query_existUnit+1) < 10 ) ? "0".($num_query_existUnit+1) : ($num_query_existUnit+1);
$unit_id = $lid ."_". $numUnit;

$query_addCourseUnit = "INSERT INTO ML_CourseUnit VALUES ('', '". $cid ."','". $unit_id."');" ;
$result_addCourseUnit = mysql_query($query_addCourseUnit);

$query_addUnit = "INSERT INTO ML_Unit VALUES ('". $unit_id ."','". addslashes($unit_title) ."','".  addslashes($unit_intro)."','".$unitOrd."');" ;
$result = mysql_query($query_addUnit);

//-- new course access control
$query_queCourseAccess = "SELECT * FROM ML_CourseAccess WHERE CID='".$cid."';" ;
$result_queCourseAccess = mysql_query($query_queCourseAccess);
$num_thisCourse= mysql_num_rows($result_queCourseAccess);
$date_start = ( $num_thisCourse != 0 ) ? mysql_result($result_queCourseAccess, 0, "DATE_START") : "9999-12-31" ;	
$date_end =  ( $num_thisCourse != 0 ) ? mysql_result($result_queCourseAccess, 0, "DATE_END") : "9999-12-31";	

$query_addUnitAccess = "INSERT INTO ML_UnitAccess VALUES ('','".$unit_id."','".$date_start."','".$date_end."');" ;
$result_addUnitAccess = mysql_query($query_addUnitAccess);

echo $query_addUnitAccess."</br>";

for ( $i = 0; $i < $song_num ; $i++)
{
	$song_title = ( $_POST["SONG_TITLE". $i] != "" ) ?  $_POST["SONG_TITLE". $i] : "none" ;
	$album = $_POST["ALBUM". $i];
	$artist = $_POST["ARTIST". $i];
	$song_overview = trim($_POST["OVERVIEW". $i]);
	$lyrics = trim($_POST["LYRICS". $i] );
	
	if ( $song_title != "" )
	{
		$sid = $lid ."_". $numUnit ."_0". $i ;
		
		$query_addSong = "INSERT INTO ML_Song VALUES ('". $sid ."','". addslashes($song_title) ."','". addslashes($album) ."','". addslashes($artist) ."','". addslashes($song_overview) ."','". addslashes($lyrics) ."','/','-','-','-','-');" ;
		$result = mysql_query($query_addSong);

		echo $query_addSong."</br>"; 
		
		$query_addSongPWD = "INSERT INTO ML_LTPWD VALUES ('','".$sid."', '-'); ";			
		$result_addSongPWD = mysql_query($query_addSongPWD);			
		
		echo $query_addSongPWD."</br>";
		
	}
}

header('Location: _admUnitList.php?language='.$input_language); 
?>