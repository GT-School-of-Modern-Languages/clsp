<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<?php
$input_language = $_REQUEST["ULANGUAGE"];
if ( $input_language == "" ){
	header('Location:index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$sid = $_REQUEST["SID"] ;
$module = $_REQUEST["MODULE"] ;
$query_hid = $_REQUEST["HID"] ;

$doc_title = "";
$module_id = "";
$module_order = "";
$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;
if ($input_language!="Arabic"){
	$strArbSize = ( $input_language == "Chinese" ) ? 4 : 2 ;
	}
switch($module)	
{
	case "QU":		
		$doc_title = "Questions for Understanding"; 
		$module_id = "QID";
		$module_order = "Q_ORDER";
		$module_content = "Q_CONTENT";
		$module_type= "Q_TYPES";
		$module_option = "Q_OPTION";				
		break;
	case "LT": 
		$doc_title = "Listening Tasks"; 
		$module_id = "LID";
		$module_order = "L_ORDER";
		$module_content = "L_CONTENT";
		$module_type= "L_TYPES";
		$module_option = "L_OPTION";		
		break;
	case "GE":	
		$doc_title = "Grammar Questions"; 
		$module_id = "GID";
		$module_order = "G_ORDER";
		$module_content = "G_CONTENT";
		$module_type= "G_TYPES";
		$module_option = "G_OPTION";				
		break;
	case "DW":
		$doc_title = "Discussion and Writing"; 
		$module_id = "WID";
		$module_order = "W_ORDER";
		$module_content = "W_CONTENT";
		break;
}	
 
 //echo "-->".$query_hid;

$query_tasks = "SELECT * FROM ML_Heading".$module." WHERE HID='".$query_hid."' ;";
$result_tasks = mysql_query($query_tasks);
$num_tasks = mysql_num_rows($result_tasks);

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;

$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='". substr($sid, 0, 6)."'; ";
$result_unit = mysql_query($query_unit);
$unit_title = mysql_result($result_unit, 0, "UNIT_TITLE");

$query_lt = "SELECT * FROM ML_Module".$module.", ML_Heading, ML_Heading".$module." ".
						"WHERE ML_Module".$module.".".$module_id." = ML_Heading".$module.".".$module_id." ".
						"AND ML_Heading.HID = ML_Heading".$module.".HID  ".
						"AND ML_Module".$module.".SID='".$sid."' " ;				
						
$query_lt .= "AND ML_Heading.HID='".$query_hid."' ORDER BY ML_Module".$module.".".$module_order.";";

$result_lt= mysql_query($query_lt);
$num_lt = mysql_num_rows($result_lt);

$query_heading = "SELECT * FROM ML_Heading WHERE HID='".$query_hid."' ;";		
$result_heading= mysql_query($query_heading);
$heading = mysql_result($result_heading, 0, "HEADING"); 	

?>
<title><?=$doc_title?>:<?=$song_title?>:<?=$heading?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script> 
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
	<div <?=$strDirRTL?>  >
    <table width="85%" border="0" cellspacing="0" cellpadding="3" align="center">
   		<tr>
   			<th align="<?=$strAlign?>"><font size="5" color="#254117" face="Georgia" ><?=$song_title?></font></th>
   		</tr>
  <tr>
    <td align="center" valign="top">
    	<table width="100%" border="0" cellspacing="0" cellpadding="3">
      	<tr>
        	<td colspan="2" align="right" valign="top"><hr noshade color="#254117" size="3"></td>
        </tr>
        <tr bgcolor="#<?=$color2?>" height="45">
        	<td valign="center" colspan="2">&nbsp;&nbsp;<font color="#FFFFFF" size="4"><?=$heading?></font></td>
      </tr>     
<?php

for ( $i=0 ; $i < $num_lt ; $i++)
{
	if ($module != "DW") 
	{
		$l_types = mysql_result($result_lt, $i, $module_type) ;
		$l_option = str_replace("\n", "</br>", mysql_result($result_lt, $i, $module_option)); 	
		
		$task_ans =  mysql_result($result_lt, $i, "ANS"); 		
		$preFeedback =  mysql_result($result_lt, $i, "FEEDBACK"); 			
		$nextLine = array("\r\n", "\n\r", "\n");
		
		$task_feedback = str_replace($nextLine, "</br>", $preFeedback);	
		
	}
	else
	{
		$l_types = "1";
		$l_option = "";	
		
		$task_ans = "";	
		$preFeedback =   "";			
		$task_feedback = "";	
	}
		
	$l_content = "<b>". str_replace("\n", "</br>", mysql_result($result_lt, $i, $module_content)) . "</b>"; 	
	$lid = mysql_result($result_lt, $i, $module_id) ;
	$hid = mysql_result($result_lt, $i, "HID");		
	$heading =  mysql_result($result_lt, $i, "HEADING"); 		

	$task_id = "ans".$lid; // variable name, e.g. $ans85
	$preTask_res = $_REQUEST["ANS".$lid] ;
	
	$taskColor = "254117";
	$rightAnsColor = "000000"; 
	$wrongAnsColor = "FF0000"; 

	switch($l_types)	
	{
		case "1":		//Open-Ended Question	
			$nextLine = array("\r\n", "\n\r", "\n");
			$task_res = str_replace($nextLine, "</br>", $preTask_res);				
			$strAns = "<div style=\"border: dotted 0 #<?=$color2?>; border-width:1px; padding-left:3ex; padding-bottom:1ex; padding-top:1ex;\"><font family='Helvetica' size='$strArbSize'>" . $task_res . "</font></div>";
		$strTask ="<font color=\"#".$taskColor."\">". $l_content."</font></br></br>".$strAns;			
		break;
			
		case "2": 	//Fill-in-Blank Question
			$uline_count = substr_count($l_content, "_");
			$strTask = "<font color=\"#".$taskColor."\">". $l_content . "</font>";
			$task_eachOpt = explode("+", $preTask_res);
			
			for ( $c=0 ; $c < $uline_count ; $c++){
				if ( $preTask_res == "" ) {
					$task_eachOpt[$c] = "";
				}				
				
				$strAns = "<font family='Helvetica' size='$strArbSize' color='#000000' style='border-bottom: 1px dotted; border-color: #".$taskColor.";'>&nbsp;&nbsp;" . $task_eachOpt[$c] . "&nbsp;&nbsp;</font>";
				$strTask = preg_replace("/_/",  $strAns, $strTask,1)."";
			}	
		break;
			
		case "3":		//Multi-Choice Question
			$mc_count = substr_count($l_option, "</br>") +1 ;
			$strTask = "";
			for ( $c=0 ; $c < $mc_count ; $c++){
				$strAns = ( substr_count($preTask_res, $c+1 ) == 0 ) ? "&nbsp;&nbsp;" : "x" ; 
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $l_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}	
			$strTask = "<font color=\"#".$taskColor."\">". $l_content . "</font></br></br><font size=\"$strArbSize\">".$strTask . "</font>";		
		break;
			
		case "4":		//Multiple Answer Question
			$sc_count = substr_count($l_option, "</br>") +1 ;
			$strTask = "";
			for ( $c=0 ; $c < $sc_count ; $c++){
				$strAns = ( substr_count($preTask_res, $c+1 ) == 0 ) ? "&nbsp;&nbsp;" : "x" ; 
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $l_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}
			$strTask = "<font color=\"#".$taskColor."\">". $l_content . "</font></br></br><font size=\"$strArbSize\">".$strTask . "</font>";	
		break;
			
		case "5":		//Plain Text
			$strTask = "<font color=\"#".$taskColor."\">". $l_content."<font></br>"; 	
		break;
			
		case "6": 	//Fill-in-Blank Question with feedback
			$uline_count = substr_count($l_content, "_");
			$opt_count = substr_count($task_feedback, "</br>");
			$strTask = "<font color=\"#".$taskColor."\">". $l_content . "</font>";
			$task_eachOpt = explode("+", $preTask_res) ;

//-- check the num of options and the num of columns are fit, if not add <br> in the end
			if ( $uline_count-1 != $opt_count ){
				if ( $uline_count-1 > $opt_count ) {
						$diff = ($uline_count -1) - $opt_count ;
						for ($loop=0 ; $loop< $diff ; $loop++ ){
							$task_feedback .= "</br>";
						}
				}
			}
			
//-- check feedback, and each potential ans
			if ( $uline_count > 1 ){
				$fCount=2;
				$feedback_eachOpt = ($task_feedback != "-" && $task_feedback != "" && substr_count($task_feedback, "</br>") != 0 ) ? explode("</br>", $task_feedback) : "";
			}else{
				$fCount=1;
				$feedback_eachOpt = $task_feedback;
			}
			
			for ( $c=0 ; $c < $uline_count ; $c++){
				if ( $preTask_res == "" ) {
				
					$task_eachOpt[$c] = "";
				}
				if($fCount==1){
					$strEachOption = $task_feedback;
				}
				else
				$strEachOption = ( $feedback_eachOpt[$c] == "" || $feedback_eachOpt[$c] == null) ? "" : $feedback_eachOpt[$c];
				
				$optPans_count = ( substr_count($strEachOption, ":" ) ) + 1; 
				$feedback_eachPans = ( $optPans_count != 0 ) ?  explode(":", $strEachOption) : trim($feedback_eachPans);
				
				
				$chkAnsFit = "n" ;
				$testAns = "";
				
				// check if the entered string is in one of the key terms
				
				for ( $pansc = 0 ; $pansc < $optPans_count ; $pansc++ ){		
					//echo $pansc . "--";
					if ( strcasecmp( trim($feedback_eachPans[$pansc]),  trim($task_eachOpt[$c]) ) == 0 ){
						$chkAnsFit = "y" ;		
						//echo trim($feedback_eachPans[$pansc]) . " = ". trim($task_eachOpt[$c]) . "</br>";
					}else{
						//echo trim($feedback_eachPans[$pansc]) . " != ". trim($task_eachOpt[$c]) . "</br>";
					}
					
				}
				
				$ansColor = ( $chkAnsFit == "y" ) ? $rightAnsColor : $wrongAnsColor ;
			
				$strAns = "<font family='Helvetica' size='$strArbSize' color='#". $ansColor ."' style='border-bottom: 1px dotted; border-color: #".$taskColor.";'>&nbsp;&nbsp;" . $task_eachOpt[$c] . "&nbsp;&nbsp;</font>";
				$strTask = preg_replace("/_/",  $strAns, $strTask,1)." ";
			}		
		break;			
			
		case "7":		//Multi-Answer Question with feedback
			$mc_count = substr_count($l_option, "</br>") +1 ;
			$strTask = "";
			$task_ans_array=explode(" ",$task_ans);
			$ans_arr=array();
			$preTask_res_array=explode(" ",$preTask_res);
			foreach ($preTask_res_array as $value){
				if($value==""){}
				else{
					$cor=False;
					foreach ($task_ans_array as $ansValue){
						if($ansValue==$value)
							$cor=True;
					}
					if(!$cor){
						$ans_arr[$value]=1;
						
					}
				}
			}
			
			
			//print $task_ans."+".$preTask_res."+".$strTask;
			$wrong_arr=array();
			for ( $c=0 ; $c < $mc_count ; $c++){
				$strAns = ( substr_count($preTask_res, $c+1 ) == 0 ) ? "&nbsp;&nbsp;" : "x" ; 
				
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
					if($strAns=="x"){
						if($ans_arr[$c+1]==1)
							array_push($wrong_arr,$c);
					}
				}
				else if ($c == 1 ){
					if($strAns=="x"){
						if($ans_arr[$c+1]==1)
							array_push($wrong_arr,$c);
					}
					$strCon=preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $l_option, 1); 
					$strTask .= $strCon;
				}else{
					if($strAns=="x"){
						if($ans_arr[$c+1]==1)
							array_push($wrong_arr,$c);
					}
					$strCon=preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
					$strTask = $strCon;
				}
			}	
			
			
			$split_strTask=explode("<br>",$strTask);
			$sizeOfArr=sizeof($split_strTask);
			$outStr="";
			
			for ($j=0; $j<$sizeOfArr;$j++){
				if($j==0){
					if(in_array($j,$wrong_arr)){
						$outStr.="<font color=\"#FF0000\">".$split_strTask[$j]."</font>";
					}
					else
						$outStr.=$split_strTask[$j];
				}
				else{
					if(in_array($j,$wrong_arr)){
						$outStr.="<br>"."<font color=\"#FF0000\">".$split_strTask[$j]."</font>";
					}
					else
						$outStr.="<br>".$split_strTask[$j];
				}
			}
			$strTask="<font color=\"#".$taskColor."\">". $l_content ."</br></br></br>".$outStr;
			//print $task_ans."+".$preTask_res."+".$strTask;
//-- check if there are wrong answers
			$ansColor = ( trim($task_ans) == trim($preTask_res) ) ? $rightAnsColor : $wrongAnsColor;			
			//$strTask = "<font color=\"#".$taskColor."\">". $l_content . "</font></br></br><font size=\"$strArbSize\" color=\"".$ansColor."\">".$strTask . "</font>";		
		break;
			
		case "8":		//Multiple Choice Question with feedback
			$sc_count = substr_count($l_option, "</br>") +1 ;
			$strTask = "";
			
//-- check if there are wrong answers

			for ( $c=0 ; $c < $sc_count ; $c++){
				$strAns = ( substr_count($preTask_res, $c+1 ) == 0 ) ? "&nbsp;&nbsp;" : "x" ; 	
				$optColor = ( trim($preTask_res) != "" ) ? ( ( (trim($task_ans) != trim($preTask_res)) && ($c == $preTask_res-1 ) ) ? $wrongAnsColor : $rightAnsColor) : $wrongAnsColor;	
			
				if ($c == 0 ) {
					$strTask .=  "<font color=\"#".$optColor."\">" . $strAns."&nbsp;&nbsp;" ;
					echo $strTask."</br>";
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "</font><br><font color=\"#".$optColor."\">". $strAns."&nbsp;&nbsp;", $l_option, 1) ;  
				}else{
					$strTask = preg_replace("/<\/br>/", "</font><br><font color=\"#".$optColor."\">". $strAns."&nbsp;&nbsp;", $strTask, 1) ; 
				}
			}
		
			$strTask = "<font color=\"#".$taskColor."\">". $l_content . "</font></br></br><font size=\"$strArbSize\" color=\"".$ansColor."\">".$strTask . "</font></font>";	
		break;			
	}	
?>
    <tr >
    <td colspan="3" valign="top">
        <hr noshade color="#<?=$color2?>" size="1"></font>
        </td>
   </tr> 
	<tr>        
    <td colspan="2" valign="top" align="center">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr>
       	<td width="60" valign="top" align="right">&nbsp;&nbsp;</td>
       	<td valign="top"><font size="<?=$strArbSize?>"><?=$strTask?></font></td>
       	<td width="60" valign="top" align="right">&nbsp;&nbsp;</td>       	
        </tr>
<?
	if ( $task_feedback != "-" && $task_feedback != "" && $l_types != "6" ){
?>
       	<tr>
       	<th width="60" valign="top" align="right"></th>
       	<?if ($task_feedback=="-"){
       	}
       	else{?>
       	<td valign="top"><font size="1"></br><em>** Feedback: <?=$task_feedback?></em></font></td>
       	<td width="60" valign="top" align="right">&nbsp;&nbsp;</td>       	
        </tr>
        <?}?>
<?
	}
?>
		</table>
	</td>
	</tr> 	
<?php
}
?>
        </td>
      </tr>   
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#254117" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr> 
</table></br></br>
<!----Saving the student's answers---->
<script>
function saveFile(){
	var a = document.getElementsByTagName('html')[0].innerHTML;
	document.getElementById('saveString').value=a;
	//alert(document.getElementById('saveString').value);
}
</script>

<form action="_admDownload.php" method="post">
<input type="hidden" name="saveString" id="saveString" value=""/>
<!--
<input type="submit" style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: ;" onclick="saveFile()" value="Save">
-->
</form>
<!----Saving the student's answers---->
</body>
</html>
