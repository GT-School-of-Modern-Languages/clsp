<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SONG_ID"] ;
$lid = $_REQUEST["LID"] ;
$hid = ( $_REQUEST["HEADING"] == "0"  || $_REQUEST["HEADING"] == "" ) ? "1" : $_REQUEST["HEADING"];
$l_content = trim($_REQUEST["L_CONTENT"]);
$l_types = $_REQUEST["L_TYPES"] ;
$l_option = trim($_REQUEST["L_OPTION"]);
$ans = ($l_types == "8" && strlen(trim($_REQUEST["ANS"])) > 1 ) ? substr(trim($_REQUEST["ANS"]), -1) : trim($_REQUEST["ANS"]) ;
$feedback = trim($_REQUEST["FEEDBACK"]);

echo $_REQUEST["L_TYPES"] ."</br>";


	switch($l_types)	
	{
		case "1":		//Open-Ended Question
			$l_option = "";
			$ans = "";
			$feedback = "";				
			break;
		case "2": 	//Fill-In Blank Question
			$l_option = "";
			$ans = "";
			$feedback = "";					
			break;
		case "3":		//Multi-Choice Question
			$feedback = "";			
			break;
		case "4":		//Single-Choice Question
			$feedback = "";				
			break;
		case "5":		//Plain Text
			$l_option = "";
			$ans = "";
			$feedback = "";		
			break;						
		case "6": 	//Fill-In Blank Question with feedback
			$l_option = "";
			$ans = "";		
			break;
	}	

$query_updLT = "UPDATE ML_ModuleLT SET L_CONTENT='".addslashes($l_content)."', L_TYPES='".
								$l_types."', L_OPTION='".addslashes($l_option)."' ".
								", ANS='".addslashes($ans)."', FEEDBACK='".addslashes($feedback)."' ".
								"WHERE LID='".$lid."' ;";
$result_updLT = mysql_query($query_updLT);

$query_updHeadingLT = "UPDATE ML_HeadingLT SET HID='".$hid."' WHERE LID='".$lid."' ;";
$result_updHeadingLT = mysql_query($query_updHeadingLT); 

echo $query_updLT. "</br>";
echo $query_updHeadingLT. "</br>";
echo $sid;

header('Location: _admEditModule-L.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='.$hid); 
?>