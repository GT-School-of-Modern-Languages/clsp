<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php
$num_songs = $_POST["NUM_SONGS"];
$unit_id = $_POST["UNIT_ID"] ;

$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='" . $unit_id ."';" ;
$result_unit = mysql_query($query_unit);
$unit_title = mysql_result($result_unit, 0, "UNIT_TITLE");
$unit_intro = mysql_result($result_unit, 0, "UNIT_INTRO");		

//-- unit intro content seperation for Arabic

$unit_intro_A = trim($unit_intro);
$unit_intro_E = "";
$indexof_AESeperator = strpos($unit_intro, "__________");
if ( $indexof_AESeperator != "" )
{
	$unit_intro_A = trim(substr($unit_intro, 0, $indexof_AESeperator)); 
	$unit_intro_E = trim(substr($unit_intro, $indexof_AESeperator+10 ));
}

$textareaDisplay = ( $input_language == "Arabic" ) ? "display: none" : "" ;
$textareaDisplay_secE = ( $input_language == "Arabic" ) ? "" : "display: none";
$textareaDisplay_secA = ( $input_language == "Arabic" ) ? "" : "display: none";

$lid = strtoupper(substr($input_language, 0, 3));

$query_course = "SELECT * FROM ML_Course WHERE LID='".$lid."' ORDER BY CID";

$result_course = mysql_query($query_course);
$num_course = mysql_num_rows($result_course);

$query_courseunit = "SELECT * FROM ML_CourseUnit WHERE UNIT_ID='".$unit_id."'; ";
$result_courseunit = mysql_query($query_courseunit);
$num_courseunit = mysql_num_rows($result_courseunit);
$unit_cid = ($num_courseunit == "0" ) ? "" : mysql_result($result_courseunit, 0, "CID") ;

$max_unit_num = 5;

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Unit Info</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>          
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>      
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>      
    </table>
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admUnitList.php?language=<?=$input_language ?>">Units in <?=$input_language?></a> >>Edit Unit Info </div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top">
    <form name="UnitUpdate" method="post">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
    <input name="NUM_SONGS" id="NUM_SONGS" type="hidden" value="<?=$num_songs?>" readonly>
    <input name="UNIT_ID" type="hidden" value="<?=$unit_id?>" readonly>   
	<input name="language" id="language" type="hidden" value="<?=$input_language?>" readonly>	
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Course Title:</font></th> 
        <td width="80%">
          <select name="CID" style="color: #<?=$color2?>; font-size: 10pt; font-family: Verdana; border-width: 1px; background-color: #<?=$color3?>; border-color: #<?=$color2?>;" >
          	<option value="">(Choose Course)</option>
<?
for ( $i=0 ; $i < $num_course ; $i++)
{
	$cid = mysql_result($result_course, $i, "CID") ;	
	$course_title = mysql_result($result_course, $i, "COURSE_TITLE") ;
	$ifselected = ($unit_cid == $cid ) ? "SELECTED" : "" ;

?>
          	<option value="<?=$cid?>" <?=$ifselected?> ><?=$course_title?></option>      	
<?
}
?>
          </select>&nbsp;	&nbsp;        
          <input type="submit" value="Add New Course" onclick="subUnitUpd('_admCourse.php')" 
        style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">        </td>
      </tr> 
      <tr>
        <th width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Unit Title:</font></th>
        <td width="80%">     
        <input name="UNIT_TITLE" type="text" value="<?=$unit_title?>"
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
       <tr style="<?=$textareaDisplay?>">
        <th width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Unit Intro:</font></th>
        <td width="80%"><textarea name="UNIT_INTRO" id="UNIT_INTRO" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$unit_intro?></textarea></td>
      </tr>
       <tr style="<?=$textareaDisplay_secA?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>"><b>Unit Intro:</b></br><font size="2">in Arabic</font></font></td>
        <td width="80%"><textarea name="UNIT_INTRO_A" id="UNIT_INTRO_A" dir="rtl" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$unit_intro_A?></textarea></td>
      </tr>
       <tr style="<?=$textareaDisplay_secE?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>"><b>Unit Intro:</b></br><font size="2">hidden info in English</font></td>
        <td width="80%"><textarea name="UNIT_INTRO_E" id="UNIT_INTRO_E" dir="ltr" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$unit_intro_E?></textarea></td>
      </tr>      
<?php
print "<input type='hidden' name='NUM_DELETE_SONG' value='0' readonly>" ;

$query_song = "SELECT * FROM ML_Song WHERE SID like '". $unit_id ."_%'; ";
$result_song = mysql_query($query_song);

for ( $i = 0; $i < $num_songs ; $i++)
{
	$song_titile = mysql_result($result_song, $i, "SONG_TITLE");
	$album = mysql_result($result_song, $i, "ALBUM");
	$artist = mysql_result($result_song, $i, "ARTIST");
	$overview = mysql_result($result_song, $i, "SONG_OVERVIEW");

//-- song overview content seperation for Arabic

	$overview_A = trim($overview);
	$overview_E = "";
	$indexof_AESeperator_overview = strpos($overview, "__________");

	if ( $indexof_AESeperator_overview != "" )
	{
		$overview_A = trim(substr($overview, 0, $indexof_AESeperator_overview)); 
		$overview_E = trim(substr($overview, $indexof_AESeperator_overview+10 ));
	}	
	
	$lyrics = mysql_result($result_song, $i, "LYRICS");
	$sid = mysql_result($result_song, $i, "SID");
	
	$str_ifDisplay = ( $i == ($num_songs-1 ) && $num_songs != 5  ) ? "" : "none" ;
	
?>
      <tr id="songRow<?=(9*$i)+0?>" style="display: ">
        <td colspan="2">
        	<hr noshade color="#<?=$color2?>" size="3">
            <input type="hidden" id="DELETE_SONG<?=$i?>" name="DELETE_SONG<?=$i?>"  value="" readonly> 
        </td>
      </tr>   
      <tr id="songRow<?=(9*$i)+1?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Song/Text/Clip Title:</font></td>
        <td width="80%"><input type="hidden" name="SID<?=$i?>" value="<?=$sid?>" readonly>
    	    <input name="SONG_TITLE<?=$i?>" type="text" value="<?=$song_titile?>"
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="60" maxlength="100">
	        <input type="button" value="DELETE" onclick="preDelete('ds','<?=$sid?>','<?=$i?>')" 
        style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #<?=$color2?>; font-size: 6pt; font-family: Verdana;">        
        </td>
      </tr> 
        <tr>
      <tr id="songRow<?=(9*$i)+2?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Album or Subtitle:</font></td>
        <td width="80%"><input name="ALBUM<?=$i?>" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="<?=$album?>" size="60" maxlength="100"></td>
      </tr> 
       <tr id="songRow<?=(9*$i)+3?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Artist/Author:</font></td>
        <td width="80%"><input name="ARTIST<?=$i?>" type="text" value="<?=$artist?>"
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
<?php
	if( $input_language != "Arabic" )
	{
?>
       <tr id="songRow<?=(9*$i)+4?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>" id="OVERVIEW<?=$i?>" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$overview?></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$i)+5?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>_A" id="OVERVIEW<?=$i?>_A" rows="10" cols="60" style="display:none; color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$i)+6?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>_E" id="OVERVIEW<?=$i?>_E" dir="ltr" rows="10" cols="60" style="display:none; color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>   
<?php
	}
	else
	{
?>
       <tr id="songRow<?=(9*$i)+4?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>" id="OVERVIEW<?=$i?>" rows="10" cols="60" style="display: none; color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$overview?></textarea></td>
      </tr>       
       <tr id="songRow<?=(9*$i)+5?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</br><font size="2">in Arabic</font></font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>_A" id="OVERVIEW<?=$i?>_A" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$overview_A?></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$i)+6?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</br><font size="2">hidden info in English</font></font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>_E" id="OVERVIEW<?=$i?>_E" dir="ltr" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$overview_E?></textarea></td>
      </tr>      
<?
	}
?>
       <tr id="songRow<?=(9*$i)+7?>" style="display: ">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Lyrics:</font></td>
        <td width="80%"><textarea name="LYRICS<?=$i?>"  rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"><?=$lyrics?></textarea></td>
      </tr>      
      <tr id="songRow<?=(9*$i)+8?>" style="display: <?=$str_ifDisplay?>" >
        <td width="20%">&nbsp;</td>
        <td width="80%" valign="top">&nbsp;
<?php
	if ( $i == ($num_songs -1) )
	{
?>        
        <input type="button" onclick="showLayer(<?=$i+2?>)" value="Add a song under this unit" style="cursor: pointer; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">
<?php
	}	
?>              
        </td>
      </tr>     
      <tr id="delRow<?=$i?>" style="display: none;">
        <td valign="top" colspan="2" align="center">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
        	<td width="80%" align="left" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;
        	<font color="#800000" size="2">You are going to delete "<?=$song_titile?>" from this unit.</font></td>
        	<td width="20%" align="right" valign="top">

       			 <input type="submit" value="CONFIRM" onclick="subUnitUpd('_admUnitUpd.php')" 
        			style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana;"></br></br>
       			 
       			 <input type="button" value="CANCEL DELETE" onclick="preDelete('cds','<?=$sid?>','<?=$i?>')" 
        			style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana;">
        	</td>
        </tr>
        </table>
        </td>
      </tr>       
<?php
}

for($j = $num_songs; $j < $max_unit_num ; $j++)
{
	$str_ifDisplayEmpty = ( $j == 0 ) ? "" : "none";
	
?>
      <tr id="songRow<?=(9*$j)+0?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td colspan="2">
        	<hr noshade color="#<?=$color2?>" size="3">
            <input type="hidden" id="DELETE_SONG<?=$i?>" name="DELETE_SONG<?=$i?>"  value="" readonly> 
        </td>
      </tr> 
      <tr id="songRow<?=(9*$j)+1?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Song/Text/Clip Title:</font></td>
        <td width="80%"><input type="hidden" name="SID<?=$j?>" value="" readonly>
    	    <input name="SONG_TITLE<?=$j?>" type="text" value=""
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="60" maxlength="100">
        </td>
      </tr> 
        <tr>
      <tr id="songRow<?=(9*$j)+2?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Album or Subtitle:</font></td>
        <td width="80%"><input name="ALBUM<?=$j?>" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
       <tr id="songRow<?=(9*$j)+3?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Artist/Author:</font></td>
        <td width="80%"><input name="ARTIST<?=$j?>" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
<?php
	if( $input_language != "Arabic" )
	{
?>
       <tr id="songRow<?=(9*$j)+4?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$j?>" id="OVERVIEW<?=$j?>" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$j)+5?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"></td>
        <td width="80%"><textarea name="OVERVIEW<?=$j?>_A" id="OVERVIEW<?=$j?>_A" rows="10" cols="60" style="display: none; color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$j)+6?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"></td>
        <td width="80%"><textarea name="OVERVIEW<?=$j?>_E" id="OVERVIEW<?=$j?>_E" dir="ltr" rows="10" cols="60" style="display: none;  color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>  
<?php
	}
	else
	{
?>
       <tr id="songRow<?=(9*$j)+4?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"></td>
        <td width="80%"><textarea name="OVERVIEW<?=$j?>" id="OVERVIEW<?=$j?>" rows="10" cols="60" style="display: none; color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$j)+5?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</br><font size="2">in Arabic</font></font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$j?>_A" id="OVERVIEW<?=$j?>_A" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
       <tr id="songRow<?=(9*$j)+6?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</br><font size="2">hidden info in English</font></font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$j?>_E" id="OVERVIEW<?=$j?>_E" dir="ltr" rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>  
<?
	}
?>
       <tr id="songRow<?=(9*$j)+7?>" style="display: <?=$str_ifDisplayEmpty?>">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Lyrics:</font></td>
        <td width="80%"><textarea name="LYRICS<?=$j?>"  rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>      
<?php
	if ( $j != $max_unit_num -1 )
	{
?>   
      <tr id="songRow<?=(9*$j)+8?>" style="display: <?=$str_ifDisplayEmpty?>" >
        <td width="20%">&nbsp;</td>
        <td width="80%" valign="top">
        <input type="button" onclick="showLayer(<?=$j+2?>)" value="Add more song under this unit" style="cursor: pointer; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">
        </td>
      </tr>     
<?php
	}
}

?>
      <tr>
        <td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      	<tr> 
        	<td colspan="2" align="right" valign="top">
        	<input type="button" value="CANCEL" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;" onclick="javascript: history.back();">
        	<input type="submit" value="SAVE UNIT INFO"  onclick="subUnitUpd('_admUnitUpd.php')" 
        	style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">
        	</td>
      </tr> 
    </table> 
    </form>          
    </td>
  </tr>
</table>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>