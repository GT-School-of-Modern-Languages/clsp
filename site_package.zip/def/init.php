<?php

define("PJ_HEAD_TITLE", "Critical Language Song Project" );
define("ARA_STR_HOME", "الصفحة الرئيسية" );
define("CHI_STR_HOME", "首页" );
define("JAP_STR_HOME", "ホームページ" );
define("RUS_STR_HOME", "Главная" );
define("FONT_STYLE", "Arial");

define("BACKUP_BASE_PATH", "../" . "ENTER_BACKUP_BASE_PATH");
define("DOMAIN_NAME", "ENTER_DOMAIN");

$strDirRTL = ( $lid == "ARA" ) ? "style=\"direction: rtl\"" : "";
$strInputRTL = ( $lid == "ARA" ) ? "rtl" : "ltr";
$strAlign = ( $lid == "ARA" ) ? "right" : "left";
$strTHAlign = ( $lid == "ARA" ) ? "left" : "right";
$strHP = $lid; 

switch ($lid) {
	case 'ARA':
        $strHP = ARA_STR_HOME;
        break;
	case 'CHI':
        $strHP = CHI_STR_HOME;
        break;
    case 'JAP':
        $strHP = JAP_STR_HOME;
        break;
    case 'RUS':
        $strHP = RUS_STR_HOME;
        break;        
}

?>
