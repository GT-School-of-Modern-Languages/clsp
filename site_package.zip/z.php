<?php

require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$query_queCourseAccess = "SELECT * FROM ML_ModuleLT WHERE L_CONTENT LIKE  '%&#x301;%' OR L_OPTION LIKE  '%&#x301;%';" ;
$result_queCourseAccess = mysql_query($query_queCourseAccess);
$num_thisCourse= mysql_num_rows($result_queCourseAccess);

//echo $query_queCourseAccess."</br>";

for ( $i=0 ; $i < $num_thisCourse ; $i++)
{
	$sid = mysql_result($result_queCourseAccess, $i, "SID");	
	$content = mysql_result($result_queCourseAccess, $i, "L_CONTENT");	


	echo $sid. ",</br> ". $content . "</p>";
}


?>
