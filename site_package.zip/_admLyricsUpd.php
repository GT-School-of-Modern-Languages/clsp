<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$nid = $_REQUEST["NID"] ;
$phrase = trim($_REQUEST["PHRASE"] );

$query_updCN = "UPDATE ML_ModuleCN SET PHRASE='".addslashes($phrase)."' WHERE '";
$result_updCN = mysql_query($query_updCN);

header('Location: _admEditModule-N.php?ULANGUAGE='.$input_language.'&SONG_ID='.$sid); 
?>