<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$phrase = trim($_REQUEST["PHRASE"] );
$wholeline = trim($_REQUEST["WHOLELINE"] );
$chk_type = $_REQUEST["WHOLELINE"];

$chk_link = ( $_REQUEST["CHK_LINK"] == null ) ? "N" : $_REQUEST["CHK_LINK"] ;
$chk_cont = ( $_REQUEST["CHK_CONT"] == null ) ? "N" : $_REQUEST["CHK_CONT"]; 
$chk_img = ( $_REQUEST["CHK_IMG"] == null ) ? "N" : $_REQUEST["CHK_IMG"]; 
$chk_doc = ( $_REQUEST["CHK_DOC"] == null ) ? "N" : $_REQUEST["CHK_DOC"];

$link = $_REQUEST["LINK"] ;
$content = trim($_REQUEST["CONTENT"]);
$atta_img = ( $_FILES["ATTA_IMG"]["name"] == "") ? "/" : $_FILES["ATTA_IMG"]["name"] ;
$atta_doc = ( $_FILES["ATTA_DOC"]["name"] == "") ? "/" : $_FILES["ATTA_DOC"]["name"] ;
$strErrorCode_img = $_FILES['ATTA_IMG']['error']; 
$strErrorCode_doc = $_FILES['ATTA_DOC']['error']; 
$strError_img = "";
$strError_doc = "";

$img_size = 0;
$img_mime = "-";
$doc_size = 0;
$doc_mime = "-";

if ( $chk_img == "Y" )
{
	$img_size = $_FILES['ATTA_IMG']['size'];
	$img_mime = $_FILES['ATTA_IMG']['type'];
}

if ( $chk_doc == "Y" )
{
	$doc_size = $_FILES['ATTA_DOC']['size'];
	$doc_mime = $_FILES['ATTA_DOC']['type'];
}

switch($strErrorCode_img)
{
	case "1":
		$strError_img = "UPLOAD_ERR_INI_SIZE";
		break;
	case "2":
		$strError_img = "UPLOAD_ERR_FORM_SIZE";
		break;
	case "3":
		$strError_img = "UPLOAD_ERR_PARTIAL";
		break;
	case "4":
		$strError_img = "UPLOAD_ERR_NO_FILE";
		break;
	case "6":
		$strError_img = "UPLOAD_ERR_NO_TMP_DIR";
		break;
	case "7":
		$strError_img = "UPLOAD_ERR_CANT_WRITE";
		break;
	case "8":
		$strError_img = "UPLOAD_ERR_EXTENSION";
		break;
}

switch($strErrorCode_doc)
{
	case "1":
		$strError_doc = "UPLOAD_ERR_INI_SIZE";
		break;
	case "2":
		$strError_doc = "UPLOAD_ERR_FORM_SIZE";
		break;
	case "3":
		$strError_doc = "UPLOAD_ERR_PARTIAL";
		break;
	case "4":
		$strError_doc = "UPLOAD_ERR_NO_FILE";
		break;
	case "6":
		$strError_doc = "UPLOAD_ERR_NO_TMP_DIR";
		break;
	case "7":
		$strError_doc = "UPLOAD_ERR_CANT_WRITE";
		break;
	case "8":
		$strError_doc = "UPLOAD_ERR_EXTENSION";
		break;
}

// ----------------------------------------------------------- update the song info ------------------------------

$query_addCN = "INSERT INTO ML_ModuleCN VALUES(". 
								   "'".$sid."', '".addslashes($phrase)."','".addslashes($wholeline)."','','".addslashes($chk_link)."','".addslashes($chk_doc)."','".addslashes($chk_img)."','".addslashes($chk_cont)."','".addslashes($link)."','".addslashes($content)."','".addslashes($atta_img)."','".$img_size."','".$img_mime."','".addslashes($atta_doc)."','".$doc_size."','".$doc_mime."') ; "; 
$result_addCN = mysql_query($query_addCN);
echo $query_addCN."</br>";

if ( $chk_img == "Y" && $strErrorCode_img == "0" )
{

	$target_dir = "attachment/".  strtoupper(substr($input_language, 0, 3))."/" ;
	$target_file = $target_dir .  $_FILES['ATTA_IMG']['name'];
	
	if ( move_uploaded_file( $_FILES['ATTA_IMG']['tmp_name'], $target_file) )
	{
		echo "ATTA_IMG upload ok </br>";
	} else{
		echo "Upload ATTA_IMG Failed: faild cod <b>".$strError_img."</b></br>"; 
	}
}

if ( $chk_doc == "Y" && $strErrorCode_doc == "0" )
{

	$target_dir = "attachment/".  strtoupper(substr($input_language, 0, 3))."/" ;
	$target_file = $target_dir .  $_FILES['ATTA_DOC']['name'];
	
	if ( move_uploaded_file( $_FILES['ATTA_DOC']['tmp_name'], $target_file) )
	{
		echo "ATTA_DOC upload ok</br>";
	} else{
		echo "Upload ATTA_DOC Failed: faild cod <b>".$strError_doc."</b></br>"; 
	}
}

header('Location: _admEditModule-N.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
?>