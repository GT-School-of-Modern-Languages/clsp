function showLayer(trid)
{
	var displayRow;
	var hideBtn;
	
	for ( i=0; i<9; i++)
	{ 
	    displayRow = document.getElementById("songRow"+ ( (trid- 1)*9 + i ) ) ;	
		displayRow.style.display = "";
	}
	for ( j=0; j< ( trid-1 ) ; j++ )
	{
		document.getElementById("songRow" + ( j*9 + 8 ) ).style.display = "none";	    
	}
	document.getElementById("NUM_SONGS").value = trid;
}

function setRadioAns(v){
	document.getElementById("ANS").value = v;
}

function setRadioRes(lid,v){
	document.getElementById("ANS"+lid).value = v;
}

function setBlankRes(lid, num){
	var txtBlank = "";
	for ( j=0; j<num ; j++ )
	{		   
		txtBlank += document.getElementById("ANS"+lid+"-"+j).value + "+";
	}
	document.getElementById("ANS"+lid ).value= txtBlank;	 
}

function setChkboxAns(num){
	document.getElementById("ANS").text = "";
	arrChk = "";

	for ( i=1; i<num+1; i++){
		if ( document.getElementById("CHK"+i).checked ){
			arrChk += document.getElementById("CHK"+i).value + " ";
		}
	}
	
	document.getElementById("ANS").value = arrChk;
}


function setChkboxRes(lid,num){
	document.getElementById("ANS"+lid).text = "";
	arrChk = "";

	for ( i=1; i<num+1; i++){
		if ( document.getElementById("CHK"+lid+"_"+i).checked ){
			arrChk += document.getElementById("CHK"+lid+"_"+i).value + " ";
		}
	}
	
	document.getElementById("ANS"+lid).value = arrChk;
}

function showFB(lid){
	document.getElementById("Q"+lid+"_FB").style.display = "";
}

function closeFB(lid){
	document.getElementById("Q"+lid+"_FB").style.display = "none";
}

function showOption(chkShow){

	switch ( chkShow )
	{
		case 0:
		document.getElementById("trOption").style.display = "none";	   
		document.getElementById("trOptionText").style.display = "none";
		document.getElementById("trSetAns").style.display = "none";
		document.getElementById("trAnsText").style.display = "none";	   
		document.getElementById("trFeedbackText").style.display = "none";	 
		break;
		case 1:
		document.getElementById("trOption").style.display = "";	   
		document.getElementById("trOptionText").style.display = "";
		document.getElementById("trSetAns").style.display = "none";	   
		document.getElementById("trAnsText").style.display = "none";	   
		document.getElementById("trFeedbackText").style.display = "none";	   
		break;		
		case 2:
		document.getElementById("trOption").style.display = "";	   
		document.getElementById("trOptionText").style.display = "";
		document.getElementById("trSetAns").style.display = "";	   
		document.getElementById("trAnsText").style.display = "none";	   
		document.getElementById("trFeedbackText").style.display = "none";	   		
		break;				
		case 3:
		document.getElementById("trOption").style.display = "";	   
		document.getElementById("trOptionText").style.display = "";
		document.getElementById("trSetAns").style.display = "";	   
		document.getElementById("trAnsText").style.display = "";	   
		document.getElementById("trFeedbackText").style.display = "";	  
		break;	
		case 4:
		document.getElementById("trOption").style.display = "none";	   
		document.getElementById("trOptionText").style.display = "none";
		document.getElementById("trSetAns").style.display = "none";	   
		document.getElementById("trAnsText").style.display = "none";	   
		document.getElementById("trFeedbackText").style.display = "";	  
		break;			
	}
		
}

function showInput(inputID){
	
	chk = document.getElementById("chk"+inputID).checked;
	document.getElementById("chkForm").value = inputID;			
	
	if (chk)
	{
		document.getElementById("input"+inputID).style.display = "";
		document.getElementById("chk_value"+inputID).value = "Y";		
	}
	else
	{
		document.getElementById("input"+inputID).style.display = "none";					
		document.getElementById("chk_value"+inputID).value = "N";				
	}
		
}

function showQuestion(chkShow, module)
{
	
	hid = chkShow.options[chkShow.selectedIndex].value;
	
	switch ( module )
	{
		case "QU":
			document.QUESTION_UNDERSTANDING.HID.value = hid;	
		break;
		case "LT":
			document.LISTENING_TASK.HID.value = hid;	
		break;		
		case "GE":
			document.GRAMMAR.HID.value = hid;	
		break;		
		case "DW":
			document.WRITING.HID.value = hid;	
		break;				
	}	
}

function chkSubm()
{
	type_value = document.getElementById("mainForm").chkForm.value;

	if ( type_value == "" )
	{
		alert('Setup the phrase type before you submit.');
		return false;
	}
	else
	{
		chk_doc = document.getElementById("chk_value4").value;
		chk_img = document.getElementById("chk_value3").value;
		
		if ( chk_doc == "Y" || chk_img == "Y" )
		{
			file_doc = document.getElementById("mainForm").ATTA_DOC.value;
			file_img = document.getElementById("mainForm").ATTA_IMG.value;
			
			if ( chk_doc == "Y" && file_doc == "" )
			{
				alert('Upload needed document for the phrase');
				document.getElementById("mainForm").ATTA_DOC.focus();
				return false;					
			}
			
			if ( chk_img == "Y" && file_img == ""  )
			{
				alert('Upload needed image for the phrase');
				document.getElementById("mainForm").ATTA_IMG.focus();
				return false;					
			}			
			
		}else{
			return true;
		}
	}
}

function selectPhrase()
{
	document.getElementById("showLine").style.display = "none";	   
	document.getElementById("showPhrase").style.display = "";	  
	document.NOTES.WHOLELINE.value = "";	  
	document.NOTES.PHRASE.value = document.getSelection();
	document.NOTES.PHRASE.focus();
}

function selectLine(line)
{
	document.getElementById("showLine").style.display = "";	   
	document.getElementById("showPhrase").style.display = "none";	  
	document.NOTES.PHRASE.value = "";	
	document.NOTES.WHOLELINE.value = line;
	document.NOTES.WHOLELINE.focus();
}

function activate(submitLocation, cid, ctitle, new_act)
{
	document.COURSE.CID.value = cid;
	document.COURSE.COURSE_TITLE.value = ctitle;
	document.COURSE.NEW_ACT.value = new_act;		
	document.COURSE.action = submitLocation;
}

function activateUnit(submitLocation, uid, utitle, sdate, edate)
{
	document.UNIT_LIST.UNIT_ID.value = uid;
	document.UNIT_LIST.UNIT_TITLE.value = utitle;	
	document.UNIT_LIST.DATE_START.value = sdate;
	document.UNIT_LIST.DATE_END.value = edate;
	document.UNIT_LIST.action = submitLocation;
}

function subAccount(submitLocation, acid, status)
{
	document.ACCOUNT.ACID.value = acid;
	document.ACCOUNT.STATUS.value = status;
	document.ACCOUNT.action = submitLocation;
}

function subCourse(submitLocation, cid)
{
	document.COURSE.CID.value = cid;
	document.COURSE.action = submitLocation;
}

function addCourseUnit(submitLocation, cid)
{
	document.UNIT_LIST.CID.value = cid;
	document.UNIT_LIST.action = submitLocation;
}

function showCourseUnit(order)
{
	if (document.getElementById("course"+order+"_unit").style.display == "none")
	{
		document.getElementById("course"+order+"_unit").style.display = "";
		document.getElementById("course"+order+"_add").style.display = "";		
	}
	else
	{
		document.getElementById("course"+order+"_unit").style.display = "none";
		document.getElementById("course"+order+"_add").style.display = "none";		
	}		
}

function subAddHeading(submitLocation, hid)
{
	document.HEADING.HID.value = hid;
	document.HEADING.action = submitLocation;
}

function subEditHeading(submitLocation, hid)
{
	document.HEADINGLIST.HID.value = hid;
	document.HEADINGLIST.action = submitLocation;
}

function subUnitUpd(submitLocation)
{
	var pageLange = document.getElementById("language").value;
	var text_A = document.getElementById("UNIT_INTRO_A").value;
	var text_E = (document.getElementById("UNIT_INTRO_E").value != "" ) ? 
						"\n__________\n\n" + document.getElementById("UNIT_INTRO_E").value : "" ;
	var maxsongnum = 5; 
	var overview_A;
	var overview_E;	
						
	if ( pageLange == "Arabic" ) 
	{
	
		document.getElementById("UNIT_INTRO").value = text_A + text_E ;

		for ( oid=0; oid<maxsongnum; oid++)
		{
			overview_A = document.getElementById("OVERVIEW" + oid + "_A").value;
			overview_E = (document.getElementById("OVERVIEW" + oid + "_E").value != "" ) ? 
						"\n__________\n\n" + document.getElementById("OVERVIEW" + oid + "_E").value : "" ;
			document.getElementById("OVERVIEW"+oid+"").value = overview_A + overview_E ;	
		}
	}
	
	document.UnitUpdate.action = submitLocation;
}

function cpStyle()
{
	document.SUGGESTION.S_CONTENT.value = "<a target='_blank' href='http://www.mlg.gatech.edu'> Ruth Benedict </a>";
}

function submitto(submitLocation, num_songs, unit_id)
{
	//alert(submitLocation + ", " + num_songs  + ", " + unit_id);

	document.UNIT_LIST.NUM_SONGS.value = num_songs;
	document.UNIT_LIST.UNIT_ID.value = unit_id;
	
	document.UNIT_LIST.action = submitLocation;

}

function submittosong(submitLocation, unit_id, song_id)
{

	document.UNIT_LIST.UNIT_ID.value = unit_id;
	document.UNIT_LIST.SONG_ID.value = song_id;
	
	document.UNIT_LIST.action = submitLocation;

}

function submittoM(submitLocation, course_id, song_id)
{
	//alert(submitLocation + ", "+ song_id);
	//alert(document.MODULE_LIST.SONG_);
	document.MODULE_LIST.CID.value = course_id;
	document.MODULE_LIST.SONG_ID.value = song_id;
	document.MODULE_LIST.action = submitLocation;
}

function submittoC(submitLocation, cid)
{
	//alert(submitLocation + ", "+ song_id);
	//alert(document.MODULE_LIST.SONG_);
	document.MODULE_LIST.CID.value = cid;
	document.MODULE_LIST.action = submitLocation;
}

function submittoN(submitLocation)
{
	document.NOTES.action = submitLocation;
}

function submittoL(submitLocation, lid)
{
	if ( submitLocation == "_admModuleLDel.php" ){
		if ( confirm("Are you sure to delete the task?") ) {
			document.LISTENING_TASK.action = submitLocation;
			document.LISTENING_TASK.LID.value = lid;	
		}
	}else{
		document.LISTENING_TASK.action = submitLocation;
		document.LISTENING_TASK.LID.value = lid;			
	}
}

function submittoQ(submitLocation, qid)
{
	if ( submitLocation == "_admModuleQDel.php" ){
		if ( confirm("Are you sure to delete the question?") ) {
			document.QUESTION_UNDERSTANDING.QID.value = qid;	
			document.QUESTION_UNDERSTANDING.action = submitLocation;
		}
	}else{
		document.QUESTION_UNDERSTANDING.QID.value = qid;	
		document.QUESTION_UNDERSTANDING.action = submitLocation;		
	}

}

function chgTopics(submitLocation, module, hid)
{
	switch ( module )
	{
		case "QU":
			document.QUESTION_UNDERSTANDING.HID.value = hid;	
			document.QUESTION_UNDERSTANDING.action = submitLocation;
		break;
		case "LT":
			document.LISTENING_TASK.HID.value = hid;	
			document.LISTENING_TASK.action = submitLocation;
			document.getElementById("TLIST").target = "_self";
		break;		
		case "GE":
			document.GRAMMAR.HID.value = hid;	
			document.GRAMMAR.action = submitLocation;
			document.getElementById("TLIST").target = "_self";
		break;		
		case "DW":
			document.WRITING.HID.value = hid;	
			document.WRITING.action = submitLocation;
			document.getElementById("TLIST").target = "_self";
		break;				
	}
}


function moveQuestion(submitLocation,qid,module){
	switch ( module )
	{
		case "QU":
			document.QUESTION_UNDERSTANDING.QID.value = qid;	
			document.QUESTION_UNDERSTANDING.action = submitLocation;
		break;
		case "LT":
			document.LISTENING_TASK.LID.value = qid;	
			document.LISTENING_TASK.action = submitLocation;
		break;		
		case "GE":
			document.GRAMMAR.GID.value = qid;		
			document.GRAMMAR.action = submitLocation;
		break;		
		case "DW":
			document.WRITING.WID.value = qid;	
			document.WRITING.action = submitLocation;
		break;				
	}
}

function moveHeading(submitLocation,mhid,thid)
{
	document.HEADINGLIST.MAIN_HID.value = mhid;	
	document.HEADINGLIST.TARGET_HID.value = thid;		
	document.HEADINGLIST.action = submitLocation;
}

function moveUnit(submitLocation,uid){
	document.COURSE.UNIT_ID.value = uid;	
	document.COURSE.action = submitLocation;
}

function submittoG(submitLocation, gid)
{
	if ( submitLocation == "_admModuleGDel.php" ){
		if ( confirm("Are you sure to delete the task?") ) {
			document.GRAMMAR.action = submitLocation;
			document.GRAMMAR.GID.value = gid;	
		}
	}else{
		document.GRAMMAR.action = submitLocation;
		document.GRAMMAR.GID.value = gid;			
	}
}

function submittoW(submitLocation, wid)
{
	if ( submitLocation == "_admModuleWDel.php" ){
		if ( confirm("Are you sure to delete the task?") ) {
			document.WRITING.action = submitLocation;
			document.WRITING.WID.value = wid;	
		}
	}else{
		document.WRITING.action = submitLocation;
		document.WRITING.WID.value = wid;		
	}
}

function submittoS(submitLocation)
{
	document.SUGGESTION.action = submitLocation;
}

function submittoSH(submitLocation)
{
	var heading = document.SUGGESTION.S_CONTENT.value ;
	
	if ( heading != "" )
	{
		document.SUGGESTION.S_CONTENT.value = "<h4>" + heading  + "</h4>";
		document.SUGGESTION.action = submitLocation;
	}
}

function submittoNUpd(submitLocation, phrase)
{
	alert(submitLocation+", "+ phrase);
	document.NOTES_UPD.PHRASE.value = phrase;
	document.NOTES_UPD.action = submitLocation;
}
function confCNDel(phrase)
{
	if ( confirm("Are you sure to remove culture notes from: "+phrase+"  ?") )
	{
		return true;
	}
	else
	{
		return false;
	}
	
}
function handleList(open_id, trid)
{	
	act = document.getElementById("courseunit"+ trid).style.display
	
	
	switch ( act )
	{
		case "none": 
			document.getElementById("courseunit"+ trid ).style.display = "" ;
			document.getElementById("btn_handleList"+ trid ).value = "[↑]" ;
			break;
		case "": 
			document.getElementById("courseunit"+ trid ).style.display = "none" ;
			document.getElementById("btn_handleList"+ trid ).value = "[↓]" ;			
			break;
		}
}
 
function preDelete(act, delete_id, trid)
{	
	var displayRow;
	var hideRow;
	var num_deleteSong;

	switch ( act )
	{
		case "ds": // prepare to delete a song from a unit 
			displayRow = document.getElementById("delRow"+ trid ) ;
			displayRow.style.display = '';
			for ( i=1; i<=8; i++)
			{	
				hideRow = document.getElementById("songRow"+ ( 9*trid + i ) ) ;
				//alert("songRow"+ ( 7*trid + i ) );
				hideRow.style.display = "none";
			}
			
			document.getElementById("DELETE_SONG"+ trid ).value = delete_id;
			
			num_deleteSong = document.UnitUpdate.NUM_DELETE_SONG.value;
			num_deleteSong ++;
			document.UnitUpdate.NUM_DELETE_SONG.value = num_deleteSong ;			
			
			break;
			
		case "cds":  //cancel the delete song command 
			//alert("cds");
			for ( i=1; i<=8; i++)
			{
				displayRow = document.getElementById("songRow"+( 9*trid + i ) ) ;
				//alert("songRow"+ ( 7*trid + i ) );				
				displayRow.style.display = '';
			}
			hideRow = document.getElementById("delRow"+ trid ) ;
			hideRow.style.display = "none";
			
			document.getElementById("DELETE_SONG"+ trid ).value = "";

			num_deleteSong = document.UnitUpdate.NUM_DELETE_SONG.value;
			num_deleteSong -- ;
			document.UnitUpdate.NUM_DELETE_SONG.value = num_deleteSong ;			
			
			break;
			
		case "du": // prepare to delete a unit 
			

			for ( j=1 ; j<=2 ; j++)
			{	
				displayRow = document.getElementById("delRow"+ trid +"_"+j) ;
				displayRow.style.display = '';
			}
			
			for ( i=1; i<=5; i++)
			{
				hideRow = document.getElementById("showRow"+ trid + "_" + i ) ;
				hideRow.style.display = "none";
			}
			
			document.UNIT_LIST.UNIT_ID.value = delete_id;
			
			break;				

		case "cdu": // cancel to delete a unit 

			for ( j=1 ; j<=2 ; j++)
			{
				document.getElementById("delRow"+ trid +"_"+ j ).style.display = 'none' ;
			}
			
			for ( i=1; i<=5; i++)
			{
				displayRow = document.getElementById("showRow"+ trid + "_" + i ).style.display = '' ;
			}
			
			document.UNIT_LIST.UNIT_ID.value = "";
			
			break;	
			
		case "dc": // prepare to delete a course 
			
			document.getElementById("course"+ trid + "_del").style.display = '' ;
			
			document.getElementById("course"+ trid).style.display = "none" ;
			document.getElementById("courseunit"+ trid).style.display = "none" ;
			document.getElementById("courseunit"+ trid + "_add").style.display = "none" ;
			
			break;				

		case "cdc": // prepare to delete a course 
			
			document.getElementById("course"+ trid + "_del").style.display = 'none' ;
			
			document.getElementById("course"+ trid).style.display = "" ;
			document.getElementById("courseunit"+ trid).style.display = "" ;
			document.getElementById("courseunit"+ trid + "_add").style.display = "" ;
			
			break;	
			
		case "dm": // prepare to delete media 
			
			document.getElementById("unitmedia"+ trid + "_del").style.display = '' ;
			document.getElementById("unitmedia"+ trid).style.display = "none" ;

			
			break;				

		case "cdm": // prepare to delete a media 
			
			document.getElementById("unitmedia"+ trid + "_del").style.display = 'none' ;
			document.getElementById("unitmedia"+ trid).style.display = "" ;
			
			break;		

		case "da": // prepare to delete an account 

			document.getElementById("account"+ trid + "_del").style.display = '' ;
			document.getElementById("account"+ trid).style.display = "none" ;
			
			break;	
			
		case "cda": // prepare to delete an account 
			
			document.getElementById("account"+ trid + "_del").style.display = 'none' ;
			document.getElementById("account"+ trid).style.display = "" ;
			
			break;	
	}
}

//__________________ student_________________

function toSongIntro(submitLocation, sid)
{
	document.COURSE_LIST.SID.value = sid;
	document.COURSE_LIST.action = submitLocation;

}

function toUnitIntro(submitLocation, uid)
{
	document.COURSE_LIST.UNIT_ID.value = uid;
	document.COURSE_LIST.action = submitLocation;

}

function openPrint()
{
	document.getElementById("TLIST").action = "print.php";
	document.getElementById("TLIST").target = "_blank";
}

function openNotes()
{
	document.getElementById("CULTURE_NOTE").action = "printNotes.php";
	document.getElementById("CULTURE_NOTE").target = "_blank";
}

function openFB()
{
	document.getElementById("TLIST").action = "feedback.php";
	document.getElementById("TLIST").target = "_blank";
}

function chkMType(form){
	chkType = form.FILE_TYPES.value;
	chkFile = form.FILE_NAME.value;
	chkCode = form.EMBDVIDEO.value;
	
	if ( ( chkType == "1" && chkFile != "" ) || ( chkType == "2" && chkFile != "" ) || ( chkType == "3" && chkCode != "" ) )
	{ 
		return true;
	}
	else 
	{
		if ( chkType == "-" && chkFile != "" ) {
			form.FILE_TYPES.focus();
			alert("Please select a file type for the media.");
		}
		if ( ( chkType == "1" || chkType == "2" ) && chkFile == "" ) {
			form.FILE_NAME.focus();
			alert("Please select a media file from your machine to upload.");		
		}
		if ( chkType == "3" && chkCode == "" ) {
			form.EMBDVIDEO.focus();
			alert("Please edit the text for embedded video.");		
		}		
		return false;
	}
	
}

function chkHeading(form){
	chkHeading = form.HEADING.value;
	
	if ( chkHeading != "" )
	{ 
		return true;
	}
	else 
	{
		form.HEADING.focus();
		alert("Please edit the heading for the topic.");	
		return false;
	}
}

function chkTitle(form){
	chkTitle = form.COURSE_TITLE.value;
	
	if ( chkTitle != "" )
	{ 
		return true;
	}
	else 
	{
		form.COURSE_TITLE.focus();
		alert("Please enter the course title.");	
		return false;		
	}
}

function cklogin()
{
	chkACC = document.LOGIN.ACC_NAME.value;
	chkPWD = document.LOGIN.ACC_PWD.value;
	
	if ( chkACC == "" || chkPWD == "" )
	{
		return false;
	}
	else
	{
		return true;
	}
}

function clearBD(){
	document.getElementById("S_CONTENT").value = "";
}

function switchAE(answid,btnwid){
	var currentDir = document.getElementById(answid).dir;
	if ( currentDir == "ltr" ){
		document.getElementById(answid).setAttribute('dir', 'rtl');
		
		document.getElementById(btnwid).setAttribute('value', 'to English Mode');
		document.getElementById(btnwid).setAttribute('title', 'switch to English writing mode');
		document.getElementById(btnwid).setAttribute('style', 'cursor: pointer; background: #BDB76B; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;');
	}else{
		document.getElementById(answid).setAttribute('dir', 'ltr');
		
		document.getElementById(btnwid).setAttribute('value', 'إلى وضع اللغة العربية');
		document.getElementById(btnwid).setAttribute('title', 'التبديل إلى وضع الكتابة العربية');		
		document.getElementById(btnwid).setAttribute('style', 'cursor: pointer; background: #808000; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-weight:bold; font-family: Georgia;');		
	}
	
}

function openTrans(){
	var chkIfOpen = document.getElementById("chkOpen").value;
	
	if ( chkIfOpen == "0" )
	{
		document.getElementById("TLayer").style.display = "" ;
		document.getElementById("chkOpen").value = "1";
		document.getElementById("btnTrans").setAttribute('style', 'border-width: 0px; background-image: url(images/btnTranslation.png); background-color:Transparent; width: 30; height: 30; cursor: pointer;');		
	}
	else
	{
		document.getElementById("TLayer").style.display = "none" ;
		document.getElementById("chkOpen").value = "0";
		document.getElementById("btnTrans").setAttribute('style', 'border-width: 0px; background-image: url(images/btnTranslation_open.png); background-color:Transparent; width: 30; height: 30; cursor: pointer;');			
	}
}

function showFileBox()
{
	var typeitem = document.getElementById("FILE_TYPES").value;
	
	if ( typeitem == "3" )
	{
		document.getElementById("MEDIA_UPLOAD").style.display = "none" ;
		document.getElementById("MEDIA_EMBED").style.display = "" ;
	}
	else if ( typeitem =="1" || typeitem == "2" )
	{
		document.getElementById("MEDIA_UPLOAD").style.display = "" ;
		document.getElementById("MEDIA_EMBED").style.display = "none" ;	
	}
	else
	{
		document.getElementById("MEDIA_UPLOAD").style.display = "none" ;
		document.getElementById("MEDIA_EMBED").style.display = "none" ;		
	}
	

}



