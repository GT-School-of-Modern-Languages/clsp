/* escapeOverlay's construction is a bit hard to grasp. It is needed to be able to
stop the event listener. See the prototype API docs for more information:
http://www.prototypejs.org/api/event
*/
var escapeOverlay = {
	fx: function(e) 
	{
		// To make script compatable with both MSIE and Firefox
		var kC  = (window.event) ? event.keyCode : e.keyCode;
		var Esc = (window.event) ? 27 : e.DOM_VK_ESCAPE;
		
		// If keypressed is escape and the new entry field is empty
		if(kC==Esc && ($F('newvalue') == '' || $F('newvalue') == null) )
			closeDialogue();
		else if(kC==Esc && window.confirm('Are you sure you wish to close the dialogue box?') )
			closeDialogue();
	}
}

// Save in cache (to be able to stopObserving() it), see Prototype API docs for more info:
// http://www.prototypejs.org/api/event
escapeOverlay.bfx = escapeOverlay.fx.bindAsEventListener(escapeOverlay);

// loadPopup shows the overlay and dialogue box

function loadPopup()
{
    alert(1234);
        	// Show the overlay (disables rest of page)
	showOverlay();
	
	// Show dialogue and focus on newvalue
	$('dialogue').show();
	$('newvalue').focus();
}

// Shows the overlay and starts the ESCAPE event listener
function showOverlay()
{
	$('overlay').show();
	Event.observe(document, 'keypress', escapeOverlay.bfx );
}

// Hides the overlay and stops the ESCAPE event listener
function hideOverlay()
{
	$('overlay').hide();
	
	Event.stopObserving(document, 'keypress', escapeOverlay.bfx );
}

// Closes the dialogue box, resets it and hides the overlay
function closeDialogue()
{
	hideOverlay();
	
	// Hide dialogue
	$('dialogue').hide();
	
	// Clear dialogue
	$('newvalue').value = '';
}

/* Event handler for onKeyPress for the newvalue field. Enables the use of the ENTER (RETURN)
key when adding a new entry in the dialogue box */
function enterKey(event, field)
{
	// If the event key pressed was a return (code 13)
	if (event.which == 13 || event.keyCode == 13)
		addEntry(field.value);
}

// count is used to number the entries LI IDs
var count = 1;

// Adds an entry
function addEntry(message)
{
	// Close the dialogue
	closeDialogue();
	
	// If the value entered for the new entry is not empty
	if (message != '' && message != null)
	{		
		// Build a new LI, set its value and id and add it
		newLI= Builder.node('li', {id: count});
		newLI.innerHTML = message;
		count++;
		
		// Append the new LI to the entries UL
		$('entries').appendChild(newLI);
	}
}

