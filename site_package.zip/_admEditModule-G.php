<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<?php

$sid = $_REQUEST["SONG_ID"] ;
$query_hid = ( $_REQUEST["HID"] == null) ? "0" :  $_REQUEST["HID"] ;

$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_song =  "SELECT * FROM ML_Song WHERE  SID='".$sid."';";
$result_song = mysql_query($query_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE");	

$query_heading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='GE' ORDER BY ML_Heading.HID ;";

$query_strge = "SELECT * FROM ML_ModuleGE, ML_Heading, ML_HeadingGE ".
						"WHERE ML_ModuleGE.GID = ML_HeadingGE.GID ".
						"AND ML_Heading.HID = ML_HeadingGE.HID ".
						"AND ML_ModuleGE.SID='".$sid."' " ;		

$query_nonHeading = $query_strge."AND ML_HeadingGE.HID ='1' ;";
$result_nonHeading= mysql_query($query_nonHeading);
$num_nonHeading = mysql_num_rows($result_nonHeading);						
						
$query_ge = ( $query_hid != "0" ) ? $query_strge . "AND ML_Heading.HID='".$query_hid."' ORDER BY ML_ModuleGE.G_ORDER ;" : $query_strge. "ORDER BY ML_Heading.HID, ML_ModuleGE.G_ORDER ;" ;

$result_heading= mysql_query($query_heading);
$num_heading = mysql_num_rows($result_heading);
						
$result_ge = mysql_query($query_ge);
$num_ge = mysql_num_rows($result_ge);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>          
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_L?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_G?></span></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr>    
       <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>  
      <tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>     
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?></a> >> <a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>"> Headings/Directions for Grammar Exercise</a> >> Edit Questions for Grammar Exercise</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
     <Form name="GRAMMAR" method="post">
     <input name="CID" type="hidden" value="<?=$cid?>">    
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="SONG_ID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="HID" type="hidden" value="1">    
	 <input name="GID" type="hidden" value="">    
	 
    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Song Title: </font></th>
        <td width="85%"><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>"
        style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr> 
<?php

if ( $num_heading > 0 )
{						
?>
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Heading: </font></th>
        <td width="85%">
          <select name="HEADING" style="color: #<?=$color2?>; font-size: 12pt; font-family: Verdana; border-width: 0px; background-color: #<?=$color3?>;" onchange="showQuestion(this, 'GE')">
          	<option value="0">(show all questions)</option>
 <?php
	for ( $j=0 ; $j < $num_heading ; $j++)
	{	
		$heading = mysql_result($result_heading, $j, "HEADING");	
		$hid = mysql_result($result_heading, $j, "HID");	
		if ( $heading != "" )
		{
			$strSelect [$j] = ( $hid == $query_hid ) ? "selected" : "" ; 
?>         	
            <option value="<?=$hid?>" <?=$strSelect[$j]?> ><?=$heading?></option>
<?php
		}
	}
?>          
          </select>&nbsp;&nbsp;	
  		  <input type="submit" value="SWITCH TO" onclick="submittoG('_admEditModule-G.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">&nbsp;
   	     <input type="submit" value="CREATE NEW HEADING" onclick="submittoG('_admEditHeadingG.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">			
        </td>
      </tr> 
<?php
}
?>
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Question:</font></th>
        <td width="75%"><font color="#800000" size="1">( put one Grammar Exercise at a time in the column below )  </font>
      	</td>
      </tr> 
	 <tr>
        <th width="25%" align="right" valign="top">&nbsp;</th>
        <td width="75%">
		<textarea name="G_CONTENT"  rows="4" cols="65" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"></textarea>   
      	</td>
      </tr>       
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Question Type:</font></th>
        <td width="75%"><font size="2" color="#<?=$color2?>"><input type="hidden" name="G_TYPES" value="0">
        <label><input type="radio" name="G_TYPES" value="5" onclick="showOption(0)">Plain Text Only</label></br>             
        <label><input type="radio" name="G_TYPES" value="1" onclick="showOption(0)">Open-Ended Question</label></br>
        <label><input type="radio" name="G_TYPES" value="2" onclick="showOption(0)">Fill-In Blank Question <font size="1" color="#800000">(use <b>UNDERLINE, _</b> for the blank in the question)</font></label></br>
        <label><input type="radio" name="G_TYPES" value="3" onclick="showOption(1)">Multi-Answer Question</label></br>
        <label><input type="radio" name="G_TYPES" value="4" onclick="showOption(1)">Multi-Choice Question</label></br>
  		</br>      
        <label><input type="radio" name="G_TYPES" value="6" onclick="showOption(4)">Fill-In Blank Question with Feedback<font size="1" color="#800000">(use <b>UNDERLINE, _</b> for the blank in the question)</font></label></br>         
        <label><input type="radio" name="G_TYPES" value="7" onclick="showOption(2)">Multi-Answer Question with Feedback</label></br>
        <label><input type="radio" name="G_TYPES" value="8" onclick="showOption(2)">Multiple-Choice Question with Feedback</label></br>        
        
      	</font></td>
      </tr> 
      <tr>
        <td colspan="2" align="center">
        </td>
      </tr>
       <tr  id="trOption" style="display: none ;">
        <th width="25%" align="right" valign="top"><font color="#<?=$color2?>">Options:</br></font></th>
        <td width="75%">  <font color="#800000" size="1">** Put options in separate lines **  </font>
        </td>
      </tr>
       <tr id="trOptionText" style="display: none ;">
        <th width="25%" align="right" valign="top">&nbsp;</th>
        <td width="75%">
		<textarea name="G_OPTION"  rows="5" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"></textarea>        
        </td>
      </tr>      
      </tr>      
       <tr id="trSetAns" style="display: none ;">
        <th width="25%" valign="top">&nbsp;<input type="hidden" name="ANS" id="ANS" value=""></th>
        <td width="75%">
        <input type="submit" value="Set up Answer Otion(s)" onclick="submittoG('_admEditModule-GAns.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">       
        </td>
       <tr id="trAnsText">
        <th width="25%" valign="top" align="right"></th>
        <td width="75%"></td>
     	</tr> 
      </tr>
       <tr id="trFeedbackText" style="display: none;">
        <th width="25%" align="right" valign="top"><font color="#<?=$color2?>" size="2">Feedback Information</font></th>
        <td width="75%">  <font color="#800000" size="1">
        ** Put feedback for each field in separate lines **  </br>
        ** Each field can have more than one potential answer. Separate each potential answer with <b>":"</b> symbol. **</br></br>
        Ex: phrase1 for field A: phrase2 for field A: phrase3 for field A: phrase4 for field A</br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;phrase5 for field B: phrase6 for field B
        </font></br></br>
		<textarea id="FEEDBACK" name="FEEDBACK"  rows="5" cols="65" style="color: #000000; font-size: 8pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"></textarea>        
        </td>
      </tr>      
      <tr> 
        <td colspan="2" align="right" valign="top">
        <input type="button" value="BACK" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;" onclick="javascript: history.back();">
        <input type="submit" value="ADD" onclick="submittoG('_admModuleGAdd.php','')" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;
        </br></br>
        </td>
      </tr> 
<?php

	if ( $query_hid != "0" && $num_heading > 1 )
	{
		$query_preHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='GE' AND HID < ".$query_hid." ORDER BY HID DESC;" ;
		$query_nextHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='GE' AND HID > ".$query_hid." ORDER BY  HID;"; 
		$result_preHeading= mysql_query($query_preHeading);
		$num_pre = mysql_num_rows($result_preHeading);
		$result_nextHeading= mysql_query($query_nextHeading);
		$num_next = mysql_num_rows($result_nextHeading);
?>

      <tr bgcolor="#<?=$color2?>"> 
        <td colspan="2" align="right" valign="top">
	    <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr>
       		<td width="50%" align="left">
<?php
		if ( $num_pre > 0 )
		{		
			$pre_hid = mysql_result($result_preHeading, 0, "HID") ;
?>
	        <input type="submit" value="&#9668;" onclick="moveHeading('_admEditModule-G.php','GE','<?=$pre_hid ?>')"  
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;"> <font size="2" color="#FFFFFF">Previous Heading</font>
<?php
		}
?>
       		</td>
        	<td width="50%" align="right">
<?php
		if ( $num_next > 0 )
		{		
			$next_hid = mysql_result($result_nextHeading, 0, "HID") ;		
?>
        	<font size="2" color="#FFFFFF">Next Heading</font>
	        <input type="submit" value="&#9658;" onclick="moveHeading('_admEditModule-G.php','GE','<?=$next_hid?>','')"  
        	style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">        	
<?php
		}
?>
        	</td>
        </tr>
		</table>
        </td>
      </tr> 
<?php
	}

for ( $i=0 ; $i < $num_ge ; $i++)
{
	$gid = mysql_result($result_ge, $i, "GID") ;
	$g_content = str_replace("\n", "</br>", mysql_result($result_ge, $i, "G_CONTENT"));
	$g_types = mysql_result($result_ge, $i, "G_TYPES") ;
	$g_option = str_replace("\n", "</br>", mysql_result($result_ge, $i, "G_OPTION")); 	
	$hid = mysql_result($result_ge, $i, "HID");		
	$heading =  mysql_result($result_ge, $i, "HEADING"); 		
	$g_order = mysql_result($result_ge, $i, "G_ORDER"); 	
	
	$task_ans =  mysql_result($result_ge, $i, "ANS"); 		
	$preFeedback =  mysql_result($result_ge, $i, "FEEDBACK"); 			
	$nextLine = array("\r\n", "\n\r", "\n");
	$task_feedback = str_replace($nextLine, "</br>", $preFeedback);	
	
	$task_optNum = substr_count(mysql_result($result_ge, $i, "G_OPTION"),"\n") +1 ;
	$task_eachOpt = explode("\n", mysql_result($result_ge, $i, "G_OPTION"));

	$strAns = "";
	$strTask = "";
	
	$nextTask_sameHeading = $query_strge."AND ML_HeadingGE.HID ='".$hid."' AND G_ORDER > '".$g_order."' ORDER BY G_ORDER;";
	$result_nextTask= mysql_query($nextTask_sameHeading);
	$num_nextTask = mysql_num_rows($result_nextTask);				

	$preTask_sameHeading = $query_strge."AND ML_HeadingGE.HID ='".$hid."' AND G_ORDER < '".$g_order."' ORDER BY G_ORDER;";
	$result_preTask= mysql_query($preTask_sameHeading);
	$num_preTask = mysql_num_rows($result_preTask);				

	$strUpArrow = ( $num_preTask != 0 ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;
	$strDnArrow = ( $num_nextTask !== 0  ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;

	$strUpFunc = ( $num_preTask != 0 ) ? "onclick=\"moveQuestion('_admModuleMOrder.php?MODULE=GE&FUNC=UP&HEADINGID=".$hid."&QID=".$gid."','".$gid."','GE')\" " : "" ;
	$strDnFunc = ( $num_nextTask != 0 ) ? "onclick=\"moveQuestion('_admModuleMOrder.php?MODULE=GE&FUNC=DN&HEADINGID=".$hid."&QID=".$gid."','".$gid."','GE')\" " : "" ;

	switch($g_types)	
	{
		case "1":		//Open-Ended Question
			$strAns = "<textarea name=\"ANS".$i."\"  rows=\"3\" cols=\"65\" style=\"color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;\"></textarea> ";			
			$strTask = $g_content."</font></br></br>".$strAns;			
			break;
		case "2": 	//Blank Question
			$strAns = "<input name=\"ANS".$i."\" type=\"text\"style=\"color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;\" size=\"8\" maxlength=\"10\">";
			$strTask = str_replace("_", $strAns, $g_content ); 			
			break;
		case "3":		//Multi-Choice Question
			$strAns = "<input name=\"ANS".$i."\" type=\"checkbox\">";		
			$strTask = $g_content."</br>".$strAns."&nbsp;&nbsp;".str_replace("</br>", "</br>".$strAns."&nbsp;&nbsp;", $g_option); 	
			break;
		case "4":		//Single-Choice Question
			$strAns = "<input name=\"ANS".$i."\" type=\"radio\">";	
			$strTask = $g_content."</br>".$strAns."&nbsp;&nbsp;".str_replace("</br>", "</br>".$strAns."&nbsp;&nbsp;", $g_option); 	
			break;
		case "5":		//Plain Text
			$strTask = $g_content."</br></br>"; 	
			break;				
		case "6": 	//Fill-In Blank Question with feedback
			$strAns = "<input name=\"CHK".$i."\" type=\"text\"style=\"color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;\" size=\"8\" maxlength=\"8\">";
			$strTask = str_replace("_", $strAns, $g_content )."</br>"; 	
			$strTask .= "</br><hr noshade color=\"#<?=$color2?>\" size=\"1\" width=\"85%\" align=\"left\" style=\"border:dashed;border-width:1px 0 0; height:0;\"><font color='#<?=$color2?>' size='1'>".$task_feedback."</font>";			
			break;
		case "7":		//Multi-Answer Question with feedback
			for ( $n = 0 ; $n < $task_optNum ; $n++)
			{	
				$strAns = ( substr_count($task_ans, $n+1 ) == 0 ) ? "<font color='<?=$color3?>'>_</font>" : "x" ; 	
				$strTask .= "<font color='#<?=$color2?>'>".$strAns."</font>&nbsp;".$task_eachOpt[$n]."</br>"; 	
			}		
			$strTask .= "</br><hr noshade color=\"#<?=$color2?>\" size=\"1\" width=\"85%\" align=\"left\" style=\"border:dashed;border-width:1px 0 0; height:0;\"><font color='#<?=$color2?>' size='1'>".$task_feedback."</font>";
			$strTask = $g_content."</br></br>".$strTask;
			break;
		case "8":		//Multi-Choice Question with feedback
			for ( $n = 0 ; $n < $task_optNum ; $n++)
			{	
				$strAns = ( substr_count($task_ans, $n+1 ) == 0 ) ? "<font color='<?=$color3?>'>_</font>" : "x" ; 	
				$strTask .= "<font color='#<?=$color2?>'>".$strAns."</font>&nbsp;".$task_eachOpt[$n]."</br>"; 	
			}				
			$strTask .= "</br><hr noshade color=\"#<?=$color2?>\" size=\"1\" width=\"85%\" align=\"left\" style=\"border:dashed;border-width:1px 0 0; height:0;\"><font color='#<?=$color2?>' size='1'>".$task_feedback."</font>";
			$strTask = $g_content."</br></br>".$strTask;			
			break;				
	}	

	if( $query_hid == "0" && $num_preTask == 0 ) {
		$heading = ( $heading != "" ) ? $heading : "(No heading assigned yet)";
?>
    <tr >
    <td colspan="2" valign="top" bgcolor="#<?=$color2?>">
        <font size="2" color="#FFFFFF">&nbsp;&nbsp;<?=$heading?>&nbsp;</font>
        </td></tr>    
    <tr >
<?
	}
?>    
    <tr>
    <td colspan="2" valign="top" align="right">
        <hr noshade color="#<?=$color2?>" size="1"><font size="2" color="#<?=$color2?>">Grammar Exercis :: <?=$heading?></font>
        <input type="submit" value="[+]" title="edit" onclick="submittoG('_admEditModule-GUpd.php','<?=$gid?>')" 
        style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
        <input type="submit" value="[-]" title="delete" onclick="submittoG('_admModuleGDel.php','<?=$gid?>')"  
        style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
        </td></tr>  
	<tr>        
    <td colspan="2" valign="top" align="center">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr  id="Q<?=$gid?>">
       	<td width="60" valign="top" align="right"><font size="2" color="#383838">
	        <input type="submit" value="up &and; " <?=$strUpFunc?> style="background: #<?=$color3?>; border-width: 0px; <?=$strUpArrow?> font-size: 8pt; font-family: Verdana;">               	
 	        <input type="submit" value="down &or; "<?=$strDnFunc?> style="background: #<?=$color3?>; border-width: 0px; <?=$strDnArrow?> font-size: 8pt; font-family: Verdana;">              	
       	</font></td>
       	<td valign="top"><font size="2"><?=$strTask?></font></td>
        </tr>
		</table>
	</td>
	</tr>
<?php
}
?>
        </td>
      </tr>
	  </Form>      
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table></br></br>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>