<?php
session_start();

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
  header('Location: index.php'); 
}
if(!isset($_SESSION['ACID'])) {
  header("Location: login.php?ULANGUAGE=" . $input_language);
}
$acid = $_SESSION['ACID'];
$_SESSION['ACID'] = $acid;

$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';
require ("config.php");
$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$strArbColor = ( $input_language == "Arabic" ) ? "#000000" : "#383838" ;
$strArbColor_introbody = ( $input_language == "Arabic" ) ? "#000000" : "#383838" ;

$strAlign = ( $lid == "ARA" ) ? "right" : "left" ;
$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;

$query_acc_course = "SELECT * FROM ML_Course, ".
                      "(SELECT * FROM ML_CourseAccess ".
                          "WHERE CPID='". $acid ."' ". 
                          "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".   
                          "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                      ") AS courseAccess ". 
                      "WHERE ML_Course.CID=courseAccess.CID AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

$result_acc_course = mysql_query($query_acc_course);
$num_acc_course = mysql_num_rows($result_acc_course);

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link href="css/navstyle.php" rel="stylesheet" type="text/css" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php

$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
$unit_id = substr($sid, 0, 6);
$query_hid = ( $_REQUEST["HID"] == "0" ) ? "1" : $_REQUEST["HID"];

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$len_song_title = mb_strlen($song_title,'UTF-8');
$s_song_title  = ($len_song_title > 30 ) ? substr($song_title, 0, 25) . "..." : $song_title ;

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
      <img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></a></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
      <font size="10" color="black"> </font></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>"><span class="menu_head"><font color="#<?=$color2?>"><b><?=$s_song_title?></b></font></span></div></td>
      </tr>
<?
$query_numN = "SELECT * FROM ML_ModuleCN WHERE SID='". $sid."' ;";
$result_numN = mysql_query($query_numN);
$num_n = mysql_num_rows($result_numN); 

$query_chkLyrics = "SELECT LYRICS FROM ML_Song WHERE SID='". $sid."' ;";
$result_chkLyrics = mysql_query($query_chkLyrics);
$chkLyrics = mysql_result($result_chkLyrics, 0, "LYRICS");

$num_n = ( $num_n == 0 && $chkLyrics != "" ) ? 1 : $num_n;
				
$query_numQ = "SELECT * FROM ML_ModuleQU WHERE SID='". $sid."' ;";
$result_numQ = mysql_query($query_numQ);
$num_q = mysql_num_rows($result_numQ);			

$query_numL = "SELECT * FROM ML_ModuleLT WHERE SID='". $sid."' ;";
$result_numL = mysql_query($query_numL);
$num_l = mysql_num_rows($result_numL);		

$query_numG = "SELECT * FROM ML_ModuleGE WHERE SID='". $sid."' ;";
$result_numG = mysql_query($query_numG);
$num_g = mysql_num_rows($result_numG);		

$query_numW = "SELECT * FROM ML_ModuleDW WHERE SID='". $sid."' ;";
$result_numW = mysql_query($query_numW);
$num_w = mysql_num_rows($result_numW);					

$query_numS = "SELECT * FROM ML_ModuleLS WHERE SID='". $sid."' ;";
$result_numS = mysql_query($query_numS);
$num_s = mysql_num_rows($result_numS);		

$query_course = "SELECT * FROM ML_CourseUnit, ML_Course ".
                        "WHERE ML_CourseUnit.CID = ML_Course.CID ".
                        "AND ML_CourseUnit.UNIT_ID='".$unit_id."' ;";
                        
$result_course = mysql_query($query_course);
$current_course_title  = mysql_result($result_course, 0, "COURSE_TITLE");
$current_cid  = mysql_result($result_course, 0, "CID");

$lid = strtoupper(substr($input_language, 0, 3));
$query_module_title = "SELECT * FROM ML_ModuleTitle WHERE CID='".$current_cid."' AND LID='".$lid."';";
$result_module_title = mysql_query($query_module_title);
				
$mn_title = ($num_n != 0 ) ? mysql_result($result_module_title, 0, "MODULE_N") : "" ;
$mq_title  = ($num_q != 0 ) ? mysql_result($result_module_title, 0, "MODULE_Q") : "" ;
$ml_title  = ($num_l != 0 ) ? mysql_result($result_module_title, 0, "MODULE_L") : ""  ;
$mg_title  = ($num_g != 0 ) ? mysql_result($result_module_title, 0, "MODULE_G") : ""  ;
$mw_title  = ($num_w != 0 ) ? mysql_result($result_module_title, 0, "MODULE_W") : ""  ;
$ms_title  = ($num_s != 0 ) ? mysql_result($result_module_title, 0, "MODULE_S") : ""  ;

$query_module = "SELECT * FROM ML_Module ORDER BY MOD_INDEX;";
$result_module = mysql_query($query_module);
$num_module = mysql_num_rows($result_module);

for ($i=0 ; $i< $num_module ; $i++){
	$page = mysql_result($result_module, $i, "MOD_PAGE");
	$module = mysql_result($result_module, $i, "MODUEL");
	$moduel_title = "";
	$chkModule = 0 ;

	switch($module)	
	{

	case "Listening Task":
			
			$chkModule = $num_l ;
			if($ml_title=="")
				$moduel_title = $module;
			else
				$moduel_title= $ml_title;
			break;
		case "Culture Notes":
			$chkModule = $num_n ;
			if($mn_title=="")
				$moduel_title = $module;
			else
				$moduel_title=$mn_title;
			break;
		case "Grammar Exercise":
			$chkModule = $num_g ;	
			if($mg_title=="")	
				$moduel_title = $module;
			else
				$moduel_title=$mg_title;
			break;
		case "Questions for Understanding":
			$chkModule =  $num_q ;
			if($mq_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mq_title;
			break;
		case "Discussion and Writing":
			$chkModule = $num_w ;
			if($mw_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mw_title;
			break;
		case "Listening Suggestion": 	
			$chkModule = $num_s ;
			if($ms_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $ms_title;
			break;
	}
		
	if ( $chkModule != 0 ) {
		
		$strHead = ( $module == "Listening Suggestion" ) ? "<span class=\"menu_select\"><font size=\"$strArbSize\">".$moduel_title."</font></span>" :
		"<a href=\"".$page."?ULANGUAGE=".$input_language."&SID=".$sid."&PWD=".$pwd."&HID=0\"><span class=\"menu_head\"><font size=\"$strArbSize\" color=\"#383838\">".$moduel_title."</font></span></a>" ;
?>
      <tr>
        <td><div class="leftMenu"><?=$strHead?></div></td>
      </tr>
<?
	}
}
?>   
    </table>


<ul id="nav" >
   
<?
    $query_course2 = "SELECT * FROM ML_Course, ML_CourseAccess ".
                                                                "WHERE ML_Course.CID = ML_CourseAccess.CID ".
                                                                "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".
                                                                "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                                                                "AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

    $result_course2 = mysql_query($query_course2);
    $num_course2 = mysql_num_rows($result_course2);

if ($num_acc_course==1){
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {  

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>">Navigation</a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                                                                "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                                                                "AND ML_CourseUnit.CID='".$each_cid."' ".
                                                                                "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);

                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong2 = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong2 = mysql_query($query_unitsong2);
                        $num_unitsong2  = mysql_num_rows($result_unitsong2);



                         for ( $k=0 ; $k < $num_unitsong2 ; $k++)
                        {
                                $each_song_title2 = mysql_result($result_unitsong2, $k, "SONG_TITLE") ;
                                $each_sid2 = mysql_result($result_unitsong2, $k, "SID") ;
                        ?>
 <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid2?>"><?=$each_song_title2?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>
    <?}}
}
else{
    ?>
    <li><a href="#">Navigation</a>
        <ul><?
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {  

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>"><?=$course_title2?></a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                                                                "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                                                                "AND ML_CourseUnit.CID='".$each_cid."' ".
                                                                                "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);

                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);



                         for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid2 = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid2?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}}?>
                </ul>
           </li>

    <?}?>
   </ul> 
  </li>




<?}?>        
</ul>


</td>
<link rel="stylesheet" type="text/css" href="css/style.php" />
    <td align="center" valign="top"> 
    <table width="650" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
     <Form name="LISTENING_TASK" method="post">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="HID" type="hidden" value="1">    
	 <input name="PWD" type="hidden" value="<?=$pwd?>">    	 
    <table width="100%" border="0" cellspacing="0" cellpadding="3">
      <tr>
        <th height="50"  align="<?=$strAlign?>" valign="center" style="border-top-style: solid ; border-top-color:  <?=$strArbColor?>; border-top-width: 1px; border-bottom-style: solid ; border-bottom-color:  <?=$strArbColor?>; border-bottom-width: 1px;">
        <font size="4" style="color: <?=$strArbColor?>" >&nbsp;&nbsp;<?=$ms_title?></font>
        </th>
      </tr> 
      <tr>
        <td valign="top" align="center">
<?php
$query = "SELECT * FROM ML_ModuleLS WHERE SID='".$sid."'; " ;		

$result = mysql_query($query);
$num = mysql_num_rows($result);
$suggestion_list = ($num == 0 ) ? "<font color='#383838'>(No listening suggestion listed here.)</font>" : "";
$strList = ""; 

if ( $num > 0 )
{
	$suggestion_list = mysql_result($result, 0, "S_CONTENT") ;	
	$numLine = substr_count ($suggestion_list,"\n") ;	
	$subs_content = explode("\n", $suggestion_list );	

	for ($line = 0; $line <= $numLine; $line++)
	{
						
		$trim_suggestion_list = trim($subs_content[$line]);
		$strbg = ( $line % 2 == 1) ? "#FBFBEF" : "#F5F6CE";
	if($input_language == "Arabic" ){
$strList .= ( $trim_suggestion_list !="" ) ? 
							( ( substr_count( $trim_suggestion_list, "<h4>" ) == 0 ) ? "<tr bgcolor='".$strbg."'><td align='".$strAlign."'><font size='4' >" . $trim_suggestion_list ."</font></td></tr>"  : "<tr><td align='".$strAlign."'>".$trim_suggestion_list ."</td></tr>" ) : "";							
		
	}
	else{
		$strList .= ( $trim_suggestion_list !="" ) ? 
							( ( substr_count( $trim_suggestion_list, "<h4>" ) == 0 ) ? "<tr bgcolor='".$strbg."'><td align='".$strAlign."'><font size='2' >" . $trim_suggestion_list ."</font></td></tr>"  : "<tr><td align='".$strAlign."'>".$trim_suggestion_list ."</td></tr>" ) : "";							
							}
	}
}
?>               
	    <table width="95%" border="0" cellspacing="3" cellpadding="10"> 
   		<?=$strList?>
		</table>
	 </tr> 
      <tr>
        <td align="right" valign="top"><hr noshade color="<?=$strArbColor?>" size="1"></td>
      </tr>    
 
 </table> 
    </td>
  </tr> 
</table></br></br>
</Form>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
</table>
</body>
</html>
