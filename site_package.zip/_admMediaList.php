<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");





?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
	</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Media Files</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>          
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>      
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr> 
</table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >>  Media Managment in <?=$input_language?></div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <form name="UNIT_LIST" method="post">

	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
    <input type="hidden" name="SONG_ID" value="" >
    <input type="hidden" name="NUM_SONGS" value="" >
    <input type="hidden" name="UNIT_ID" value="" >
    
    <table width="100%" border="0" cellspacing="0" cellpadding="5">

<?php
$query_course = "SELECT * FROM ML_Course WHERE LID='".$lid."'; ";

$result_course = mysql_query($query_course);
$num_course = mysql_num_rows($result_course);

for ( $i=0 ; $i < $num_course ; $i++)
{
	$cid = mysql_result($result_course, $i, "CID") ;	
	$course_title = mysql_result($result_course, $i, "COURSE_TITLE") ;

	$query_courseunit = "SELECT * FROM ML_CourseUnit, ML_Unit WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
									"AND ML_CourseUnit.CID='".$cid."' ORDER BY ML_Unit.UNIT_ORDER; ";
									
	$result_courseunit = mysql_query($query_courseunit);
	$num_courseunit  = mysql_num_rows($result_courseunit);		
?>
  <tr>
    <td><font color='#<?=$color2?>' size='5' family='Verdana'><?=$course_title?></font>
    <hr noshade color="#<?=$color2?>" size="3"></br>
    </td>
  </tr>
  <tr>
  	<td>
<?php

	for ( $j=0 ; $j < $num_courseunit ; $j++)
	{       		
		$uid = mysql_result($result_courseunit, $j, "UNIT_ID") ;	
		
		$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$uid."'; ";
		$result_unit = mysql_query($query_unit);

		$unit_title = trim(mysql_result($result_unit, 0, "UNIT_TITLE") );
		$unit_intro = trim(mysql_result($result_unit, 0, "UNIT_INTRO") );

		$unit_id = $uid;
		
		$query_song = "SELECT * FROM ML_Song WHERE SID like '". $unit_id ."_%'; ";
		$result_song = mysql_query($query_song);
		$num_songs = mysql_num_rows($result_song);
?>  
     <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr>
        <th colspan="3" align="<?=$strAlign?>" valign="top"><font color="#<?=$color2?>"> << <?=$unit_title?> >></font>
        </th>
      </tr>
      <tr>
        <td colspan="3"><font color="#<?=$color2?>" size="2">Unit Introduction:</font></br>
        <textarea name="UNIT_INTRO"  rows="5" cols="100" readonly
        style="color: #000000; font-size: 8pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>;background-color: #<?=$color3?>;">
<?=$unit_intro?>
        </textarea>        
        </td>
      </tr>   
  <tr>
        <td colspan="3"><font color="#<?=$color2?>" size="2">Listening Material:</font></td>   
   	  </tr>
<?php
		if ($num_songs != 0 )
		{ 
			for ($sn=0; $sn< $num_songs; $sn++)
			{
				$song_title = mysql_result($result_song, $sn, "SONG_TITLE") ;
				$sid = mysql_result($result_song, $sn, "SID");
				$file_name = mysql_result($result_song, $sn, "FILE_NAME");
				$chkEmSong = mysql_result($result_song, $sn, "W_OTHER");
				
				$strBtnDel = ( $file_name == "/") ? "" : "<input type=\"button\" value=\"[&#150;]\" onclick=\"preDelete('dm','" .$sid. "','" .$i.$j. "-".$sn."')\" style=\"cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;\" title=\"delete the song and its media file\">";      
		        if($chkEmSong=="y")
		        	$strBtnDel="<input type=\"button\" value=\"[&#150;]\" onclick=\"preDelete('dm','" .$sid. "','" .$i.$j. "-".$sn."')\" style=\"cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;\" title=\"delete the song and its media file\">";
				$download_path = "listenings/".  strtoupper(substr($input_language, 0, 3)) ."/".$file_name;
				
				$file_target = ( $file_name == "/") ?  
									  ( $chkEmSong =="y" ) ? "<font size='1'> media has been embedded in the page</font>" : "<font color='#383838' size='1'>no media file uploaded</font>" 
									: "<a href='".$download_path."' target='_blank'><b>".$file_name."</b></a>" ;

				
?>
      <tr id="unitmedia<?=$i?><?=$j?>-<?=$sn?>" style="display: ">        
      	<td width="30%" valign="top">
        <font size="1" face="Verdana, Geneva, sans-serif" ><?=$sn+1?>) <?=$song_title?> </font></td>
      	<td width="50%" align="left" dir="ltr">
        <font size="1" face="Verdana, Geneva, sans-serif" >Media File: <?=$file_target?> </font>
        </td>
       	<td width="20%" align="right"  valign="top">
        <input type="submit" onclick="submittosong('_admUploadMedia.php','<?=$unit_id?>','<?=$sid?>')" value="[+]" style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="edit song info and upload meda file">
        <?=$strBtnDel ?>
       	</td>        
   	  </tr>
   	  
      <tr id="unitmedia<?=$i?><?=$j?>-<?=$sn?>_del" style="display: none">        
      	<td valign="top" colspan="2" align="center">
        <font color="#800000" size="1"> This will remove the media file for the song: <?=$song_title?>.</font>      	
      	<td width="20%" valign="top" align="right" valign="top">        
        <input type="submit" value="CONFIRM" name="CONFIRM_DELETE_SONG"   
        onclick="submittosong('_admMediaDel.php?FILE_NAME=<?=$file_name?>','<?=$uid?>','<?=$sid?>')" 
        style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana;" >
        <input type="button" value="CANCEL" name="CANCEL_DELETE_SONG" onclick="preDelete('cdm','<?=$sid?>','<?=$i?><?=$j?>-<?=$sn?>')"
        style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana;">		
       	</td>        
   	  </tr>
<?php
			}
?>
   	<tr> <td colspan="3" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3">
        <input type="submit" onclick="submitto('_admEditUnit.php','<?=$num_songs?>','<?=$unit_id?>')" value="Edit Song Info" style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;"></br></br>
   	</td></tr> 
<?php
		}
		else
		{
?>
      <tr>        
      <td width="85%">
        <font size="1" color='#383838'>( No listening material under this unit. )</font></td>
        <td width="15%">&nbsp;</td>        
   	</tr>
   	<tr> 
    	<td colspan="3" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3">
        <input type="submit" onclick="submitto('_admEditUnit.php','<?=$num_songs?>','<?=$unit_id?>')" value="Add Song Info" style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;"></br></br>
    </td>
    </tr> 
<?php		
		}
?>        

    </table>        
    </br>
 <?php
 	}
?>    
        </td>
      </tr>
      <tr>
    	<td><hr noshade color="#<?=$color2?>" size="3"></br></td>
      </tr>   
 <?php
 }
?>    
 </table>           
	</form>
    </td>
  </tr>
</table>
	</td>
</tr>
    </table>
    </td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
