<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$wid = $_REQUEST["WID"] ;

$query_delDW = "DELETE FROM ML_ModuleDW WHERE  SID='".$sid."' AND WID='".$wid."' ;";
$result_delDW = mysql_query($query_delDW);

$query_num = "SELECT * FROM ML_ModuleDW WHERE SID='".$sid."' ORDER BY W_ORDER; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

for ( $j=0 ; $j < $num_question ; $j++)
{	
	$qestion_id = mysql_result($result_num, $j, "WID") ;
	$query_updOrder = "UPDATE ML_ModuleDW SET W_ORDER='".($j+1)."' WHERE WID='".$qestion_id."'; ";	
	echo $query_updOrder."</br>";
	$result_updOrder = mysql_query($query_updOrder) or die(mysql_error()); 
}

$query_delHeadingDW = "DELETE FROM ML_HeadingDW WHERE WID='".$wid."' ;";
$result_delHeadingDW = mysql_query($query_delHeadingDW);

header('Location: _admEditModule-W.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='); 
?>