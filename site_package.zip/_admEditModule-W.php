<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
$sid = $_REQUEST["SONG_ID"] ;

$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_hid = ( $_REQUEST["HID"] == null) ? "0" :  $_REQUEST["HID"] ;

$query_song =  "SELECT * FROM ML_Song WHERE  SID='".$sid."';";
$result_song = mysql_query($query_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE");	

$query_heading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='DW' ORDER BY ML_Heading.HID ;";

$query_strdw = "SELECT * FROM ML_ModuleDW, ML_Heading, ML_HeadingDW ".
						"WHERE ML_ModuleDW.WID = ML_HeadingDW.WID ".
						"AND ML_Heading.HID = ML_HeadingDW.HID ".
						"AND ML_ModuleDW.SID='".$sid."' " ;				

$query_nonHeading = $query_strdw."AND ML_HeadingDW.HID ='1' ;";
$result_nonHeading= mysql_query($query_nonHeading);
$num_nonHeading = mysql_num_rows($result_nonHeading);			
						
$query_dw = ( $query_hid != "0" ) ? $query_strdw . "AND ML_Heading.HID='".$query_hid."' ORDER BY ML_ModuleDW.W_ORDER ;" : $query_strdw . "ORDER BY ML_Heading.HID, ML_ModuleDW.W_ORDER ;" ;

$result_heading= mysql_query($query_heading);
$num_heading = mysql_num_rows($result_heading);
						
$result_dw= mysql_query($query_dw);
$num_dw = mysql_num_rows($result_dw);
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>     
       <tr>
        <td><div class="leftModule"><a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_L?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_W?></span></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>  
      <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>           
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
  	<div <?=$strDirRTL?>  >  		
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a> >> <a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>"> Headings/Directions for "Discussing & Writing" </a> >> Edit Questions for Discussing & Writing</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
     <Form name="WRITING" method="post">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="CID" type="hidden" value="<?=$cid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="WID" type="hidden" value="">      
     <input name="SONG_ID" type="hidden" value="<?=$sid?>">
	 <input name="HID" type="hidden" value="<?=$query_hid?>">    
    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Song Title: </font></th>
        <td width="75%"><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>"
        style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr> 
<?php

if ( $num_heading > 0 )
{						
?>
      <tr>
        <td colspan="2" ><font color="#<?=$color2?>"><b>&nbsp;&nbsp;&nbsp;Heading: </b></font>
          <select name="HEADING" style="color: #<?=$color2?>; font-size: 12pt; font-family: Verdana; border-width: 0px; background-color: #<?=$color3?>;" onchange="showQuestion(this, 'DW')">
          	<option value="0">(show all questions)</option>
 <?php
	for ( $j=0 ; $j < $num_heading ; $j++)
	{	
		$heading = mysql_result($result_heading, $j, "HEADING");	
		$hid = mysql_result($result_heading, $j, "HID");	
		if ( $heading != "" )
		{
			$strSelect [$j] = ( $hid == $query_hid ) ? "selected" : "" ; 
?>         	
            <option value="<?=$hid?>" <?=$strSelect[$j]?> ><?=$heading?></option>
<?
		}
	}
?>          
          </select>&nbsp;&nbsp;	
  		  <input type="submit" value="SWITCH TO" onclick="submittoW('_admEditModule-W.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">&nbsp;
   	     <input type="submit" value="CREATE NEW HEADING" onclick="submittoW('_admEditHeadingW.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">			
        </td>
      </tr> 
<?
}
?>  
	 <tr>
        <th valign="top" align="center" colspan="2">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr><td>	
   		 <font color="#<?=$color2?>"><b>Topic for Discussion & Writing:</b></font>	
        </td></tr>
       	<tr><td align="center">	
		<textarea name="W_CONTENT"  rows="5" cols="75" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"></textarea>   
        </td></tr>
		</table>               
      	</th>
      </tr>  
      <tr> 
        <td colspan="2" align="right" valign="top">
        <input type="reset" value="CLEAR" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">
        <input type="submit" value="ADD" onclick="submittoW('_admModuleWAdd.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;</br></br>
        </td>
      </tr> 
<?php

	if ( $query_hid != "0" && $num_heading > 1 )
	{
		$query_preHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='DW' AND HID < ".$query_hid." ORDER BY HID DESC;" ;
		$query_nextHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='DW' AND HID > ".$query_hid." ORDER BY  HID;"; 
		$result_preHeading= mysql_query($query_preHeading);
		$num_pre = mysql_num_rows($result_preHeading);
		$result_nextHeading= mysql_query($query_nextHeading);
		$num_next = mysql_num_rows($result_nextHeading);
?>

      <tr bgcolor="#<?=$color2?>"> 
        <td colspan="2" align="right" valign="top">
	    <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr>
       		<td width="50%" align="left">
<?php
		if ( $num_pre > 0 )
		{		
			$pre_hid = mysql_result($result_preHeading, 0, "HID") ;
?>
	        <input type="submit" value="&#9668;" onclick="moveHeading('_admEditModule-W.php','DW','<?=$pre_hid ?>')"  
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;"> <font size="2" color="#FFFFFF">Previous Heading</font>
<?php
		}
?>
       		</td>
        	<td width="50%" align="right">
<?php
		if ( $num_next > 0 )
		{		
			$next_hid = mysql_result($result_nextHeading, 0, "HID") ;		
?>
        	<font size="2" color="#FFFFFF">Next Heading</font>
	        <input type="submit" value="&#9658;" onclick="moveHeading('_admEditModule-W.php','DW','<?=$next_hid?>','')"  
        	style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">        	
<?php
		}
?>
        	</td>
        </tr>
		</table>
        </td>
      </tr> 
<?php
	}

for ( $i=0 ; $i < $num_dw ; $i++)
{
	$wid = mysql_result($result_dw, $i, "WID") ;
	$w_content = mysql_result($result_dw, $i, "W_CONTENT") ;
	$w_order = mysql_result($result_dw, $i, "W_ORDER") ;	

	$nextLine = array("\r\n", "\n\r", "\n");
	$w_content = str_replace($nextLine, "</br>", $w_content);
	
	$hid = mysql_result($result_dw, $i, "HID");		
	$heading =  mysql_result($result_dw, $i, "HEADING"); 		

	$nextTask_sameHeading = $query_strdw."AND ML_HeadingDW.HID ='".$hid."' AND W_ORDER > '".$w_order."' ORDER BY W_ORDER;";
	$result_nextTask= mysql_query($nextTask_sameHeading);
	$num_nextTask = mysql_num_rows($result_nextTask);				

	$preTask_sameHeading = $query_strdw."AND ML_HeadingDW.HID ='".$hid."' AND W_ORDER < '".$w_order."' ORDER BY W_ORDER;";
	$result_preTask= mysql_query($preTask_sameHeading);
	$num_preTask = mysql_num_rows($result_preTask);				

	$strUpArrow = ( $num_preTask != 0 ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;
	$strDnArrow = ( $num_nextTask !== 0  ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;

	$strUpFunc = ( $num_preTask != 0 ) ? "onclick=\"moveQuestion('_admModuleMOrder.php?MODULE=DW&FUNC=UP&HEADINGID=".$hid."&QID=".$wid."','".$wid."','DW')\" " : "" ;
	$strDnFunc = ( $num_nextTask != 0 ) ? "onclick=\"moveQuestion('_admModuleMOrder.php?MODULE=DW&FUNC=DN&HEADINGID=".$hid."&QID=".$wid."','".$wid."','DW')\" " : "" ;
	
//Open-Ended Question
	$strAns = "<textarea name=\"ANS".$i."\"  rows=\"5\" cols=\"65\" style=\"color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;\"></textarea> ";			
	$strTask = $w_content."</font></br></br>".$strAns;	
	
	if( $query_hid == "0" && $num_preTask == 0 ) {
		$heading = ( $heading != "" ) ? $heading : "(No heading assigned yet)";
?>
    <tr >
    <td colspan="2" valign="top" bgcolor="#<?=$color2?>">
        <font size="2" color="#FFFFFF">&nbsp;&nbsp;<?=$heading?>&nbsp;</font>
        </td></tr>    
    <tr >
<?
	}
?>    
    <tr >
    <td colspan="2" valign="top" align="right">
        <hr noshade color="#<?=$color2?>" size="1"><font size="2" color="#<?=$color2?>">Topic for Discussion & Writing :: <?=$heading?></font>
        <input type="submit" value="[+]" onclick="submittoW('_admEditModule-WUpd.php','<?=$wid?>')" 
        style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
        <input type="submit" value="[-]" onclick="submittoW('_admModuleWDel.php','<?=$wid?>')"  
        style="cursor: pointer; background: #<?=$color3?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
        </td></tr>  
	<tr>        
    <td colspan="2" valign="top" align="center">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr  id="Q<?=$wid?>">
       	<td width="60" valign="top" align="right"><font size="2" color="#383838">
	        <input type="submit" value="up &and; " <?=$strUpFunc?> style="background: #<?=$color3?>; border-width: 0px; <?=$strUpArrow?> font-size: 8pt; font-family: Verdana;">               	
 	        <input type="submit" value="down &or; "<?=$strDnFunc?> style="background: #<?=$color3?>; border-width: 0px; <?=$strDnArrow?> font-size: 8pt; font-family: Verdana;">              	
       	</font></br></br></td>
       	<td valign="top"><font size="2"><?=$strTask?></font></br></br></td>
        </tr>
		</table>
	</td>
	</tr>
<?php
}
?>
        </td>
      </tr>
	  </Form>      
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table></br></br>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>