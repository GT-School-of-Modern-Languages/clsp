<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$language_id = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<?php

$sid = $_REQUEST["SONG_ID"] ;
$lid = $_REQUEST["LID"] ;
$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$language_id."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_hid = ( $_REQUEST["HID"] == null) ? "0" :  $_REQUEST["HID"] ;

$query_songlt =  "SELECT * FROM ML_Song, ML_ModuleLT ".
						"WHERE ML_Song.SID = ML_ModuleLT.SID ".
						"AND ML_ModuleLT.LID='".$lid."' ".
						"AND ML_Song.SID='".$sid."';";
            echo $query_songlt;									
						
$result_songlt = mysql_query($query_songlt);
$song_title = mysql_result($result_songlt, 0, "SONG_TITLE");	
$l_content = trim(mysql_result($result_songlt, 0, "L_CONTENT"));	
$l_types = ($_REQUEST["L_TYPES"] == "0" || $_REQUEST["L_TYPES"] == mysql_result($result_songlt, 0, "L_TYPES") ) ? 
mysql_result($result_songlt, 0, "L_TYPES") : $_REQUEST["L_TYPES"] ;	
$l_option = ($_REQUEST["L_OPTION"] =="" || trim($_REQUEST["L_OPTION"]) == trim(mysql_result($result_songlt, 0, "L_OPTION")) ) ? trim(mysql_result($result_songlt, 0, "L_OPTION")) : $_REQUEST["L_OPTION"] ;	

$task_optNum = substr_count($l_option,"\n") +1 ;
$task_eachOpt = explode("\n", $l_option);
$task_optText = str_replace("\n", "</br>", $l_option );

$ans = mysql_result($result_songlt, 0, "ANS");	
$feedback = mysql_result($result_songlt, 0, "FEEDBACK");	

$strChkDisplay = ( $l_types == 3 || $l_types == 4 || $l_types == 7 || $l_types == 8 ) ? "" : "none";
$strChkDisplay_ans = ( $l_types == 7 || $l_types == 8 ) ? "" : "none";
$strChkDisplay_feedback = ( $l_types == 6 || $l_types == 7 || $l_types == 8  ) ? "" : "none";

$strChkTypes_1 = ( $l_types == "1" ) ? "checked" : "";
$strChkTypes_2 = ( $l_types == "2" ) ? "checked" : "";
$strChkTypes_3 = ( $l_types == "3" ) ? "checked" : "";
$strChkTypes_4 = ( $l_types == "4" ) ? "checked" : "";
$strChkTypes_5 = ( $l_types == "5" ) ? "checked" : "";
$strChkTypes_6 = ( $l_types == "6" ) ? "checked" : "";
$strChkTypes_7 = ( $l_types == "7" ) ? "checked" : "";
$strChkTypes_8 = ( $l_types == "8" ) ? "checked" : "";

$task_strAns = "";
$task_strTask = "";

switch($l_types)	
{
	case "7":		//Multi-Answer Question
		for ( $i = 0 ; $i < $task_optNum ; $i++)
		{	
			$strAns = ( substr_count($ans, $i+1 ) == 0 ) ? "" : "checked" ;
			$task_strAns = "<input id=\"CHK".($i+1)."\" name=\"CHK\" type=\"checkbox\" onclick=\"setChkboxAns(".$task_optNum.")\" value=\"".($i+1)."\" ".$strAns.">";		
			$task_strTask .= $task_strAns."&nbsp;".$task_eachOpt[$i]."</br>"; 	
		}
	break;
	case "8":		//Multiple-Choice Question
		for ( $i = 0 ; $i < $task_optNum ; $i++)
		{	
			$strAns = ( substr_count($ans, $i+1 ) == 0 ) ? "" : "checked" ;
			$task_strAns = "<input id=\"CHK".($i+1)."\" name=\"CHK\" type=\"radio\" onclick=\"setRadioAns(".($i+1).")\" value=\"".($i+1)."\" ".$strAns.">";	
			$task_strTask .= $task_strAns."&nbsp;".$task_eachOpt[$i]."</br>"; 	
		}
		break;				
}	

$query_heading = "SELECT * FROM ML_Heading  WHERE SID='".$sid."' AND MODULE='LT' ORDER BY HID ;" ;
$result_heading= mysql_query($query_heading);
$num_heading = mysql_num_rows($result_heading);

$query_lt = "SELECT * FROM ML_ModuleLT, ML_Heading, ML_HeadingLT ".
						"WHERE ML_ModuleLT.LID = ML_HeadingLT.LID ".
						"AND ML_Heading.HID = ML_HeadingLT.HID ".
						"AND ML_ModuleLT.LID='".$lid."' ORDER BY ML_Heading.HID ;" ;

$result_lt= mysql_query($query_lt);
$query_hid = mysql_result($result_lt, 0, "HID");	

//echo $query_lt;

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_L?></span></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr>      
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>      
      <tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>  
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
  	<div <?=$strDirRTL?>  >  		
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a>>> <a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>">Headings/Directions for "Listening Task" </a>>> <a href="_admEditModule-L.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>&HID=">Edit "Listening Task" Module</a> >> Update Listening Tasks </div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
     <form name="LISTENING_TASK" method="post">
     <input name="CID" type="hidden" value="<?=$cid?>">      
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="SONG_ID" type="hidden" value="<?=$sid?>">   
 	 <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="LID" type="hidden" value="<?=$lid?>">      
	 <input name="HID" type="hidden" value="0">	 
    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Song Title: </font></th>
        <td width="85%"><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>"
      style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr>       
<?php

if ( $num_heading > 0 )
{		

?>
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Heading: </font></th>
        <td width="85%">
          <select name="HEADING" style="color: #<?=$color2?>; font-size: 12pt; font-family: Verdana; border-width: 0px; background-color: #<?=$color3?>;" onchange="showQuestion(this, 'LT')">
          	<option value="1">(remove heading)</option>
 <?php
	for ( $j=0 ; $j < $num_heading ; $j++)
	{	
		$heading = mysql_result($result_heading, $j, "HEADING");	
		$hid = mysql_result($result_heading, $j, "HID");	
		if ( $heading != "" )
		{
			$strSelect [$j] = ( $hid == $query_hid ) ? "selected" : "" ; 
?>         	
            <option value="<?=$hid?>" <?=$strSelect[$j]?> ><?=$heading?></option>
<?
		}
	}
?>          
          </select>
        </td>
      </tr> 
<?
}
?>  
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Listening Task:</font></th>
        <td width="75%"><font color="#800000" size="1">( put one listening task at a time in the column below )  </font>
      	</td>
      </tr> 
	 <tr>
        <th width="25%" align="right" valign="top">&nbsp;</th>
        <td width="75%">
		<textarea name="L_CONTENT"  rows="10" cols="65" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$l_content?></textarea>   
      	</td>
      </tr>       
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Task Type:</font></th>
        <td width="75%"><font size="2" color="#<?=$color2?>"><input type="hidden" name="L_TYPES" value="0">
        <label><input type="radio" name="L_TYPES" value="5" <?=$strChkTypes_5?> onclick="showOption(0)">Plain Text Only</label></br>        
        <label><input type="radio" name="L_TYPES" value="1" <?=$strChkTypes_1?> onclick="showOption(0)">Open-Ended Question</label></br>
        <label><input type="radio" name="L_TYPES" value="2" <?=$strChkTypes_2?> onclick="showOption(0)">Fill-In Blank Question <font size="1" color="#800000">** use <b>UNDERLINE(_)</b> for the blank in the question **</font></label></br>
        <label><input type="radio" name="L_TYPES" value="3" onclick="showOption(1)" <?=$strChkTypes_3?> >Multi-Answer Question</label></br>
        <label><input type="radio" name="L_TYPES" value="4" onclick="showOption(1)" <?=$strChkTypes_4?> >Multiple-Choice Question</label></br>
  		</br>      
        <label><input type="radio" name="L_TYPES" value="6" onclick="showOption(4)" <?=$strChkTypes_6?> >Fill-In Blank Question with Feedback<font size="1" color="#800000">(use <b>UNDERLINE, _</b> for the blank in the question)</font></label></br>       
        <label><input type="radio" name="L_TYPES" value="7" onclick="showOption(3)" <?=$strChkTypes_7?> >Multi-Answer Question with Feedback</label></br>
        <label><input type="radio" name="L_TYPES" value="8" onclick="showOption(3)" <?=$strChkTypes_8?> >Multiple-Choice Question with Feedback</label></br>           	
      	</font></td>
      </tr> 
      <tr>
        <td colspan="2" align="center">
        </td>
      </tr>
       <tr  id="trOption" style="display: <?=$strChkDisplay?> ;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Options:</br></font></th>
        <td width="75%">  <font color="#800000" size="1">** Put options in separate lines **  </font>
        <input type="hidden" id="OPTION" name="L_OPTION_HIDDEN" value="<?=$l_option?>">               
        </td>
      </tr>
       <tr id="trOptionText" style="display: <?=$strChkDisplay?>  ;">
        <th width="25%" align="right" valign="top">&nbsp;</th>
        <td width="75%">
		<textarea name="L_OPTION"  rows="5" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$l_option?></textarea>        
        </td>
      </tr>      
       <tr id="trSetAns" style="display: ;">
        <th width="25%" valign="top">&nbsp;</th>
        <td width="75%">
        <input type="submit" value="Update Answer Option(s)" onclick="submittoL('_admEditModule-LUpd.php','<?=$lid?>')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">       
        </td>
      </tr>  
       <tr id="trAnsText" style="display:<?=$strChkDisplay_ans?>">
        <th width="25%" valign="top" align="<?=$strTHAlign?>"><font color="#<?=$color2?>" size="2">Answer(s):</br></font>
        <input type="hidden" name="ANS" id="ANS" value="<?=$ans?>">
        </th>
        <td width="75%"><hr noshade color="#<?=$color2?>" size="1">
        <font color="#<?=$color2?>" size="2"><?=$task_strTask?></font>
        </font></td>
     	</tr> 
       <tr id="trFeedbackText" style="display:<?=$strChkDisplay_feedback?>">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>" size="2">Feedback Information</font></th>
        <td width="75%">  <font color="#800000" size="1">
        ** Put feedback for each field in separate lines **  </br>
        ** Each field can have more than one potential answer. Separate each potential answer with <b>":"</b> symbol. **</br></br>
        Ex: phrase1 for field A: phrase2 for field A: phrase3 for field A: phrase4 for field A</br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;phrase5 for field B: phrase6 for field B
        </font></br></br>
		<textarea id="FEEDBACK" name="FEEDBACK"  rows="5" cols="65" style="color: #000000; font-size: 8pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$feedback?></textarea>        
        </td>
      </tr>            
      <tr> 
        <td colspan="2" align="right" valign="top">
        <input type="button" value="CANCEL" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;" onclick="history.back();">
        <input type="submit" value="UPDATE" onclick="submittoL('_admModuleLUpd.php','<?=$lid?>')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;
        </td>
      </tr> 
      </form>
	<tr>        
    <td colspan="2" valign="top" align="center"></td>
	</tr>
        </td>
      </tr>   
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table></br></br>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>