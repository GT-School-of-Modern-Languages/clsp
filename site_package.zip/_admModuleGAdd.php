<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SID"] ;
$g_content = trim($_REQUEST["G_CONTENT"]);
$g_types = ( $_REQUEST["G_TYPES"] == "0" || $_REQUEST["G_TYPES"] == "" ) ? "5" : $_REQUEST["G_TYPES"];
$g_option = trim($_REQUEST["G_OPTION"]);
$hid = ( $_REQUEST["HEADING"] == "0" || $_REQUEST["HEADING"] == "" ) ? "1" : $_REQUEST["HEADING"];

$ans = ($g_types == "8" && strlen(trim($_REQUEST["ANS"])) > 1 ) ? substr(trim($_REQUEST["ANS"]), -1) : trim($_REQUEST["ANS"]) ;
$feedback =  trim($_REQUEST["FEEDBACK"]) ;

$query_num = "SELECT * FROM ML_ModuleGE WHERE SID='".$sid."'; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

$query_addGE = "INSERT INTO ML_ModuleGE VALUES('".$sid."','','".addslashes($g_content)."','".$g_types."','".addslashes($g_option)."','".($num_question+1)."','".$ans."','".addslashes($feedback)."');" ;
$result_addGE = mysql_query($query_addGE);

$query_selGE = "SELECT GID FROM ML_ModuleGE WHERE SID='".$sid."' AND G_CONTENT='".addslashes($g_content)."' ;" ;
$result_selGE = mysql_query($query_selGE);
$gid = mysql_result($result_selGE, 0, "GID") ;

$query_addHeadingGE = "INSERT INTO ML_HeadingGE VALUES('".$hid."','".$gid."');" ;
$result_addHeadingGE = mysql_query($query_addHeadingGE);

echo $query_addGE;

header('Location: _admEditModule-G.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID=#Q'.$lid); 
?>