<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$lid = strtoupper(substr($input_language, 0, 3));

$acc_name = $_REQUEST["ACC_NAME"];
$acc_pwd = $_REQUEST["ACC_PWD"];


$query_account = "SELECT * FROM ML_CoursePWD WHERE LID='".$lid."' ".
							"AND ACC_NAME='".$acc_name."' ".
							"AND ACC_PWD='".$acc_pwd."' ".		
							"AND ACCESS_START <= '". date("Y-m-d") . "' ". 	
							"AND ACCESS_END > '". date("Y-m-d") . "' "; 									
							"ORDER BY ACID;" ;

$result_account = mysql_query($query_account);
$num_account= mysql_num_rows($result_account);

$chk = ( $num_account == 0 ) ? "0" : "1" ;

if ( $chk == "0" ){
	//header('Location: login.php?ULANGUAGE='.$input_language.'&LOGIN='.$chk); 
	header('Location: login.php?ULANGUAGE='.$input_language); 
}else{
	session_start();
	setcookie('main', 'true',time()+60*60*6);
	$_SESSION['ACID'] = mysql_result($result_account, 0, "ACID");
	header('Location: courseList.php?ULANGUAGE='.$input_language); 
}
?>