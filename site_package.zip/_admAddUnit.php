<?php
$input_language = $_REQUEST["ULANGUAGE"];
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$cid = $_REQUEST["CID"];
$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';
require ("config.php");
$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$query_course = "SELECT * FROM ML_Course WHERE CID='".$cid."'; ";
$result_course = mysql_query($query_course);
$course_title = mysql_result($result_course, 0, "COURSE_TITLE") ;

$max_unit_num = 5;

//-- intro content seperation for Arabic
$textareaDisplay = ( $input_language == "Arabic" ) ? "display: none" : "" ;
$textareaDisplay_secE = ( $input_language == "Arabic" ) ? "" : "display: none";
$textareaDisplay_secA = ( $input_language == "Arabic" ) ? "" : "display: none";

$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    	</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Unit Info</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
       <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>  
       <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>        
    <tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>       
    </table>
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admUnitList.php?language=<?=$input_language ?>">Units in <?=$input_language?></a> >>Edit Basic Info </div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top">
    <form name="SongEdit" method="post" action="_admUnitAdd.php">	
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
    <input name="SONG_ID" type="hidden" value="" readonly>
    <input name="SONG_NUM" type="hidden" value="1" readonly>
    <input name="CID" type="hidden" value="<?=$cid?>" readonly>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="20%" align="<?=$strTHAlign?>"><font color="#<?=$color2?>">Course Title:</font></th>
        <td width="80%"><input name="COURSE_TITLE" type="text" value="<?=$course_title?>" readonly
        style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <th width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Unit Title:</font></th>
        <td width="80%"><input name="UNIT_TITLE" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
       <tr>
        <th width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Unit Intro:</font></th>
        <td width="80%"><textarea name="UNIT_INTRO"  rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
<?
for ( $i = 0; $i < $max_unit_num ; $i++)
{
	$str_ifDisplay = ($i == 0 ) ? "" : "none" ;
?>
      <tr id="songRow<?=(7*$i)+0?>" style="display: <?=$str_ifDisplay?>;">
        <td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>   
      <tr id="songRow<?=(7*$i)+1?>" style="display: <?=$str_ifDisplay?>;">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Song Title:</font></td>
        <td width="80%"><input name="SONG_TITLE<?=$i?>" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
		</td>
      </tr> 
        <tr>
      <tr id="songRow<?=(7*$i)+2?>" style="display: <?=$str_ifDisplay?>;">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Album:</font></td>
        <td width="80%"><input name="ALBUM<?=$i?>" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
       <tr id="songRow<?=(7*$i)+3?>" style="display: <?=$str_ifDisplay?>;">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Artist:</font></td>
        <td width="80%"><input name="ARTIST<?=$i?>" type="text" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100"></td>
      </tr> 
       <tr id="songRow<?=(7*$i)+4?>" style="display: <?=$str_ifDisplay?>;">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Overview:</font></td>
        <td width="80%"><textarea name="OVERVIEW<?=$i?>"  rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>
       <tr id="songRow<?=(7*$i)+5?>" style="display: <?=$str_ifDisplay?>;">
        <td width="20%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Lyrics:</font></td>
        <td width="80%"><textarea name="LYRICS<?=$i?>"  rows="10" cols="60" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color2?>;"></textarea></td>
      </tr>      
      <tr id="songRow<?=(7*$i)+6?>" style="display: <?=$str_ifDisplay?>;">
        <td width="20%">&nbsp;</td>
        <td width="80%" valign="top">
<?
		if ( $i < ($max_unit_num -1) )
		{
		
?>
        <input type="button" onclick="showLayer(<?=$i+2?>)" title="Add another song under this unit" value="Add another song under this unit" style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #<?=$color2?>; font-size: 8pt; font-family: Verdana;">      
<?
		}
?>        
        &nbsp;</td>
      </tr>     
<?
}
?>      
      <tr>
        <td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      	<tr> 
        	<td colspan="2" align="right" valign="top">
          <input type="button" value="CANCEL" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;" onclick="javascript: history.back();">
        	<input type="reset" value="CLEAR" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">
        	<input type="submit" value="SAVE NEW UNIT" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">
        	</td>
      </tr> 
    </table> 
    </form>          
    </td>
  </tr>
</table>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>