<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;

// ----------------------------------------------------------- update pwd for Listening Task info ------------------------------

$query_updPWD = "UPDATE ML_LTPWD SET PWD='".addslashes($pwd)."' WHERE SID='".$sid."' ;";
$result_updDW= mysql_query($query_updPWD);

echo $query_updPWD;

header('Location:_admEditHeadingL.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
?>