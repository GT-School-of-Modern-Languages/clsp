
<?php

$input_language = $_POST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
   </td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>   
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_select">File Upload</span></a></div></td>
      </tr>         
    </table>    
</td>
    <td align="left" valign="top">
<br/>
<br/>
<font color="#<?=$color2?>" size="5"> Uploading a file </font>
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
<td width="20"></td><hr size="3" noshade="" color="#<?=$color2?>">
<tr height = "20" ></tr>
<tr><td width="20"></td>
<td><font color="#<?=$color2?>"><?php 
 $target = "upload/"; 
 $target = $target . basename( $_FILES['uploaded']['name']) ; 
 $uploaded_size = $_FILES['uploaded']['size'];
 $uploaded_type = $_FILES['uploaded']['type'];
 //echo basename( $_FILES['uploaded']['name']);
 $ok=1; 
 //This is our size condition 
 if ($uploaded_size > 3500000) 
 { 
 echo "Your file is too large.<br/><br/>"; 
 $ok=0; 
 } 
 //This is our limit file type condition 
 if ($uploaded_type =="text/php" || $uploaded_type =="application/x-httpd-php" || $uploaded_type =="application/php" || $uploaded_type =="application/x-php" || $uploaded_type =="application/octet-stream" || $uploaded_type =="application/exe" || $uploaded_type =="application/msdos-windows" || $uploaded_type =="application/dos-exe") 
 { 
 echo "PHP files or EXEs cannot be uploaded<br/><br/>"; 
 $ok=0; 
 } 

 //Here we check that $ok was not set to 0 by an error 
 if ($ok==0) 
 { 
 echo "Sorry your file was not uploaded<br/><br/>"; 
 } 
   
 //If everything is ok we try to upload it 
 else 
 { 
	if (!file_exists($target))
	 {
	 if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) 
	 { 
	 echo "The file ". basename( $_FILES['uploadedfile']['name']). " has been uploaded<br/>"; 
	 echo "You can link the file using the url : http://www.clsp.gatech.edu/Song_Project/upload/".basename( $_FILES['uploaded']	['name'])."<br/><br/>";
	 } 
	 else 
	 { 
	 echo "Sorry, there was a problem uploading your file, please try again or contact the system administrator<br/><br/>"; 
	 } 
	 }
	else
	 {
	 echo "File exists on the server. If it is only a naming conflict. Please rename the file and try again.<br/><br/>";
	 }
 } 

 ?> </font></td>
</tr>
</table>

</font>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html> 

