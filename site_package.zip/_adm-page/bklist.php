<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Song Project @GT Modern Language</title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>
<script language="JavaScript" type="text/javascript"></script>

<?php

//-- basic director set up
$bkdir_path = "../../_historyAccess/";
$bkdir_which = $_REQUEST["WHICH"]; 

$where = $bkdir_path . $bkdir_which;

//-- date operation
$currenrYear = date("Y");
$currenrMonth = intval( date("m") );
$arrMonth = array("January","Febuary","March","April","May","June","July","August","September","October","November","December");
$monthCount = 12;

$thisYear = $currenrYear ;
$thisMonth = $currenrMonth ;

$str_SITE = ( $bkdir_which == "SITE" ) ? 
"<font class=\"diron\">&nbsp;&nbsp;INTERFACE&nbsp;&nbsp;</font>" : "<font class=\"diroff\"><a href=\"bklist.php?WHICH=SITE\">&nbsp;&nbsp;INTERFACE&nbsp;&nbsp;</a></font>" ;
$str_DB = ( $bkdir_which == "DB" ) ? 
"<font class=\"diron\">&nbsp;&nbsp;DATABASE&nbsp;&nbsp;</font>" : "<font class=\"diroff\"><a href=\"bklist.php?WHICH=DB\">&nbsp;&nbsp;DATABASE&nbsp;&nbsp;</a></font>" ;

echo "<table class=\"bkadm\" border=\"1\">";
echo "<tr><td><a href=\"http://www.clsp.gatech.edu/Song_Project/_adm-page/\">&larr; Back</a> to designer's main page.<hr noshade style=\"height: 1em #CCC solid;\"></th></tr>";
echo "<tr><th><font size=\"4\">Current Backup Directory: ".$str_SITE." &nbsp;&nbsp;". $str_DB ."</font></p></th></tr>";

	for ( $i=1 ; $i <= $monthCount ; $i++)
	{				
		echo "<tr><td>". $thisYear." ".$arrMonth[($thisMonth-1)] ."</td></tr>";

		$itemHandler = opendir($where);		
		while(($item= readdir($itemHandler)) !== false ){
       		if( substr($item, 0, 1) != "." && substr($item, 12, 4) == $thisYear && intval(substr($item, 16, 2)) == $thisMonth ){
       			echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"$where/$item\">$item</a></td></tr>";
       		}
       	}

		$thisMonth = ( ( $currenrMonth - $i ) < 1 ) ? 12 + ( $currenrMonth - $i) : $currenrMonth - $i;
		$thisYear = ( ( $currenrMonth - $i ) < 1 ) ? $currenrYear - 1 : $currenrYear;
	}
echo "</table>";

?>

</body>
</html>