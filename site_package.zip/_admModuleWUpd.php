<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$hid = ( $_REQUEST["HEADING"] == "0" || $_REQUEST["HEADING"] == "" ) ? "1" : $_REQUEST["HEADING"];
$wid = $_REQUEST["WID"] ;
$w_content = trim($_REQUEST["W_CONTENT"]);

// ----------------------------------------------------------- update the dw info ------------------------------

$query_updDW = "UPDATE ML_ModuleDW SET W_CONTENT='".addslashes($w_content)."' WHERE WID='".$wid."' ;";
$result_updDW= mysql_query($query_updDW);

$query_updHeadingDW = "UPDATE ML_HeadingDW SET HID='".$hid."' WHERE WID='".$wid."' ;";
$result_updHeadingDW = mysql_query($query_updHeadingDW);

echo $query_updHeadingDW;

header('Location: _admEditModule-W.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='.$hid); 

?>