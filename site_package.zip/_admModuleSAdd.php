<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$s_content = trim($_REQUEST["S_CONTENT"]);

$query_addLS = "INSERT INTO ML_ModuleLS VALUES('".$sid."','".addslashes($s_content)."');" ;
$result_addLS = mysql_query($query_addLS);

header('Location: _admEditModule-S.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 

?>