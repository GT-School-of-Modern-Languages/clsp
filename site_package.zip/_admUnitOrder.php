<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"];
$lid = strtoupper(substr($input_language, 0, 3));
$question_uid = $_REQUEST["UNIT_ID"] ;
$func = $_REQUEST["FUNC"];
$submitLocation = "_admCourse";


// ----------------------------------------------------------- update order info ------------------------------

//select the order of the target unit
$query_selOrder = "SELECT UNIT_ORDER FROM ML_Unit WHERE UNIT_ID='".$question_uid."' ;";
$result_selOrder = mysql_query($query_selOrder);
$question_order = mysql_result($result_selOrder, 0, "UNIT_ORDER"); 

$new_order = ($func == "UP" ) ? ( $question_order - 1) : ( $question_order +1 ) ; 
$new_exchangedorder = $question_order ; 

$query_selExchangedOrder = "SELECT UNIT_ID FROM ML_Unit WHERE UNIT_ID like'".$lid."%' AND UNIT_ORDER='".$new_order."' ;";
$result_selExchangedOrder = mysql_query($query_selExchangedOrder);
$exchanged_question_id = mysql_result($result_selExchangedOrder, 0, "UNIT_ID") or die(mysql_error()); 

$query_updOrder_target = "UPDATE ML_Unit SET UNIT_ORDER='".$new_order."' WHERE UNIT_ID='".$question_uid."' ;";
$result_updOrder_target = mysql_query($query_updOrder_target) or die(mysql_error()); 

$query_updOrder_exchanged = "UPDATE ML_Unit SET UNIT_ORDER='".$new_exchangedorder."' WHERE UNIT_ID='".$exchanged_question_id."' ;";
$result_updOrder_exchanged = mysql_query($query_updOrder_exchanged) or die(mysql_error()); 

header('Location:'.$submitLocation.'.php?language='.$input_language); 
?>