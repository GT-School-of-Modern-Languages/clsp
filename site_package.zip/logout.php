<?php
  session_start();
  $input_language = $_REQUEST["ULANGUAGE"] ;
  session_destroy();

  if ( $input_language == "" ){
	header('Location: index.php'); 
  }
  
  header("Location: login.php?ULANGUAGE=" . $input_language);
?>


