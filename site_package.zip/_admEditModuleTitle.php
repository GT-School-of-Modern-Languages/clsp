<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"];

if ( $input_language == "" || $cid == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

$query_mtitle_eng = "SELECT * FROM ML_ModuleTitle WHERE LID='ENG';" ;
$result_mtitle_eng = mysql_query($query_mtitle_eng);

$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".strtoupper(substr($input_language, 0, 3))."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);

$num_fields = 8;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Module Management</span></div></td>
      </tr>    
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>        
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>      
    </table>    
</td>
    <td align="left" valign="top">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	   	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a>>> Module Title Edit</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >

    <form name="updMTitleForm" method="post" action="_admModuleTitleUpd.php">
    <input name="CID" type="hidden" value="<?=$cid?>" readonly>
    <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#<?=$color3?>">	  
      <tr>
    	<td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
  	  </tr> 
      <tr>
    	<th width="30%" align="<?=$strTHAlign?>"><font size="2" face="Verdana, Geneva, sans-serif" color="#<?=$color2?>">in English</font></th>
  	  	<th width="70%"><font size="2" face="Verdana, Geneva, sans-serif" color="#<?=$color2?>">in <?=$input_language?></font></th>
  	  </tr> 
      <tr>
    	<td colspan="2"><hr noshade color="#<?=$color2?>" size="1"></td>
  	  </tr> 
<?php
for ($i=2 ; $i< $num_fields ; $i++)
{
?>
      <tr>
    	<th align="<?=$strTHAlign?>"><font size="2" face="Verdana, Geneva, sans-serif" color="#<?=$color2?>"><?=mysql_result($result_mtitle_eng, 0, $i)?>:</th>
  	  	<td ><input name="<?=mysql_fetch_field($result_mtitle_eng, $i)->name?>" type="text" value="<?=mysql_result($result_mtitle, 0, $i)?>"
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="60" maxlength="100">  	  	
  	  	</td>
  	  </tr>  
<?
}
?> 
      <tr> 
        <td colspan="2" align="right" valign="top"></br><hr noshade color="#<?=$color2?>" size="3">
        <input type="submit" value="UPDATE TITLE" style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;"></br>&nbsp;
        </td>
      </tr> 
    </table> 
	</form>
    </td>
  </tr> 
</table>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>