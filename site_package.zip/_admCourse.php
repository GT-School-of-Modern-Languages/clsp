<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
$color4=mysql_result($result_color, 0, "color4");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css"href="script/cal/calendar.css">
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js?v=1"></script>
<script language="JavaScript" type="text/javascript" src="script/cal/calendar_us.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
	</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Course Info</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>  
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>       
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr> 
    </table>    
</td>
    <td align="left" valign="top">
    
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >>  Course management </div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <form name="COURSE" method="post">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
	<input name="language" type="hidden" value="<?=$input_language?>" readonly>	
	<input name="CID" type="hidden" value="" readonly>	
	<input name="UNIT_ID" type="hidden" value="" readonly>	
  <input name="NEW_ACT" type="hidden" value="">	
    <table width="800" border="0" cellspacing="0" cellpadding="3" bgcolor="#CCCC99">
      <tr bgcolor="#FFFFFF">
        <th width="20%" valign="top"><font color="#<?=$color2?>">Course Title: </font></th>
        <td width="80%" valign="top">        
        <input name="COURSE_TITLE" type="text" 
        style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" value="" size="50" maxlength="100">
        </td>
    </tr> 
	<tr bgcolor="#FFFFFF">
	    <th width="20%" valign="top">&nbsp;</th>
        <td width="80%" valign="top" align="right">                
        <input type="submit" value="CREATE NEW COURSE" onclick="subCourse('_admCourseAdd.php','')" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; " onsubmit="">
        </font>
        </td>
     </tr>      
     <tr bgcolor="#FFFFFF">
        <td colspan="2">
        <hr noshade color="#<?=$color2?>" size="2">
     </tr>       
<?php
$query_course = "SELECT * FROM ML_Course ".
								"WHERE ML_Course.LID='".$lid."' ORDER BY ML_Course.CID DESC; ";

$result_course = mysql_query($query_course);
$num_course = mysql_num_rows($result_course);
for ( $i=0 ; $i < $num_course ; $i++)
{
	$cid = mysql_result($result_course, $i, "CID") ;	
	$course_title = mysql_result($result_course, $i, "COURSE_TITLE") ;

  $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$cid."' ; ";
  $result_activation = mysql_query($query_courseActivation);
  $activation = mysql_result($result_activation, 0, "ACTIVATION");

	//chkDate != 0 ---> course has been inactivated
	$strNABG = ($activation == 'A' ) ? '#'.$color3 : '#'.$color4;
	
	$query_courseunit = "SELECT * FROM ML_CourseUnit, ML_Unit ".
			       						"WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
										"AND CID='".$cid."' ORDER BY UNIT_ORDER ; ";	
		
	$result_courseunit = mysql_query($query_courseunit);
	$num_courseunit  = mysql_num_rows($result_courseunit);	

	$strAct = ($activation == 'A') ? "<font color='#<?=$color2?>' size='1' ><b>(COURSE ACTIVATED)</b></font>" : "<font color=#333333 size='1'><b>(COURSE INACTIVED)</b></font>";


?>
    <tr bgcolor="#FFFFFF" id="tr_<?=$cid?>" >
      <td colspan="2" valign="bottom">&nbsp;&nbsp;</td>
    </tr>
	<tr id="course<?=$i?>" style="display:" bgcolor="<?=$strNABG?>">   
    <td colspan="2" valign="top" align="center">
	    <table width="800" border="0" cellspacing="0" cellpadding="0" > 
       	<tr id="course<?=$i?>">
       		<td valign="top" width="650" >
       		<font size="3" face="Verdana" color="#<?=$color2?>"><b><?=$course_title?></b></font>
       		</p><font size="2" color="#<?=$color2?>" ><?=$strAct ?></font>
       		</td>
       		<td width="150"  align="<?=$strTHAlign?>" valign="top"><font size="2">
 	       <input type="submit" value="[+]" onclick="subCourse('_admUpdCourse.php','<?=$cid?>')"
	        style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="edit title and access control">
  	      <input type="button" value="[-]" onclick="preDelete('dc','<?=$cid?>','<?=$i?>')" 
    	    style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="delete course">       	
<?
	if ( $activation == 'A' )
	{
		
?>
  	      <input type="submit" value="[D]" onclick="activate('_admCourseUpd.php','<?=$cid?>','<?=$course_title?>', 'D')"
    	    style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="deactivate this course">       	    	    
<?
	}else{
?>
  	      <input type="submit" value="[A]" onclick="activate('_admCourseUpd.php','<?=$cid?>','<?=$course_title?>', 'A')"
    	    style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="activate this course">   
<?
	}
?>
       		</td>       			
       	</tr>
 		<tr>
    	  <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	   	</tr>          
	   	
       	<tr id="courseunit<?=$i?>" style="display:">
       		<td width="70%" colspan="2" valign="top">
<?
	
	$ifUnitInfo = ($num_courseunit == "0" ) ? "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size='1' color='#383838'>(No unit under course this course.)</font>" : "";


	for ( $j=0 ; $j < $num_courseunit ; $j++)
	{       		
		$uid = mysql_result($result_courseunit, $j, "UNIT_ID") ;	
		$unit_title = trim(mysql_result($result_courseunit, $j, "UNIT_TITLE") );
		$unit_intro = trim(mysql_result($result_courseunit, $j, "UNIT_INTRO") );

		$indexof_AESeperator = strpos($unit_intro, "__________");
		if ( $indexof_AESeperator != "" )
		{
			$unit_intro_A = trim(substr($unit_intro, 0, $indexof_AESeperator)); 	
			$unit_intro = $unit_intro_A;
		}
		
		$len_intro = mb_strlen($unit_intro,'UTF-8');
		$idx_intro = strripos(substr($unit_intro, 0, 300), " " );
		$sub_intro  = ($len_intro > 300 ) ? substr($unit_intro, 0, $idx_intro) : $unit_intro."" ;		
		
		$strMore =  ($len_intro > 300 ) ? "......" : "" ;

		$strUpArrow = ( $j != 0 ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;
		$strDnArrow = ( $j != ( $num_courseunit-1)  ) ? "color: #800000; cursor: pointer;" : "color: #383838;" ;		
		$strUpFunc = ( $j != 0 ) ? "onclick=\"moveUnit('_admUnitOrder.php?FUNC=UP','".$uid."')\" " : "" ;
		$strDnFunc = ( $j != ( $num_courseunit-1)  ) ? "onclick=\"moveUnit('_admUnitOrder.php?FUNC=DN','".$uid."')\" " : "" ;		
?>
       		<table width="100%" border="0" cellspacing="0" cellpadding="0">
       			<tr>
       				<td align="<?=$strTHAlign?>" valign="top" width="50">
	        		<input type="submit" value="up &and; " style="background: <?=$strNABG?>; border-width: 0px; <?=$strUpArrow?> font-size: 7pt; font-family: Verdana;" title="move order upward" <?=$strUpFunc?> ></br>         	
 	        		<input type="submit" value="down &or; " style="background: <?=$strNABG?>; border-width: 0px; <?=$strDnArrow?> font-size: 7pt; font-family: Verdana;" title="move order dowrnward" <?=$strDnFunc?> > </br>           	
       				</td>
       				<td align="<?=$strAlign?>" valign="top">
       				<font size="2"><?=$unit_title?></font></br>
       				<font size="2" face="Verdana" color="#383838"><?=$sub_intro?><?=$strMore?></font>     				
       				</td>
       			</tr>
       			
       		</table>  
			</p> 				
<?
	}
?>
       		</td>       		
       	</tr>
      <tr id="courseunit<?=$i?>_add" style="display:">
        <td colspan="2" align="right" valign="top">
        <input type="submit" value="ADD NEW UNIT" onclick="subCourse('_admAddUnit.php','<?=$cid?>')" 
        style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">  </br></br>      
        </td>
      </tr>
		</table>
	</td>
	</tr>  
    <tr  id="course<?=$i?>_del" style="display: none">
        <td valign="top" colspan="2" align="center"></br>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
        	<td width="80%" align="center" valign="top">
        	<font color="#800000" size="2">You are going to delete the whole course, </br>
        	including the units belong to the course.</font></td>
        	<td width="20%" align="right" valign="top">
       			 <input type="submit" value="CONFIRM" onclick="subCourse('_admCourseDel.php','<?=$cid?>')" 
        			style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana;"></br></br>     			 
       			 <input type="button" value="CANCEL DELETE" onclick="preDelete('cdc','<?=$cid?>','<?=$i?>')" 
        			style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana;">
        	</td>
        </tr>
        </table></br>
        </td>
    </tr> 
      
<?php
}
?>
        </td>
      </tr>
 </table> 
</form>
    </br>
        </td>
      </tr>
 </table>
 	<div <?=$strDirRTL?>  >  	
	</td>
</tr>

    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
