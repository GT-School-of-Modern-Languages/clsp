<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$lid = strtoupper(substr($input_language, 0, 3));
$status = $_REQUEST["STATUS"];
$acid = $_REQUEST["ACID"];

$acc_name = $_REQUEST["ACC_NAME"];
$acc_email = $_REQUEST["ACC_EMAIL"];
$acc_pwd = ( $status != "INS" ) ? $_REQUEST["ACC_PWD"] : "" ;

if ( $acc_pwd == "" ){
	$pwd_length = 10;
	$pwd_characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for ($p = 0; $p < $pwd_length; $p++) {
		$acc_pwd .= $pwd_characters[mt_rand(0, strlen($pwd_characters))];
	}      
}

$strAccess_s = $_REQUEST["ACCESS_START"];
$strAccess_e = $_REQUEST["ACCESS_END"];

$access_s = ($status != "DEL" && $strAccess_s != "" ) ? substr($strAccess_s, 6, 4). "-".substr($strAccess_s, 0, 2)."-".substr($strAccess_s, 3, 2) : date("Y-m-d") ;
$access_e = ($status != "DEL" && $strAccess_e != "" ) ? substr($strAccess_e, 6, 4). "-".substr($strAccess_e, 0, 2)."-".substr($strAccess_e, 3, 2) : "9999-12-31";

switch ($status) {
    case "INS":
		if ( $acc_name != "" ) 
		{ 
	        $query_account = "INSERT INTO ML_CoursePWD VALUES ('','".addslashes($acc_name)."','".addslashes($acc_email)."','".$acc_pwd."','".$lid."','".
        	$access_s."','".$access_e."');" ;
			$acc_result= mysql_query($query_account);
        }
	    break;
    
    case "UPD":
			$query_account = "UPDATE ML_CoursePWD SET ".
			"ACC_NAME = '".addslashes($acc_name)."', ".
			"ACC_EMAIL = '".addslashes($acc_email)."', ".
			"ACC_PWD = '".$acc_pwd."', ".
			"ACCESS_START ='".$access_s."', ".
			"ACCESS_END ='".$access_e."' ".
			"WHERE ACID = '".$acid."'; ";		
			$acc_result= mysql_query($query_account);

	    	break;

    case "DEL":
		$query_courseAccess = "DELETE FROM ML_CourseAccess WHERE CPID = '".$acid."'; ";
		$cacc_result = mysql_query($query_courseAccess);

		$query_account = "DELETE FROM ML_CoursePWD WHERE ACID = '".$acid."'; ";		
		$acc_result= mysql_query($query_account);

	    break;
}

//echo  $query_account;
	
header('Location: _admAccountList.php?language='.$input_language); 
?>