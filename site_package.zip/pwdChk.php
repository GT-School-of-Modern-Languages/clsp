<?php
require ("config.php");
if($_COOKIE['main']!='true'){
        header("Location: index.php");
}
$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$req_pwd = $_REQUEST["PWD"] ;
$req_page = $_REQUEST["PAGE"] ;

$page_href = ""; 

	switch($req_page)	
	{
		case "N": // Culture Notes
			$page_href = "notes.php";
			break;
		case "G":	//Grammar Exercise
			$page_href = "grammar.php";
			break;
		case "Q":	//Questions for Understanding
			$page_href = "understanding.php";
			break;
		case "W":	//Discussion and Writing
			$page_href = "writing.php";
			break;
		case "S": 	//Listening Suggestion
			$page_href = "suggestion.php";
			break;
	}

$query_pwd =  "SELECT * FROM ML_LTPWD WHERE  SID='".$sid."';";
$result_pwd = mysql_query($query_pwd);
$pwd = mysql_result($result_pwd, 0, "PWD");	



if ( $pwd == $req_pwd ) {
	setcookie('password', $pwd,time()+60*60*2);
//	header("Location: ".$page_href ."?ULANGUAGE=".$input_language."&SID=".$sid."&PWD=".$req_pwd); 
	header("Location: ".$page_href ."?ULANGUAGE=".$input_language."&SID=".$sid); 
}
else 
{
	header("Location: pwd.php?ULANGUAGE=".$input_language."&SID=".$sid."&PAGE=".$req_page."&PWD=F"); 
}

?>