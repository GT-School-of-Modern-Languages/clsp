<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$song_num = $_REQUEST["NUM_SONGS"];
$unit_title = $_REQUEST["UNIT_TITLE"] ;
$unit_intro = $_REQUEST["UNIT_INTRO"] ;
$unit_id = $_REQUEST["UNIT_ID"] ;
$cid = $_REQUEST["CID"] ;


if ( $unit_title != "UACCESS_UPD" ){

//echo $unit_intro."</br>";

$query_courseunit = "SELECT * FROM ML_CourseUnit WHERE UNIT_ID='".$unit_id."'; ";
$result_courseunit = mysql_query($query_courseunit);
$num_courseunit  = mysql_num_rows($result_courseunit);

if ( $num_courseunit != "" ){
	if ( $cid == "" ){
		$query_cuDel = "DELETE FROM ML_CourseUnit WHERE UNIT_ID='".$unit_id."'; ";
		$result_cuDel = mysql_query($query_cuDel);	
	}else{
		$query_cuUpd = "UPDATE ML_CourseUnit SET CID='".$cid."' WHERE UNIT_ID='".$unit_id."'; ";
		$result_cuUpd = mysql_query($query_cuUpd);
	}
}else{
	if ( $cid != "" ){
		$query_cuAdd = "INSERT INTO ML_CourseUnit VALUES ('','".$cid."','".$unit_id."'); ";
		$result_cuAdd = mysql_query($query_cuAdd);
	}
}

$num_delete_song = $_REQUEST["NUM_DELETE_SONG"] ;

$lid = strtoupper(substr($input_language, 0, 3));

// ----------------------------------------------------------- update the unit info --------------------------------
$query_updUnit = "UPDATE ML_Unit SET UNIT_TITLE='". addslashes($unit_title) ."', UNIT_INTRO='". addslashes($unit_intro) ."' WHERE UNIT_ID='". $unit_id . "' ;" ;
$result_existUnit = mysql_query($query_updUnit);	

//echo $query_updUnit. "</br>";

// ----------------------------------------------------------- update the old song info ------------------------------
for ( $i = 0 ; $i < 5 ; $i++)
{

	$sid = ( $_REQUEST["SID". $i] != '' ) ? $_REQUEST["SID". $i] : "" ;
	$song_title = ( $_REQUEST["SONG_TITLE". $i] != '' ) ? $_REQUEST["SONG_TITLE". $i] : "" ;
	
	if ( $sid != '' && $song_title !='' )
	{
		$album = $_REQUEST["ALBUM". $i];
		$artist = $_REQUEST["ARTIST". $i];
		$song_overview = $_REQUEST["OVERVIEW". $i];
		$lyrics = $_REQUEST["LYRICS". $i];
	
		$query_updSong = "UPDATE ML_Song ". 
										   "SET SONG_TITLE='". addslashes($song_title) ."',  ALBUM='".  addslashes($album) ."', ARTIST='".  addslashes($artist) ."', SONG_OVERVIEW='". addslashes($song_overview) ."', LYRICS='".  addslashes($lyrics)."' ".
										   "WHERE SID='" . $sid  . "'; ";
		
		$result_updSong = mysql_query($query_updSong);	
	}	
	
// ----------------------------------------------------------- insert the new song info ------------------------------	
	if ( $sid == '' && $song_title !='' )
	{
		$album = $_REQUEST["ALBUM". $i];
		$artist = $_REQUEST["ARTIST". $i];
		$song_overview = $_REQUEST["OVERVIEW". $i];
		$lyrics = $_REQUEST["LYRICS". $i];

		$query_songID = "SELECT MAX(SID) FROM ML_Song WHERE SID LIKE '". $unit_id ."_%'; ";
		$result_songID = mysql_query($query_songID);	
		$row = mysql_fetch_array($result_songID);
		$new_sid = sprintf($unit_id ."_%02d", (intval( substr($row[0], 7, 2) )+1));
		$query_addSong = "INSERT INTO ML_Song VALUES ". 
										   "('". addslashes($new_sid)."', '". addslashes($song_title) ."', '".  addslashes($album) ."', '".  addslashes($artist) ."', '". addslashes($song_overview)."', '".  addslashes($lyrics)."', ".
										   "'/', '-', '-', '-', '-'); ";
		
		$result_addSong = mysql_query($query_addSong);
	
		$query_addSongPWD = "INSERT INTO ML_LTPWD VALUES ('','".$new_sid."', '-'); "; // Password to bypass the notes login		
		$result_addSongPWD = mysql_query($query_addSongPWD);			

		//echo $query_addSong. "</br>";
		//echo $query_addSongPWD. "</br>";	
	}
}

// delete the old song from unit
for ( $i = 0 ; $i < $song_num; $i++)
{
	$delete_sid = $_REQUEST["DELETE_SONG". $i];
	
	if ( $delete_sid != '' ) 
	{
		$query_delSong = "DELETE FROM ML_Song WHERE SID='". $delete_sid ."'; " ;
		$result_delSong = mysql_query($query_delSong);		

		$query_delSongPWD = "DELETE FROM ML_LTPWD WHERE SID='". $delete_sid ."'; " ;
		$result_delSongPWD = mysql_query($query_delSongPWD);		
		
		echo $query_delSong."</br>";
	}
}

}else{ // only upate the unit access control

	$date_start = $_REQUEST["DATE_START"];
	$date_end = $_REQUEST["DATE_END"];
	
/*
	if ( strpos($date_start, "/") == 0 && strpos($date_end, "/") == 0 )
	{
		$date_start = ($date_start != "") ? $date_start : "9999-12-31";
		$date_end = ($date_end != "" ) ? $date_end : "9999-12-31";
	}else{
		$date_start = ($date_start != "") ? substr($date_start, 6, 4). "-".substr($date_start, 0, 2)."-".substr($date_start, 3, 2) : "9999-12-31";
		$date_end = ($date_end != "" ) ? substr($date_end, 6, 4). "-".substr($date_end, 0, 2)."-".substr($date_end, 3, 2) : "9999-12-31";	
	}
*/

	$query_updUnitAccess = "UPDATE ML_UnitAccess SET DATE_START='".$date_start."', DATE_END='".$date_end."' ".								
										" WHERE UNIT_ID='".$unit_id."' ;";
	$result_updUnitAccess = mysql_query($query_updUnitAccess);

	echo $query_updUnitAccess;
}

header('Location: _admUnitList.php?language='.$input_language); 

?>
