<?php
session_start();

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
  header('Location: index.php'); 
}
if(!isset($_SESSION['ACID'])) {
  header("Location: login.php?ULANGUAGE=" . $input_language);
}
$acid = $_SESSION['ACID'];
$_SESSION['ACID'] = $acid;

$lid = strtoupper(substr($input_language, 0, 3));
include 'def/init.php';
require ("config.php");
$link = connectDB();
if (!$link) {
echo "database connection fail!";
exit(-1);
}
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
$query_hid = $_REQUEST["HID"];

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$len_song_title = mb_strlen($song_title,'UTF-8');
$s_song_title  = ($len_song_title > 30 ) ? substr($song_title, 0, 25) . "..." : $song_title ;

$target_dir = "listenings/".  strtoupper(substr($input_language, 0, 3))."/" ;
$target_file = mysql_result($result_song, 0, "FILE_NAME");
$chkEmSong = mysql_result($result_song, 0, "W_OTHER");

$media_av = ( mysql_result($result_song, 0, "W_AUDIO") == "y" ) ? "audio" : 
        ( mysql_result($result_song, 0, "W_VEDIO" == "y" ) ? "video" : "other" );
if ($target_file != "/" ){
$height = 117;
}
else if( $chkEmSong == "y" )
$height = 200;
else
$height=117;
?>
<html>

<!--
<frameset rows="120,*" frameborder="0" border="0" framespacing="0">
  <frame name="topNav" src="header.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>&HID=<?=$hid?>" scrolling="no">
-->
<frameset cols="300,*" frameborder="0" border="0" framespacing="0">
  <frame name="menu" src="leftmenu.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>&HID=<?=$hid?>" marginheight="0" marginwidth="0" scrolling="no" noresize>
<frameset rows="<?=$height?>,*" frameborder="0" border="0" framespacing="0">
  <frame name="video" src="video.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>&HID=<?=$hid?>" marginheight="0" marginwidth="0" scrolling="no" noresize>
<frame name="content" src="understandingTasks.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>&HID=0" marginheight="0" marginwidth="0" scrolling="auto" noresize>
</frameset>
</frameset>
<!--
</frameset>  
-->
</html>
