<?php

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$main_title = $_POST['MAIN_TITLE'];
$contents = $_POST['CONTENTS'];


$query_mainTitle = "UPDATE ML_UI SET TEXT='" . $main_title . "' WHERE NAME='MAIN_TITLE'";
$result_mainTitle = mysql_query($query_mainTitle);

$query_contents = "UPDATE ML_UI SET TEXT='" . $contents. "' WHERE NAME='INTRO_CONTENTS'";
$result_contents = mysql_query($query_contents);


header("Location: _admFront.php");

?>