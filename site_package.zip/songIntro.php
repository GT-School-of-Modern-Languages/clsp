<?php
session_start();

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
  header('Location: index.php'); 
}
if(!isset($_SESSION['ACID'])) {
  header("Location: login.php?ULANGUAGE=" . $input_language);
}
$acid = $_SESSION['ACID'];
$_SESSION['ACID'] = $acid;

require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
//print_r($_REQUEST);

$lid = strtoupper(substr($input_language, 0, 3));
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
$unit_id = substr($sid, 0, 6);

include 'def/init.php';

$query_email="SELECT * FROM ML_FeedbackEM WHERE LANGUAGE='$input_language'";
$result_email=mysql_query($query_email);
$email=mysql_result($result_email,0, "Email");

$_SESSION['email']=$email;

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);


$query_acc_course = "SELECT * FROM ML_Course, ".
                      "(SELECT * FROM ML_CourseAccess ".
                          "WHERE CPID='". $acid ."' ". 
                          "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".   
                          "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                      ") AS courseAccess ". 
                      "WHERE ML_Course.CID=courseAccess.CID AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

$result_acc_course = mysql_query($query_acc_course);
$num_acc_course = mysql_num_rows($result_acc_course);

$song_title = "";
$album = "";
$artist = "";
$overview = "";

if ($num_songs > 0) {
	$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
	$len_song_title = mb_strlen($song_title,'UTF-8');
	//$s_song_title  = ($len_song_title > 30 ) ? substr($song_title, 0, 25) . "..." : $song_title ;

	$idx_intro = strripos(substr($song_title, 0, 25), " " );
	$s_song_title  = ($len_song_title > 25 ) ? substr($song_title, 0, $idx_intro) . "..." : $song_title."" ;		

	$album = mysql_result($result_song, 0, "ALBUM");
	$artist = mysql_result($result_song, 0, "ARTIST");
	$overview = mysql_result($result_song, 0, "SONG_OVERVIEW");
	

	$nextLine = array("\r\n", "\n\r", "\n");
	$overview_body = str_replace($nextLine, "</br>", $overview);
	
//-- song overview content seperation for Arabic

	$overview_A = trim($overview_body);
	$overview_E = "";
	$indexof_AESeperator_overview = strpos($overview_body, "__________");

	if ( $indexof_AESeperator_overview != "" )
	{
		$overview_A = trim(substr($overview_body, 0, $indexof_AESeperator_overview)); 
		$overview_E = trim(substr($overview_body, $indexof_AESeperator_overview+20 ));
	}		
	
	$album = ($album == "" ) ? "" : $album ;
	$artist = ($artist == "" ) ? "" : $artist ;
	$overview_body = ($overview_body == "" ) ? "--" : $overview_body ;
}	

	$query_course = "SELECT * FROM ML_CourseUnit, ML_Course ".
							"WsERE ML_CourseUnit.CID = ML_Course.CID ".
							"AND ML_CourseUnit.UNIT_ID='".$unit_id."' ;";
							
	$result_course = mysql_query($query_course);
	$current_course_title  = mysql_result($result_course, 0, "COURSE_TITLE");
	$current_cid  = mysql_result($result_course, 0, "CID");

	$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$unit_id."'; ";
	$result_unit = mysql_query($query_unit);
	$current_unit_titile  = mysql_result($result_unit, 0, "UNIT_TITLE");

	$strArbColor = ( $input_language == "Arabic" ) ? "#000000" : "#383838" ;
	$strArbColor_introbody = ( $input_language == "Arabic" ) ? "#000000" : "#383838" ;
	$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;

require_once('popup-contactform.php');


?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css" href="css/bluetabs.css" />
<link rel="STYLESHEET" type="text/css" href="popup-contact.css">
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/dropdowntabs.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    	<img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></a></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    	<font size="10" color="black"> </font></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p>
   
<!-- feedback -->
<link href="css/navstyle.php" rel="stylesheet" type="text/css" />
	<ul id="contact">
	<a href='javascript:fg_popup_form("fg_formContainer","fg_form_InnerContainer","fg_backgroundpopup");'><img src="images/mail.jpg" width="90" title="Feedback"></a>
	</ul>

<p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><span class="menu_select"><font color="#<?=$color2?>"><b><?=$s_song_title?></b></font></span></div></td>
      </tr>
<?
$query_numN = "SELECT * FROM ML_ModuleCN WHERE SID='". $sid."' ;";
$result_numN = mysql_query($query_numN);
$num_n = mysql_num_rows($result_numN); 

$query_chkLyrics = "SELECT LYRICS FROM ML_Song WHERE SID='". $sid."' ;";
$result_chkLyrics = mysql_query($query_chkLyrics);
$chkLyrics = mysql_result($result_chkLyrics, 0, "LYRICS");

$num_n = ( $num_n == 0 && $chkLyrics != "" ) ? 1 : $num_n;
				
$query_numQ = "SELECT * FROM ML_ModuleQU WHERE SID='". $sid."' ;";
$result_numQ = mysql_query($query_numQ);
$num_q = mysql_num_rows($result_numQ);			

$query_numL = "SELECT * FROM ML_ModuleLT WHERE SID='". $sid."' ;";
$result_numL = mysql_query($query_numL);
$num_l = mysql_num_rows($result_numL);		

$query_numG = "SELECT * FROM ML_ModuleGE WHERE SID='". $sid."' ;";
$result_numG = mysql_query($query_numG);
$num_g = mysql_num_rows($result_numG);		

$query_numW = "SELECT * FROM ML_ModuleDW WHERE SID='". $sid."' ;";
$result_numW = mysql_query($query_numW);
$num_w = mysql_num_rows($result_numW);					

$query_numS = "SELECT * FROM ML_ModuleLS WHERE SID='". $sid."' ;";
$result_numS = mysql_query($query_numS);
$num_s = mysql_num_rows($result_numS);		

$query_course = "SELECT * FROM ML_CourseUnit, ML_Course ".
                        "WHERE ML_CourseUnit.CID = ML_Course.CID ".
                        "AND ML_CourseUnit.UNIT_ID='".$unit_id."' ;";
                        
$result_course = mysql_query($query_course);
$current_course_title  = mysql_result($result_course, 0, "COURSE_TITLE");
$current_cid  = mysql_result($result_course, 0, "CID");

$lid = strtoupper(substr($input_language, 0, 3));
$query_module_title = "SELECT * FROM ML_ModuleTitle WHERE CID='".$current_cid."' AND LID='".$lid."';";
$result_module_title = mysql_query($query_module_title);
				
$mn_title = ($num_n != 0 ) ? mysql_result($result_module_title, 0, "MODULE_N") : "" ;
$mq_title  = ($num_q != 0 ) ? mysql_result($result_module_title, 0, "MODULE_Q") : "" ;
$ml_title  = ($num_l != 0 ) ? mysql_result($result_module_title, 0, "MODULE_L") : ""  ;
$mg_title  = ($num_g != 0 ) ? mysql_result($result_module_title, 0, "MODULE_G") : ""  ;
$mw_title  = ($num_w != 0 ) ? mysql_result($result_module_title, 0, "MODULE_W") : ""  ;
$ms_title  = ($num_s != 0 ) ? mysql_result($result_module_title, 0, "MODULE_S") : ""  ;

$query_module = "SELECT * FROM ML_Module ORDER BY MOD_INDEX;";
$result_module = mysql_query($query_module);
$num_module = mysql_num_rows($result_module);

for ($i=0 ; $i< $num_module ; $i++){
	$page = mysql_result($result_module, $i, "MOD_PAGE");
	$module = mysql_result($result_module, $i, "MODUEL");
	$moduel_title = "";
	$chkModule = 0 ;

	switch($module)	
	{
		/*
		case "Listening Task":
			$chkModule = $num_l ;
			$moduel_title = $module;
			break;
		case "Culture Notes":
			$chkModule = $num_n ;
			$moduel_title = $module;
			break;
		case "Grammar Exercise":
			$chkModule = $num_g ;		
			$moduel_title = $module;
			break;
		case "Questions for Understanding":
			$chkModule = $num_q ;
			$moduel_title = $module
			break;
		case "Discussion and Writing":
			$chkModule = $num_w ;
			$moduel_title = $module;
			break;
		case "Listening Suggestion": 	
			$chkModule = $num_s ;
			$moduel_title = $module;
			break;
			
			*/
		case "Listening Task":
			
			$chkModule = $num_l ;
			if($ml_title=="")
				$moduel_title = $module;
			else
				$moduel_title= $ml_title;
			break;
		case "Culture Notes":
			$chkModule = $num_n ;
			if($mn_title=="")
				$moduel_title = $module;
			else
				$moduel_title=$mn_title;
			break;
		case "Grammar Exercise":
			$chkModule = $num_g ;	
			if($mg_title=="")	
				$moduel_title = $module;
			else
				$moduel_title=$mg_title;
			break;
		case "Questions for Understanding":
			$chkModule =  $num_q ;
			if($mq_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mq_title;
			break;
		case "Discussion and Writing":
			$chkModule = $num_w ;
			if($mw_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mw_title;
			break;
		case "Listening Suggestion": 	
			$chkModule = $num_s ;
			if($ms_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $ms_title;
			break;
			
	}
	
	if ( $chkModule != 0 ) {
?>
      <tr>
        <td><div class="leftMenu"><a href="<?=$page ?>?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>&HID=0"><span class="menu_head"><font size="<?=$strArbSize?>"><?=$moduel_title?></font></span></a></div></td>
      </tr>
      
      
<?
	}
}
?>   
    </table>

<ul id="nav" >

<?

if($num_acc_course==1){
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {  

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>">Navigation</a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                              "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                              "AND ML_CourseUnit.CID='".$each_cid."' ".
                                              "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);


                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);
                        for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>
    <?}}
}
else{
    ?>
    <li><a href="#">Navigation</a>
        <ul><?

    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;

        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");

        if($activation == 'A') {

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>"><?=$course_title2?></a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                            "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                            "AND ML_CourseUnit.CID='".$each_cid."' ".
                                            "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);

                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);



                         for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>

    <?}}?>
   </ul> 
  </li>




<?}?>
        

</ul>




</td>

    <td align="left" valign="top">
<?php

	$query_unitlist = "SELECT * FROM ML_CourseUnit, ML_Unit ".
   										"WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
										"AND ML_CourseUnit.CID='".$current_cid."' ".					
 										"AND ML_Unit.UNIT_ID like '".$lid."%' ".
										"AND ML_Unit.UNIT_ID != '".$unit_id."' ".													
										"ORDER BY ML_Unit.UNIT_ORDER; ";														
	$result_unitlist = mysql_query($query_unitlist);
	$num_unitlist  = mysql_num_rows($result_unitlist);
	
	$query_songlist = "SELECT * FROM ML_Song WHERE SID LIKE '".$unit_id."_%' AND SID != '".$sid."' ; ";
	$result_songlist = mysql_query($query_songlist);
	$num_songlist  = mysql_num_rows($result_songlist);			
	
	$str_dropunits = ( $num_unitlist != 0 ) ? "rel=\"dropmenu_unit\"": "";
	$str_dropsongs = ( $num_songlist != 0 ) ? "rel=\"dropmenu_song\"": "";

	$str_ulistopen = ( $num_unitlist != 0 ) ? "<font class='box_rotate'>&#8227; </font>" : "";
	$str_slistopen = ( $num_songlist != 0 ) ? "<font class='box_rotate'>&#8227;</font>" : "" ;
?>    
<form name="COURSE_LIST" method="post">	
<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" >
<input name="SID" type="hidden" value="">	
<input name="PWD" type="hidden" value="">		
<input name="UNIT_ID" type="hidden" value="">		

<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	
	  <table width="700" border="0" cellspacing="0" cellpadding="3">
  		<tr>
    		<td>
			<div id="dropmenu" class="bluetabs">
				<ul>
					<li><a href="index.php"><?=$strHP?></a></li>>>			
					<li><a href="courseList.php?ULANGUAGE=<?=$input_language?>"><?=$current_course_title?></a></li>>> 	
					<li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$unit_id?>" <?=$str_dropunits?> ><?=$current_unit_titile?> <?=$str_ulistopen?></a> </li>>> 	
					<li><a <?=$str_dropsongs?> ><?=$song_title?> <?=$str_slistopen?></a> </li>
				</ul>
			</div>    
			<div id="dropmenu_unit" class="dropmenusub">
<?
	if ( $num_unitlist != "0" )
	{
		for ( $j=0 ; $j < $num_unitlist ; $j++)
		{       		
			$unitlist_title = trim(mysql_result($result_unitlist, $j, "UNIT_TITLE") );
			$unitlist_id = mysql_result($result_unitlist, $j, "UNIT_ID") ;
?>			
				<a>
				<input type="submit" value="<?=$unitlist_title?>" title="<?=$unitlist_title?>" style="height: 24px; width: 300px; cursor: pointer; text-align:left; background: #FFFFFF;  border-style:solid; border-width: 1px; border-color:#383838; color: <?=$strArbColor?>; font-size: 9pt; font-family: <?=$FONT_STYLE ?>;" onclick="toUnitIntro('unitList.php', '<?=$unitlist_id?>')" onMouseover="this.style.color='#800000'" onMouseout="this.style.color='<?=$strArbColor?>'" >
				</a>
<?			
			}
		}
?>	
		</div>		
			<div id="dropmenu_song" class="dropmenusub">
<?
	if ( $num_songlist != "0" )
	{
		for ( $s=0 ; $s < $num_songlist ; $s++)
		{       		
			$songlist_title = trim(mysql_result($result_songlist, $s, "SONG_TITLE") );
			$songlist_id = mysql_result($result_songlist, $s, "SID") ;
?>			
				<a>
				<input type="submit" value="<?=$songlist_title?>" title="<?=$songlist_title?>" style="height: 24px; width: 300px; cursor: pointer; text-align:left; background: #FFFFFF;  border-style:solid; border-width: 1px; border-color:#383838; color: <?=$strArbColor?>; font-size: 9pt; font-family: <?=$FONT_STYLE ?>;" onclick="toSongIntro('songIntro.php', '<?=$songlist_id?>')" onMouseover="this.style.color='#800000'" onMouseout="this.style.color='<?=$strArbColor?>'" >
				</a>
<?			
			}
		}
?>	
		</div>				
			<script type="text/javascript">
				tabdropdown.init("dropmenu")
			</script>				
    </br>
    </form>
    </td>
              <td valign="top"><u><a href="logout.php?ULANGUAGE=<?=$input_language?>">logout</a> </u></td>      

  </tr>
  <tr>
    <td align="center" valign="top">
    <form name="SONG_INTRO" method="post">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
    <table width="95%" border="0" cellspacing="0" cellpadding="5">  
      <tr>
        <th colspan="2" valign="top" align="<?=$strAlign?>">
        <font color="<?=$strArbColor?>" size="<?=$strArbSize?>"><?=$song_title?></font>
        </th>
      </tr> 
      <tr>
        <td colspan="2"valign="top">
        <font color="<?=$strArbColor_introbody?>" size="<?=$strArbSize?>"><?=$album?></font>
        </td>
      </tr> 
      <tr>
        <td colspan="2"valign="top">
        <font color="<?=$strArbColor_introbody?>" size="<?=$strArbSize?>"><?=$artist?></font>
        </td>
      </tr> 
      <tr>
        <td width="30" valign="top" align="left">
<?php

	if ( $input_language == "Arabic" && $overview_E != "" )
	{
?>    
        	<input name="btnTrans" id="btnTrans" type="button" onclick="openTrans()" style="border-width: 0px; background-image: url(images/btnTranslation_open.png); background-color:Transparent; width: 30; height: 30; cursor: pointer; " title="translation (below)v"/>
        	<input type="hidden" name="chkOpen" id="chkOpen" value="0" readonly>
<?php
	}
	else
	{
		echo "&nbsp;&nbsp;";
	}

?>    	
        </td>      
        <td valign="top">
        <font color="<?=$strArbColor_introbody?>" size="<?=$strArbSize?>"><?=$overview_A?></font>
        </td>
      </tr>
      <tr id="TLayer" style="display: none">
        <td width="30" valign="top" align="left">&nbsp;&nbsp;</td>    
        <link rel="stylesheet" type="text/css" href="css/style.php" />  
        <td valign="top" dir="ltr">
	        <font color="<?=$strArbColor_introbody?>" size="2"><?=$overview_E?></font>
        </td>
      </tr>       
      <tr>
        <td colspan="2"><hr noshade color="<?=$strArbColor?>" size="3"></td>
      </tr> 
    </table> 
    </form>          
    </td>
  </tr>
</table>
</div>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
	
<?PHP
require_once('contactform-code.php');

?>
</html>
