<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
$color4=mysql_result($result_color, 0, "color4");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body text="black">
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
	</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Unit Info</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>        
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr> 
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >>  Units in <?=$input_language?></div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <form name="UNIT_LIST" method="post">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
	<input name="language" type="hidden" value="<?=$input_language?>" readonly>	
    <input type="hidden" name="NUM_SONGS" value="" readonly>
    <input type="hidden" name="UNIT_ID" value="" readonly>
    <input type="hidden" name="UNIT_TITLE" value="" readonly>    
    <input type="hidden" name="DATE_START" value="" readonly>
    <input type="hidden" name="DATE_END" value="" readonly>        
    <input type="hidden" name="CID" value="" readonly>    
<?php

$query_course = "SELECT * FROM ML_Course WHERE LID='".$lid."'; ";

$result_course = mysql_query($query_course);
$num_course = mysql_num_rows($result_course);

for ( $i=0 ; $i < $num_course ; $i++)
{
	$cid = mysql_result($result_course, $i, "CID") ;	
	$course_title = mysql_result($result_course, $i, "COURSE_TITLE") ;

  $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$cid."' ; ";
  $result_activation = mysql_query($query_courseActivation);
  $activation = mysql_result($result_activation, 0, "ACTIVATION");

	$query_courseunit = "SELECT * FROM ML_CourseUnit, ML_Unit WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
									"AND ML_CourseUnit.CID='".$cid."' ORDER BY ML_Unit.UNIT_ORDER; ";	
	$result_courseunit = mysql_query($query_courseunit);
	$num_courseunit  = mysql_num_rows($result_courseunit);
	
	$query_courseAccess = "SELECT * FROM ML_CourseAccess WHERE CID='".$cid."' ;";

	$result_courseAccess = mysql_query($query_courseAccess);
	$num_courseAccess = mysql_num_rows($result_courseAccess);	
	
	$strDate_S = ( $num_courseAccess != 0 ) ? mysql_result($result_courseAccess, 0, "ML_CourseAccess.DATE_START") : "9999-12-31";
	$strDate_E = ( $num_courseAccess != 0 ) ? mysql_result($result_courseAccess, 0, "ML_CourseAccess.DATE_END") : "9999-12-31" ;

	$date_start = ($strDate_S != "9999-12-31") ?  substr($strDate_S, 5, 2). "/".substr($strDate_S, -2, 2)."/".substr($strDate_S, 0, 4) : "the beginning";
	$date_end = ($strDate_E != "9999-12-31" ) ?  substr($strDate_E, 5, 2). "/".substr($strDate_E, -2, 2)."/".substr($strDate_E, 0, 4) : "the end";	
	
// check if activate
	$query_chkCDate = "SELECT * FROM ML_CourseAccess WHERE CID = " .$cid. " ". 
									"AND DATE_START <= '". date("Y-m-d") . "' ". 	
									"AND DATE_END > '". date("Y-m-d") . "'; "; 									
	
	$result_chkCDate = mysql_query($query_chkCDate);
	$chkCDate = mysql_num_rows($result_chkCDate);		
	
	$strDate_start = ( $chkCDate != 0 ) ? "Can be accessed from ". $date_start : "<font color=#333333>Can be accessed  after activating the course</font>" ;
	$strDate_end = ( $chkCDate != 0 ) ? "through ". $date_end : "" ; 
	$strAct = ($activation == 'A') ? "<font color='#<?=$color2?>' size='1' ><b>(COURSE ACTIVATED)</b></font>" : 
												 "<font color='#333333' size='1' ><b>(COURSE INACTIVED)</b></font>";
?>
  <tr>
    <td><font color='#<?=$color2?>' size='5' family='Verdana'><?=$course_title?></font><p>
    <font size="2" color="#<?=$color2?>" ><?=$strAct ?> </font>
    <hr noshade color="#<?=$color2?>" size="3">
     <div align="right"><input type="submit" value="ADD NEW UNIT" onclick="addCourseUnit('_admAddUnit.php','<?=$cid?>')" title="add new unit to this course"
        style="cursor: pointer; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;"></div>
    </td>
  </tr>
  <tr>
  	<td>
<?php

	for ( $j=0 ; $j < $num_courseunit ; $j++)
	{       		
		$uid = mysql_result($result_courseunit, $j, "UNIT_ID") ;	
		
// check if activate
		$query_chkDate = "SELECT * FROM ML_UnitAccess WHERE UNIT_ID ='" .$uid. "' ". 
									"AND DATE_START <= '". date("Y-m-d") . "' ". 	
									"AND DATE_END > '". date("Y-m-d") . "'; "; 		
									
		$result_chkDate = mysql_query($query_chkDate);
		$chkDate = mysql_num_rows($result_chkDate);		
		
		$strNABG = ($chkDate != 0 ) ? '#'.$color3 : '#'.$color4;

		$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$uid."'; ";
		$result_unit = mysql_query($query_unit);

		$unit_title = trim(mysql_result($result_unit, 0, "UNIT_TITLE") );
		$unit_intro = trim(mysql_result($result_unit, 0, "UNIT_INTRO") );

		$unit_id = $uid;
		
		$query_song = "SELECT * FROM ML_Song WHERE SID like '". $unit_id ."_%'; ";
		$result_song = mysql_query($query_song);
		$num_songs = ( mysql_num_rows($result_song) == "" ) ? "0" : mysql_num_rows($result_song) ;

?>        
     <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="<?=$strNABG?>">
      <tr id="delRow<?=$i?><?=$j?>_1" style="display: none;">
        <td width="80%" align="left" valign="top" colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;
        <font color="#800000" size="2"> This will remove "<?=$unit_title?>" unit and the listening material(s) under it.</font></td>
      </tr>
      <tr id="delRow<?=$i?><?=$j?>_2" style="display: none;">
        <td align="right" colspan="2"> 
        <input type="submit" value="CONFIRM" name="CONFIRM_DELETE_UNIT"  onclick="submitto('_admUnitDel.php?ULANGUAGE=<?=$input_language?>','<?=$num_songs?>','<?=$unit_id?>')" style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
        <input type="button" value="CANCEL" name="CANCEL_DELETE_UNIT" onclick="preDelete('cdu','<?=$unit_id?>','<?=$i?><?=$j?>')" 
        style="cursor: pointer; cursor: hand; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
        </td>
      </tr>
      <tr id="showRow<?=$i?><?=$j?>_1" style="display: ;">
        <td width="80%" align="<?=$strAlign?>" valign="top"><font color="#<?=$color2?>"><b><< <?=$unit_title?> >></b></font></td>
        <td width="20%" align="<?=$strTHAlign?>" valign="top"> 
 	       <input type="submit" value="[+]" title="edit unit and song info" onclick="submitto('_admEditUnit.php','<?=$num_songs?>','<?=$unit_id?>')"
	        style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">
  	      <input type="button" value="[-]" title="delete this unit"  onclick="preDelete('du','<?=$unit_id?>','<?=$i?><?=$j?>')" 
    	    style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;">       
<?
if( $chkCDate != 0 && $chkDate == 0 ){
?>  
  	      <input type="submit" value="[A]" onclick="activateUnit('_admUnitUpd.php','<?=$unit_id?>','UACCESS_UPD','<?=$strDate_S?>','<?=$strDate_E?>')"
    	    style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="activate this unit">    
<?
}
if( $chkCDate != 0 && $chkDate != 0 ){
?>
  	      <input type="submit" value="[D]" onclick="activateUnit('_admUnitUpd.php','<?=$unit_id?>','UACCESS_UPD','9999-12-31','0000-00-00')" style="cursor: pointer; background: <?=$strNABG?>; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="deactivate this unit">   
<?
}
?>
        </td>
      </tr>
      <tr id="showRow<?=$i?><?=$j?>_2" style="display: ;">
        <td colspan="2"><font color="#<?=$color2?>" size="2">Unit Introduction:</font></br>
        <textarea name="UNIT_INTRO"  rows="8" cols="120" readonly style="color: #000000; font-size: 8pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>;background-color: <?=$strNABG?>;"><?=$unit_intro?></textarea>        
        </td>
      </tr>        
      <tr id="showRow<?=$i?><?=$j?>_3" style="display: ;">
        <td width="85%" colspan="2"><font color="#<?=$color2?>" size="2">Listening Material:</font></br>        
        <font size="1" face="Verdana, Geneva, sans-serif" >
<?php
		if ($num_songs != 0 )
		{ 
			for ($ns=0; $ns< $num_songs; $ns++)
			{
				echo "- ". mysql_result($result_song, $ns, "SONG_TITLE") ."</br>";
			}
		}
		else
		{
			echo "<font color='#383838'>( No listening material under this unit. )</font>" ;
		}
?>        
        </font>
        </td>
      </tr>    
  
      <tr id="showRow<?=$i?><?=$j?>_5" style="display: ;"> 
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
      </tr> 
    </table></br>     
   <?php
	}
?>        
        </td>
      </tr>
   <?php
}
?>      
      <tr>
    	<td align="right"> 
        <hr noshade color="#<?=$color2?>" size="3"></br></td>
      </tr>     
 </table>           
    </td>
  </tr> 
</table>
	</form>
	</div>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
