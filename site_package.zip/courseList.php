<?PHP
/*
    Contact Form from HTML Form Guide
    This program is free software published under the
    terms of the GNU Lesser General Public License.
    See this page for more info:
    http://www.html-form-guide.com/contact-form/simple-modal-popup-contact-form.html
*/
//1. First, include the file popup-contactform.php

//2. link to the style file contact.css
?>
<?php
/*if($_COOKIE['main']!='true'){
        header("Location: index.php");
}*/

require ("config.php");
$link = connectDB();
if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location: index.php'); 
}

// Session Check
session_start();
if(!isset($_SESSION['ACID'])) {
  header("Location: login.php?ULANGUAGE=" . $input_language);
}
$acid = $_SESSION['ACID'];
$_SESSION['ACID'] = $acid;


$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';

/*
$query_course = "SELECT * FROM ML_Course, ML_CourseAccess ".
								"WHERE ML_Course.CID = ML_CourseAccess.CID ".
								"AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ". 	
								"AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".											
								"AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";
*/
$query_course = "SELECT * FROM ML_Course WHERE ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

$result_course = mysql_query($query_course);
$num_course = mysql_num_rows($result_course);

/*
$query_acc_course = "SELECT * FROM ML_Course, ML_CourseAccess ".
                      "WHERE ML_CourseAccess.CPID='" . $acid . "' ".
                      "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".   
                      "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                      "AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";
*/

$query_acc_course = "SELECT * FROM ML_Course, ".
                      "(SELECT * FROM ML_CourseAccess ".
                          "WHERE CPID='". $acid ."' ". 
                          "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".   
                          "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                      ") AS courseAccess ". 
                      "WHERE ML_Course.CID=courseAccess.CID AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

$result_acc_course = mysql_query($query_acc_course);
$num_acc_course = mysql_num_rows($result_acc_course);

$strArbColor = ( $input_language == "Arabic" ) ? "#000000" : "#383838" ;
$query_email="SELECT * FROM ML_FeedbackEM WHERE LANGUAGE='$input_language'";
$result_email=mysql_query($query_email);
$email=mysql_result($result_email, 0, "Email");
$_SESSION['email']=$email;

require('popup-contactform.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css" href="css/bluetabs.css" />
<link rel="STYLESHEET" type="text/css" href="popup-contact.css">
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/dropdowntabs.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="250" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
           <img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></a></br>
    </td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    	<font size="10" color="black"> </font></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    
<link href="css/navstyle.php" rel="stylesheet" type="text/css" />
<ul id="contact">
	<a href='javascript:fg_popup_form("fg_formContainer","fg_form_InnerContainer","fg_backgroundpopup");'
><img src="images/mail.jpg" width="90" title="Feedback"></a>
	</ul>
<ul id="nav" >

<?

if($num_acc_course==1){
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {  

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>">Navigation</a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                              "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                              "AND ML_CourseUnit.CID='".$each_cid."' ".
                                              "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);


                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);
                        for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>
    <?}}
}
else{
    ?>
    <li><a href="#">Navigation</a>
        <ul><?

    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;

        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");

        if($activation == 'A') {

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>"><?=$course_title2?></a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                            "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                            "AND ML_CourseUnit.CID='".$each_cid."' ".
                                            "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);

                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);



                         for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>

    <?}}?>
   </ul> 
  </li>




<?}?>
        

</ul>





	</td>   

<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css" href="css/bluetabs.css" /> 
    <td align="center" valign="top">
	<div <?=$strDirRTL?>  >
	<form name="COURSE_LIST" method="post">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
	<input name="UNIT_ID" type="hidden" value="" readonly>	
	<input name="PWD" type="hidden" value="" readonly>		 
	<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	  <tr>
  	  <td align="center" valign="top">      	  
        <table width="700" border="0" cellspacing="0" cellpadding="3">
       	<tr height="30" id="course<?=$lid?>" >
       		<td valign="top">
      			<div id="dropmenu" class="bluetabs">
      				<ul>
      					<li><a href="index.php"><?=$strHP?></a></li>>>			
      				</ul>
    			  </div>    
			      </br>   				
       		</td>  
          <td valign="top"><u><a href="logout.php?ULANGUAGE=<?=$input_language?>">logout</a> </u></td>			
       	</tr> 
        
<?php

for ( $i=0 ; $i < $num_acc_course ; $i++)
{
  $each_cid = mysql_result($result_acc_course, $i, "CID") ;  
  $course_title = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
 
  $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
  $result_activation = mysql_query($query_courseActivation);
  $activation = mysql_result($result_activation, 0, "ACTIVATION");


  if($activation == 'A') {

  ?>
        <tr>
          <td align="center">    
   	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
         	<tr height="30" id="course<?=$i?>" >
         		<th valign="top" align="<?=$strAlign?>" > 
         		<font size="5" color="<?=$strArbColor?>"><?=$course_title?></font>
  	        </br>
         		</th>  			
         	</tr>
         	<tr height="30" id="course<?=$i?>" >
         		<th valign="top" align="center"> <hr noshade color="<?=$strArbColor?>" size="3">
         		</th>  			
         	</tr>
  <?
  	$query_courseunit = "SELECT * FROM ML_CourseUnit, ML_Unit ".
     										"WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
  										"AND ML_CourseUnit.CID='".$each_cid."' ".										
  										"ORDER BY ML_Unit.UNIT_ORDER; ";		
  	$result_courseunit = mysql_query($query_courseunit);
  	$num_courseunit  = mysql_num_rows($result_courseunit);
  	
  	$ifUnitInfo = ($num_courseunit == "0" ) ? "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size='1' color='#383838'>(No unit under this course.)</font>" : "";
  	
  	if ( $num_courseunit == "0" )
  	{
  	?>
         	<tr id="course<?=$i?>_unit">
         		<td valign="top"><?=$ifUnitInfo?></td>       		
         	</tr>	
  	<?
  	}
  	else
  	{
  		for ( $j=0 ; $j < $num_courseunit ; $j++)
  		{       		
  			$uid = mysql_result($result_courseunit, $j, "UNIT_ID") ;	
  		
  			$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$uid."'; ";
  			
  			$result_unit = mysql_query($query_unit);
  			$unit_title = trim(mysql_result($result_unit, 0, "UNIT_TITLE") );

  			$query_chkDate = "SELECT * FROM ML_UnitAccess WHERE UNIT_ID ='" .$uid. "' ". 
  										"AND DATE_START <= '". date("Y-m-d") . "' ". 	
  										"AND DATE_END > '". date("Y-m-d") . "'; "; 		
  									
  			$result_chkDate = mysql_query($query_chkDate);
  			$chkDate = mysql_num_rows($result_chkDate);		
  		
  			$strNABG = ($chkDate != 0 ) ? "#cccc99" : "#cccccc";		
  			
  			if ($chkDate != 0 ) {

  ?>
         	<tr  id="Course<?=$i?>_Unit">
         		<td valign="top">     	 		
         			<font size="3" color="<?=$strArbColor?>"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
         			<?=($j+1)?>. &nbsp;
  	       		<input type="submit" value="<?=$unit_title?>"  title="<?=$unit_title?>" style="font-weight:bold; cursor: pointer; background: #FFFFFF; border-width: 0px; color: <?=$strArbColor?>; font-size: 12pt; font-family: <?=$FONT_STYLE ?>;" onclick="toUnitIntro('unitList.php', '<?=$uid?>')">
         		</td>       		
         	</tr>  	
  <?
  			}
  			else
  			{
  ?>
         	<tr  id="Course<?=$i?>_Unit">
         		<td valign="top">     	 		
         			<font size="3" color="<?=$strArbColor?>"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
         			<?=$j+1?>. &nbsp; <font color="#999" size="2" > (unit closed) </font>
  	       		<input type="button" value="<?=$unit_title?>"  title="<?=$unit_title?>" style="font-weight:bold; background: #FFFFFF; border-width: 0px; color: #999 ; font-size: 12pt; font-family: <?=$FONT_STYLE ?>;" onclick="toUnitIntro('unitList.php', '<?=$uid?>')">
         		</td>       		
         	</tr>  
  <?			
  			}
  		}
    }
?>
		</table> </br>   		    
        </td>
      </tr>
<?php
  }
}
?>
    </table>
        </td>
      </tr>
      </table>
    </form>
   </div>
 </td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
    </table>
    </td>
  </tr> 
</table>
<?PHP
//3. php include contactform-code.php at the end of the page

require_once('contactform-code.php');
?>
</body>
</html>
