<?php
require ("config.php");
$link = connectDB();
if (!$link) {
  echo "database connection fail!";
  exit(-1);
}

$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$query_mainTitle = "SELECT * FROM ML_UI WHERE NAME='MAIN_TITLE'";
$result_mainTitle = mysql_query($query_mainTitle);
$main_title = mysql_result($result_mainTitle, 0, "TEXT");

$query_contents = "SELECT * FROM ML_UI WHERE NAME='INTRO_CONTENTS'";
$result_contents = mysql_query($query_contents);
$intro_contents = mysql_result($result_contents, 0, "TEXT");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Critical Languages Song Project</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
      </td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
      <a href="http://mlg-grant.iac.gatech.edu/"><font size="10" color="black"> </font></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admMain.php"><span class="menu_head">Admin Main Page</span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftMenu"><a href="index.php"><span class="menu_head">Students Main Page</span></a></div></td>
      </tr>   
       <tr>
        <td><div class="leftMenu"><span class="menu_select">Modify Front Page</span></div></td>
      </tr>           
      <tr>
        <td><div class="leftMenu"><a href="_admChangeColor.php"><span class="menu_head">Change Theme</span></a></div></td>
      </tr>    

      <tr>
        <td><div class="leftMenu"><a href="_admBackupFiles.php"><span class="menu_head">Backup UI/DB</span></a></div></td>
      </tr>                  
    </table>
    </td>
    <td align="center" valign="top"><p>&nbsp;</p><p>&nbsp;</p>
      <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
          <td align="center" valign="top" >
            <form name="COURSE" method="post" action="_admEditFrontPage.php">
              <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
              <input name="language" type="hidden" value="<?=$input_language?>" readonly> 
              <input name="CID" type="hidden" value="" readonly>  
              <input name="UNIT_ID" type="hidden" value="" readonly>    
              <table width="800" border="0" cellspacing="0" cellpadding="3" bgcolor="#FFFFFF">
                <tr bgcolor="#FFFFFF">
                  <th width="20%" valign="top"><font color="#<?=$color2?>">Main Title: </font></th>
                  <td width="80%" valign="top">        
                    <input name="MAIN_TITLE" value="<?=$main_title?>" type="text" 
                    style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="50" maxlength="100">
                  </td>
                </tr>

                <tr bgcolor="#FFFFFF">
                  <th width="20%" valign="top"><font color="#<?=$color2?>">Contents/HTML: </font></th>
                  <th width="20%" valign="top"></th>
                  <td width="80%" valign="top"> </td>       
                </tr>  

                <tr bgcolor="#FFFFFF">
                  <th width="20%" valign="top">&nbsp;</th>
                  <th width="10%" valign="top">
                  <textarea name="CONTENTS" rows="30" cols="90"><?=$intro_contents?></textarea></th>
                  <td width="90%" valign="top"> </td>       
                </tr>  

                <tr bgcolor="#FFFFFF">
                  <th width="20%" valign="top">&nbsp;</th>
                  <td width="80%" valign="top" align="right">                
                    <input type="submit" value="Apply Change" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; " >                  
                  </td>
                </tr>      
            
                <tr bgcolor="#FFFFFF">
                  <td colspan="2">
                  <hr noshade color="#<?=$color2?>" size="2">
                </tr>   
              </table>   
            </form>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr height="25" bgcolor="#<?=$color1?>">
    <td align="center" valign="middle">&nbsp;</td>
    <td align="right" valign="middle" >
    <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
    </table>
    </td>
  </tr> 
</table>
</body>
</html>