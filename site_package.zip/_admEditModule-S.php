<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
?>
 <html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<?php

$sid = $_REQUEST["SONG_ID"] ;

$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");
  
$query_song =  "SELECT * FROM ML_Song WHERE SID='".$sid."';";
$result_song = mysql_query($query_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE");	

$query_songLS =  "SELECT * FROM ML_ModuleLS WHERE SID='".$sid."';";
$result_songLS = mysql_query($query_songLS);
$num_ls = mysql_num_rows($result_songLS);

$strSubmit = ( $num_ls == "1" ) ? "_admModuleSUpd.php" : "_admModuleSAdd.php";

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>  
      <tr>      
        <td><div class="leftModule"><a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_L?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_S?></span></div></td>
      </tr>     
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr> 
      <tr> 
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>      
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a>>> Edit List for Further Listening Suggestions</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >

    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
     <Form name="SUGGESTION" method="post">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="CID" type="hidden" value="<?=$cid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">       
     <input name="STATUS" type="hidden" value="0">            
	 <tr>
        <th valign="top" align="center" colspan="2">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr><th align="left">	
   		 <font color="#<?=$color2?>">Further Listening Suggestion for the Song: </font><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>" style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="20" maxlength="100"></br></br>	
        </th></tr>
       	<tr><td >	
		<font color="#800000" size="2"> If there is a link for the listening suggestion, put the link in <b>" &lt;a target="_blank" href="link"&gt; listening &lt;/a&gt;"</b>.
		E.g.  &lt;a artget="_blank" href="http://www.mlg.gatech.edu"&gt; Ruth Benedict &lt;/a&gt;</br></br></font>
		
        <input type="button" value="Click to copy and paste the link template to edit" onclick="cpStyle()" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">	</br></br>	
		<textarea  id="S_CONTENT" name="S_CONTENT"  rows="10" cols="80" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"></textarea>   
        </td></tr>
		</table>               
      	</th>
      </tr>  
      <tr> 
        <td colspan="2" align="right" valign="top">
        <input type="button" value="CLEAR" onclick="clearBD()" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">
        <input type="submit" value="ADD TO INFO" onclick="submittoS('<?=$strSubmit?>')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">
        <input type="submit" value="ADD AS HEADING" onclick="submittoSH('<?=$strSubmit?>')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;
        </td>
      </tr> 
<?php
if ( $num_ls > 0 )
{
	$s_content = mysql_result($result_songLS, 0, "S_CONTENT") ;	
	$numLine = substr_count ($s_content,"\n") ;	
	$subs_content = explode("\n", $s_content );	
	$strTask = ""; 
	for ($line=0; $line <= $numLine; $line++)
	{
		$trim_s_content = trim($subs_content[$line]);
		$strbg = ( $line % 2 == 1) ? "#ECF8E0" : "#DBEADC";

		$strTask .= ( $trim_s_content !="" ) ? 
							( ( substr_count( $trim_s_content, "<h4>" ) == 0 ) ? "<tr bgcolor='".$strbg."'><td><font size='2'>" . $trim_s_content ."</font></td></tr>"  : "<tr><td>".$trim_s_content ."</td></tr>" ) : "";	
	}

?>
    <tr bgcolor="#FFFFFF">
    <td colspan="2" valign="top" align="right" >
        <hr noshade color="#<?=$color2?>" size="1"><font size="2" color="#<?=$color2?>"> Listening Suggestion List:</font>
        <input type="submit" value="[+]" onclick="submittoS('_admEditModule-SUpd.php')" 
        style="cursor: pointer; background: #FFFFFF; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="edit sugestion list">
        <input type="submit" value="[-]" onclick="submittoS('_admModuleSDel.php')"  
        style="cursor: pointer; background: #FFFFFF; border-width: 0px; color: #800000; font-size: 8pt; font-family: Verdana;" title="delete the whole list">
        </td></tr>  
	<tr bgcolor="#FFFFFF">        
    <td colspan="2" valign="top" align="center" >
	    <table width="95%" border="0" cellspacing="3" cellpadding="10"> 

		   		<?=$strTask?>

		</table>
		</br>
	</td>
	</tr>
<?php
}
?>
        </td>
      </tr>
	  </Form>      
      <tr bgcolor="#FFFFFF">
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table></br></br>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>