<?php

require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$unit_id = $_REQUEST["UNIT_ID"] ;
$lid = strtoupper(substr($input_language, 0, 3));
$sid = $_REQUEST["SID"] ;

$file_types = $_REQUEST["FILE_TYPES"] ;
$wPraat = "-";
$wAudio = "-";
$wVedio = "-";
$wOther = "-";



switch($file_types)
{
	case "1":
		$wAudio = "y";
		break;
	case "2":
		$wVedio = "y";
		break;
	case "3":
		$wOther = "y";
		break;
}

if ( $file_types == "-" ) {
	$query_updSong = "UPDATE ML_Song".
							   " SET FILE_NAME='/', W_PRAAT='-', W_AUDIO='-', W_VEDIO='-', W_OTHER='-'" . 
							   " WHERE SID='" . $sid  . "'; ";
	$query_delDetail = "DELETE FROM ML_SongDetail WHERE SID='".$sid."' ;" ;
	$query_delEmbed = "DELETE FROM ML_SongEmbed WHERE SID='".$sid."' ;" ;

	$result_updSong = mysql_query($query_updSong);		
	$result_delDetail = mysql_query($query_delDetail);	
	$result_delEmbed = mysql_query($query_delEmbed);

	header('Location: _admMediaList.php?language='.$input_language); 
}

else if ( $file_types == "1" || $file_types == "2" )	//** Upload audio/vdeo files, update ML_Song, and insert new to ML_SongDetail **//
{

	$file_name = $_FILES["FILE_NAME"]["name"];
	$file_size = $_FILES['FILE_NAME']['size'];
	$mime_type = $_FILES['FILE_NAME']['type'];
	$strErrorCode = $_FILES['FILE_NAME']['error'];

	switch($strErrorCode)
	{
	case "1":
		$strError = "UPLOAD_ERR_INI_SIZE";
		break;
	case "2":
		$strError = "UPLOAD_ERR_FORM_SIZE";
		break;
	case "3":
		$strError = "UPLOAD_ERR_PARTIAL";
		break;
	case "6":
		$strError = "UPLOAD_ERR_NO_TMP_DIR";
		break;
	case "7":
		$strError = "UPLOAD_ERR_CANT_WRITE";
		break;
	case "8":
		$strError = "UPLOAD_ERR_EXTENSION";
		break;
	}

	if($strErrorCode == "4") {
		$query_updSong = "UPDATE ML_Song".
								   " SET FILE_NAME='/', W_PRAAT='-', W_AUDIO='-', W_VEDIO='-', W_OTHER='-'" . 
								   " WHERE SID='" . $sid  . "'; ";
		$query_delDetail = "DELETE FROM ML_SongDetail WHERE SID='".$sid."' ;" ;
		$query_delEmbed = "DELETE FROM ML_SongEmbed WHERE SID='".$sid."' ;" ;

		$result_updSong = mysql_query($query_updSong);		
		$result_delDetail = mysql_query($query_delDetail);	
		$result_delEmbed = mysql_query($query_delEmbed);

		header('Location: _admMediaList.php?language='.$input_language); 
	}

	else {
		$target_dir = "../listenings/".  strtoupper(substr($input_language, 0, 3))."/" ;
		$target_file = $target_dir .  $_FILES['FILE_NAME']['name'];


	// ----------------------------------------------------------- update the song info ------------------------------

		$query_updSong = "UPDATE ML_Song". 
									   " SET FILE_NAME='". addslashes($file_name) ."', W_PRAAT='".  addslashes($wPraat) . "', W_AUDIO='".  addslashes($wAudio) . "', W_VEDIO='".  addslashes($wVedio) . "', W_OTHER='".  addslashes($wOther) . 
									   "' WHERE SID='" . $sid  . "'; ";

	//echo "query_updSong: ".$query_updSong ."</br>";


	// ----------------------------------------------------------- add the song detail ------------------------------
		$query_addSongDetail = "INSERT INTO ML_SongDetail VALUES ('".$sid ."','', '".addslashes($file_name)."', '".$file_size."', '".$mime_type."');" ;

		//echo "query_addSongDetail: ".$query_addSongDetail."</br>";

	// ----------------------------------------------------------- delete song embedded table ------------------------------	

		$query_delEmbed = "DELETE FROM ML_SongEmbed WHERE SID='".$sid."' ;" ;
		$result_delEmbed = mysql_query($query_delEmbed);
		

		if ( move_uploaded_file( $_FILES['FILE_NAME']['tmp_name'], $target_file) )
		{
			$result_updSong = mysql_query($query_updSong);
			$result_addSongDetail = mysql_query($query_addSongDetail);
			//header('Location: _admMediaList.php?language='.$input_language); 
		} else{
			echo "Upload Failed: faild cod <b>".$strError."</b>"; 
			//header('Location: _admMediaErr.php?ULANGUAGE='.$input_language.'&ERR='.$strError); 	
		}

	}
}

else if ( $file_types == "3" )	//** Embedded audio/vdeo, insert/update ML_SongEmbed, check ML_Song and ML_SongDetail **//
{
	$embdvideo = $_REQUEST["EMBDVIDEO"];
	
	if ( $embdvideo == '' || ctype_space($embdvideo) ) {
		$query_updSong = "UPDATE ML_Song".
								   " SET FILE_NAME='/', W_PRAAT='-', W_AUDIO='-', W_VEDIO='-', W_OTHER='-'" . 
								   " WHERE SID='" . $sid  . "'; ";
		$query_delDetail = "DELETE FROM ML_SongDetail WHERE SID='".$sid."' ;" ;
		$query_delEmbed = "DELETE FROM ML_SongEmbed WHERE SID='".$sid."' ;" ;

		$result_updSong = mysql_query($query_updSong);		
		$result_delDetail = mysql_query($query_delDetail);	
		$result_delEmbed = mysql_query($query_delEmbed);

		header('Location: _admMediaList.php?language='.$input_language); 

	}
	else {

		$query_selEmSong = "SELECT * FROM ML_SongEmbed WHERE SID='".$sid."' ;" ;
		$result_selEmSong = mysql_query($query_selEmSong);	
		$num_selEmSong  = mysql_num_rows($result_selEmSong);
		
		if ( $num_selEmSong == "0" )
		{

			$query_updSong = "UPDATE ML_Song". 
										   " SET FILE_NAME='/', W_PRAAT='".  addslashes($wPraat) . "', W_AUDIO='".  addslashes($wAudio) . "', W_VEDIO='".  addslashes($wVedio) . "', W_OTHER='".  addslashes($wOther) . 
										   "' WHERE SID='" . $sid  . "'; ";
			$result_updSong = mysql_query($query_updSong);								   
									   
			$query_addSongEmbed = "INSERT INTO ML_SongEmbed VALUES ('".$sid ."','', '".addslashes($embdvideo)."');" ;
			$result_addSongEmbed = mysql_query($query_addSongEmbed);

			$query_delDetail = "DELETE FROM ML_SongDetail WHERE SID='".$sid."' ;" ;
			$result_delDetail = mysql_query($query_delDetail);	
		}
		else
		{
			$query_updEmSong = "UPDATE ML_SongEmbed SET EMCODE='".  addslashes($embdvideo) . "' WHERE SID='" . $sid  . "'; ";
			$result_updEmSong = mysql_query($query_updEmSong);				
		}
		header('Location: _admMediaList.php?language='.$input_language); 
	}
}

?>