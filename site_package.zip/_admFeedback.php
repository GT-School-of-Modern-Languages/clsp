
<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$nEmail = $_POST[nEmail];
if($nEmail!=""){
	$updateString="Email Updated!";
	$insertQuery="INSERT INTO ML_FeedbackEM(Email,LANGUAGE) VALUES ('$nEmail','$input_language') ON DUPLICATE KEY UPDATE Email=VALUES(Email)";
	mysql_query($insertQuery);

}

$emailquery="SELECT * FROM ML_FeedbackEM WHERE LANGUAGE='$input_language'";
$result_email= mysql_query($emailquery);
$email=mysql_result($result_email, 0, "Email");	
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>   
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></div></td>
      </tr>         
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Feedback</span></a></div></td>
      </tr> 
    </table>    
</td>
    <td align="left" valign="top">
<br/>
<br/>
<font color="#<?=$color2?>" size="5"> Change Email Address </font>
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="position:relative;left:150px;">   
<hr size="3" noshade="" color="#<?=$color2?>">

<tr height = "20" ></tr>
<tr>

<td><?=$updateString?></td>
</tr>
<tr>
<td><font color="#<?=$color2?>">Please Enter Email where Feedback will be sent:</font></td>

</tr>
<tr>
<td>
<form action="" method="post">
<input type="text" name="nEmail" value="<?=$email?>"/>
<input type="submit" value="Update"/>
</form>

</td>
</tr>
</table>
<p style="position:relative;left:150px;color:#<?=$color2?>;font-size:16"/>

</p>
<br/>
<table border="1" cellspacing="0" cellpadding="0" style="position:relative;left:150px;color:#<?=$color2?>">

</table>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
