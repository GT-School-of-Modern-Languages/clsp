<?php
require ("config.php");
$link = connectDB();
if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Critical Languages Song Project</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    	<a href="http://mlg-grant.iac.gatech.edu/"><font size="10" color="black"> </font></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>
        <td><div class="leftMenu"><span class="menu_select">Admin Main Page</span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftMenu"><a href="index.php"><span class="menu_head">Students Main Page</span></a></div></td>
      </tr>   
       <tr>
        <td><div class="leftMenu"><a href="_admFront.php"><span class="menu_head">Modify Front Page</span></a></div></td>
      </tr>           
      <tr>
        <td><div class="leftMenu"><a href="_admChangeColor.php"><span class="menu_head">Change Theme</span></a></div></td>
      </tr>    

      <tr>
        <td><div class="leftMenu"><a href="_admBackupFiles.php"><span class="menu_head">Backup UI/DB</span></a></div></td>
      </tr>      
    </table>
    </td>
    <td align="center" valign="top"><p>&nbsp;</p><p>&nbsp;</p>
        <table width="650" border="0" cellspacing="3" cellpadding="5">
<?


$Name = $_POST[Name];
if ($Name!=""){
	$Name=strtoupper($Name);
	$LID= substr($Name, 0,3);
	$insert_query="INSERT INTO ML_Lang VALUES('$Name', '$LID')";
	mkdir("attachment/".$LID, 0777);
	mysql_query($insert_query);
}
$deleteLan= $_POST[Language];
if($deleteLan!=""){
	$delete_query="DELETE FROM ML_Lang WHERE LANGUAGE='$deleteLan'";
	mysql_query($delete_query);

}
$query = "select LANGUAGE from ML_Lang order by LANGUAGE;" ;
$result = mysql_query($query);



?>

    <form action="" method="post">
New Language: <input type="text" name="Name" />
<input type="submit" value="Add" />
</form>
<br>
<?php
if ( $result != FALSE)
{
	
	$num_rows = mysql_num_rows($result);
	$num_field = mysql_num_fields($result);
	
	if ( $num_rows == 0 )
	{
		print "No results. </br>";
	}
	else
	{
		for ( $i = 0; $i < $num_rows ; $i++ ){
		$language = mysql_result($result, $i);
?>
      <tr>
       <form action="" method="post">
        <td align="center"><font size="6">
        
        <a href="_admCourse.php?language=<?=$language?>"><?=$language?></a>
         </font>
         
         <input type="submit" onclick="return confirm('Are you sure?')" value="Delete"/>
         <input type="hidden" name="Language" value="<?=$language?>">
         </form>
         </td>
      </tr>
<?php
		}
	}
}
?>
    </table>
    </td>
  </tr>
  <tr height="25" bgcolor="#<?=$color1?>">
    <td align="center" valign="middle">&nbsp;</td>
    <td align="right" valign="middle" >
    <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
    </table>
    </td>
  </tr> 
</table>
</body>
</html>