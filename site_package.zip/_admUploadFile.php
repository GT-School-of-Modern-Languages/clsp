
<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>   
<tr>
        <td><div class="leftMenu"><span class="menu_select">File Upload</span></div></td>
      </tr>         
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr> 
    </table>    
</td>
    <td align="left" valign="top">
<br/>
<br/>
<font color="#<?=$color2?>" size="5"> Uploading a file </font>
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="position:relative;left:150px;">   
<hr size="3" noshade="" color="#<?=$color2?>">
<form enctype="multipart/form-data" action="_admUploadFileBack.php" method="POST">
<tr height = "20" ></tr>
<tr>
<td><font color="#<?=$color2?>">Please choose a file:</font></td>
<td> <input name="uploaded" type="file" /></td></tr>
<tr height = "20" ></tr>
<input type="hidden" name="language" value="<?=$input_language?>"/>
<tr><td></td><td><input type="submit" value="Upload" /></td></tr>
</form></tr>
</table>
<p style="position:relative;left:150px;color:#<?=$color2?>;font-size:16"/>
<?php

if ($handle = opendir('upload/')) {
    echo "Files currently in the directory: <br/>\n";
?>
</p>
<br/>
<table border="1" cellspacing="0" cellpadding="0" style="position:relative;left:150px;color:#<?=$color2?>">
<tr>
<th>File name</th>
<!--<th>Date added</th>-->
<th>URL</th>
</tr>
<?
    /* This is the correct way to loop over the directory. */
    while (false !== ($entry = readdir($handle))) {
         if ($entry != "." && $entry != "..") {
	    echo "<tr><td>";
            echo "$entry</td>";
	    //echo "<td>";
	    //echo "</td>";
	    echo "<td>http://www.clsp.gatech.edu/Song_Project/upload/".$entry."</td></tr>";
        }
    }

    closedir($handle);
}
?>
</table>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
