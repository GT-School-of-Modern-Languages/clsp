<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_POST["ULANGUAGE"] ;
$cid = $_POST["CID"] ;

$lid = strtoupper(substr($input_language, 0, 3));

$m_n = $_POST["MODULE_N"];
$m_g = $_POST["MODULE_G"];
$m_q = $_POST["MODULE_Q"];
$m_l = $_POST["MODULE_L"];
$m_w = $_POST["MODULE_W"];
$m_s = $_POST["MODULE_S"];



$query_updMTitle = "UPDATE ML_ModuleTitle SET MODULE_N='". addslashes($m_n) .
								"', MODULE_G='". addslashes($m_g) .
								"', MODULE_Q='". addslashes($m_q) .
								"', MODULE_L='". addslashes($m_l) .
								"', MODULE_W='". addslashes($m_w) .
								"', MODULE_S='". addslashes($m_s) .
								"' WHERE LID='". $lid . "' AND CID='" .$cid. "' ;" ;

echo $query_updMTitle;

$result_updMTitle = mysql_query($query_updMTitle);


header('Location: _admModuleList.php?language='.$input_language); 
?>