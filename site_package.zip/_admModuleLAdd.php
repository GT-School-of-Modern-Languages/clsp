<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"];
$sid = $_REQUEST["SONG_ID"] ;
$l_content = trim($_REQUEST["L_CONTENT"]);
$l_types = ( $_REQUEST["L_TYPES"] == "0" || $_REQUEST["L_TYPES"] == "" ) ? "5" : $_REQUEST["L_TYPES"]; 
$l_option = trim($_REQUEST["L_OPTION"]);
$hid = ( $_REQUEST["HEADING"] == "0"  || $_REQUEST["HEADING"] == "" ) ? "1" : $_REQUEST["HEADING"];

$ans = ($l_types == "8" && strlen(trim($_REQUEST["ANS"])) > 1 ) ? substr(trim($_REQUEST["ANS"]), -1) : trim($_REQUEST["ANS"]) ;
$feedback =  trim($_REQUEST["FEEDBACK"]) ;

$query_num = "SELECT * FROM ML_ModuleLT WHERE SID='".$sid."'; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

$query_addLT = "INSERT INTO ML_ModuleLT VALUES('".$sid."','','".addslashes($l_content)."','".$l_types."','".addslashes($l_option)."','".($num_question+1)."','".$ans."','".addslashes($feedback)."');" ;

$result_addLT = mysql_query($query_addLT);

$query_selLT = "SELECT LID FROM ML_ModuleLT WHERE SID='".$sid."' AND L_CONTENT='".addslashes($l_content)."' ;" ;
$result_selLT = mysql_query($query_selLT);
$lid = mysql_result($result_selLT, 0, "LID") ;


$query_addheadingLT = "INSERT INTO ML_HeadingLT VALUES('".$hid."','".$lid."');" ;
$result_addheadingLT = mysql_query($query_addheadingLT);

echo $query_addLT."</br>";

header('Location: _admEditModule-L.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='.$hid.'&#Q'.$lid); 
?>