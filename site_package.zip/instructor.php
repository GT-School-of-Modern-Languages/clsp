<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>
<?php
	include 'def/init.php';
	echo PJ_HEAD_TITLE;
?>
</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    	<a href="http://www.iac.gatech.edu/" target="_blank"><img src=" " border="0"></a></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    	<a href="http://mlg-grant.iac.gatech.edu/"><img src="images/CSP_title.png" border="0"></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720"><p>&nbsp;</p>
      <p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="index.php"><span class="menu_head">Main Page</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">For Instructors</span></div></td>
      </tr>
    </table></td>
    <td align="center" valign="top"><h2>Welcome Page for other instructors</h2></td>
  </tr>
  <tr height="25" bgcolor="#<?=$color1?>">
    <td align="center" valign="middle"><a href="_admMain.php"><u>Designers' Page</u></a></td>
    <td align="right" valign="middle" >
    <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
  </table>
    </td>
  </tr> 
</table>
</body>
</html>