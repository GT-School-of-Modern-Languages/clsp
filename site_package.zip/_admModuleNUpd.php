<html>
<head>
	
</head>
<body onload="document.forms['redirecting'].submit()">
<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"];
$sid = $_REQUEST["SID"] ;
$nid = $_REQUEST["NID"] ;
$phrase = trim($_REQUEST["PHRASE"] );
$wholeline = trim($_REQUEST["WHOLELINE"] );
$chk_type = $_REQUEST["WHOLELINE"];

$chk_link = ( $_REQUEST["CHK_LINK"] == null ) ? "N" : $_REQUEST["CHK_LINK"] ;
$chk_cont = ( $_REQUEST["CHK_CONT"] == null ) ? "N" : $_REQUEST["CHK_CONT"]; 
$chk_img = ( $_REQUEST["CHK_IMG"] == null ) ? "N" : $_REQUEST["CHK_IMG"]; 
$chk_doc = ( $_REQUEST["CHK_DOC"] == null ) ? "N" : $_REQUEST["CHK_DOC"];

//echo "chk_link: ". $chk_link . ", chk_cont: ". $chk_cont . ", chk_img: ". $chk_img. ", chk_doc: ". $chk_doc ."</br>";


$link = ( trim($_REQUEST["LINK"]) == "" ) ? "" : trim($_REQUEST["LINK"]) ;
$content = ( trim($_REQUEST["CONTENT"]) == "" ) ? "" : trim($_REQUEST["CONTENT"]) ;

//echo $link .", " . $content . "</br>";

$atta_img = ( $_FILES["ATTA_IMG"]["name"] == "") ? "/" : $_FILES["ATTA_IMG"]["name"] ;
$atta_doc = ( $_FILES["ATTA_DOC"]["name"] == "") ? "/" : $_FILES["ATTA_DOC"]["name"] ;
$strErrorCode_img = $_FILES['ATTA_IMG']['error']; 
$strErrorCode_doc = $_FILES['ATTA_DOC']['error']; 
$strError_img = "";
$strError_doc = "";

//echo "atta_img: ". $atta_img . "</br>";

$query_selCN = "SELECT * FROM ML_ModuleCN WHERE  NID='".$nid."'; ";
$result_selCN = mysql_query($query_selCN);

$old_atta_img = mysql_result($result_selCN, 0, "ATTA_IMG") ;	
$old_atta_doc = mysql_result($result_selCN, 0, "ATTA_DOC") ;	
$old_phrase = mysql_result($result_selCN, 0, "PHRASE") ;	
$old_wholeline = mysql_result($result_selCN, 0, "WHOLELINE") ;	

//echo $phrase." and ". $old_phrase . "</br>";

if ( $phrase != $old_phrase || $wholeline != $old_wholeline ) {
	
	$query_selLyrics = "SELECT LYRICS FROM ML_Song WHERE SID='".$sid."'; ";
	$result_selLyrics = mysql_query($query_selLyrics);	
	
	$old_lyrics = mysql_result($result_selLyrics, 0, "LYRICS") ;		
	
	//echo $old_lyrics."</br>";
	
	$new_lyrics = ($phrase != $old_phrase) ? preg_replace("/".$old_phrase."/",$phrase, $old_lyrics) : preg_replace("/".$old_wholeline."/",$wholeline, $old_lyrics) ;
	
	$query_updLyrics = "UPDATE ML_Song SET LYRICS='".addslashes($new_lyrics)."' WHERE SID='".$sid."' ;";
	$result_updLyrics = mysql_query($query_updLyrics);		
	
	//echo $query_updLyrics;
}

$query_updCN = "UPDATE ML_ModuleCN SET PHRASE='".addslashes($phrase)."', WHOLELINE='".addslashes($wholeline)."'";

$query_updCN .= ( $chk_link == "N" ) ? ", CHK_LINK='N', LINK='http://' " : ", CHK_LINK='Y', LINK='".addslashes($link)."'" ;
$query_updCN .= ( $chk_cont == "N" ) ? ", CHK_CONT='N', CONTENT='' " : ", CHK_CONT='Y', `CONTENT`='".addslashes($content)."'" ;


if ( $chk_img == "N" ){
	//unlink("attachment/".  strtoupper(substr($input_language, 0, 3))."/".$old_atta_img);
	$query_updCN .= ", CHK_IMG='N', ATTA_IMG='/', IMG_SIZE='0', IMG_MIME='-' ";
	//echo "unlink old_atta_img. </br>";
}

if ( $chk_doc == "N" ){
	//unlink("attachment/".  strtoupper(substr($input_language, 0, 3))."/".$old_atta_doc);
	$query_updCN .= ", CHK_DOC='N', ATTA_DOC='/', DOC_SIZE='0', DOC_MIME='-' ";
	//echo "unlink old_atta_doc";
}

if ( $chk_img == "Y" && $atta_img != "/"  )
{
	//echo "img not empty. </br>";
	//unlink("attachment/".  strtoupper(substr($input_language, 0, 3))."/".$old_atta_img);

	$atta_file_img = $_FILES["ATTA_IMG"]["name"];
	$atta_size_img = $_FILES['ATTA_IMG']['size'];
	$atta_mime_img = $_FILES['ATTA_IMG']['type'];
		
	$query_updCN .= ", CHK_IMG='Y', ATTA_IMG='".addslashes($atta_file_img)."', IMG_SIZE='".$atta_size_img."', IMG_MIME='".$atta_mime_img."' ";
		
	switch($strErrorCode_img)	
	{
		case "1":
			$strError_img = "UPLOAD_ERR_INI_SIZE";
			break;
		case "2":
			$strError_img = "UPLOAD_ERR_FORM_SIZE";
			break;
		case "3":
			$strError_img = "UPLOAD_ERR_PARTIAL";
			break;
		case "4":
			$strError_img = "UPLOAD_ERR_NO_FILE";
			break;
		case "6":
			$strError_img = "UPLOAD_ERR_NO_TMP_DIR";
			break;
		case "7":
			$strError_img = "UPLOAD_ERR_CANT_WRITE";
			break;
		case "8":
			$strError_img = "UPLOAD_ERR_EXTENSION";
			break;
	}

	$target_dir_img = "attachment/".  strtoupper(substr($input_language, 0, 3))."/" ;
	$target_file_img = $target_dir_img .  $atta_file_img;
	
	if ( move_uploaded_file( $_FILES['ATTA_IMG']['tmp_name'], $target_file_img) )
	{
		//echo "update img ok";
	} else{
		//echo "Upload Failed: faild cod <b>".$strError_img."</b></br>"; 
	}
}
	
if ( $chk_doc == "Y" && $atta_doc != "/" )
{
	//echo "doc not empty. </br>";		
		//unlink("attachment/".  strtoupper(substr($input_language, 0, 3))."/".$old_atta_doc);
		
	$atta_file_doc = $_FILES["ATTA_DOC"]["name"];
	$atta_size_doc = $_FILES['ATTA_DOC']['size'];
	$atta_mime_doc = $_FILES['ATTA_DOC']['type'];
		
	$query_updCN .= ", CHK_DOC='Y', ATTA_DOC='".addslashes($atta_file_doc)."', DOC_SIZE='".$atta_size_doc."', DOC_MIME='".$atta_mime_doc."' ";
		
	switch($strErrorCode_doc)	
	{
		case "1":
			$strError_doc = "UPLOAD_ERR_INI_SIZE";
			break;
		case "2":
			$strError_doc = "UPLOAD_ERR_FORM_SIZE";
			break;
		case "3":
			$strError_doc = "UPLOAD_ERR_PARTIAL";
			break;
		case "4":
			$strError_doc = "UPLOAD_ERR_NO_FILE";
			break;
		case "6":
			$strError_doc = "UPLOAD_ERR_NO_TMP_DIR";
			break;
		case "7":
			$strError_doc = "UPLOAD_ERR_CANT_WRITE";
			break;
		case "8":
			$strError_doc = "UPLOAD_ERR_EXTENSION";
			break;
	}

	$target_dir_doc = "attachment/".  strtoupper(substr($input_language, 0, 3))."/" ;
	$target_file_doc = $target_dir_doc .  $atta_file_doc;
	
	if ( move_uploaded_file( $_FILES['ATTA_DOC']['tmp_name'], $target_file_doc) )
	{
		//echo "update img ok";
	} else{
		//echo "Upload Failed: faild cod <b>".$strError_doc."</b></br>"; 
	}	
}

// ----------------------------------------------------------- update the cn info ------------------------------
$query_updCN .= " WHERE  NID='".$nid."';";
$result_updCN = mysql_query($query_updCN);

//echo $query_updCN;

//header('Location: _admEditModule-N.php?ULANGUAGE='.$input_language.'&SONG_ID='.$sid); -- Old redirection doesnot work
//New redirection to accomodate post parameters
echo "<form name=\"redirecting\" id=\"redirecting\" action=\"./_admEditModule-N.php\" method=\"post\">";

echo "<input type=\"hidden\" name=\"ULANGUAGE\" value=\"".$input_language."\"/>";
echo "<input type=\"hidden\" name=\"CID\" value=\"".$cid."\"/>";
echo "<input type=\"hidden\" name=\"SONG_ID\" value=\"".$sid."\"/>";
echo "</form>";
?>
</body>
</html>
