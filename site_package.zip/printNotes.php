<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php
if($_COOKIE['main']!='true'){
        header("Location: index.php");
}
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$lid = strtoupper(substr($input_language, 0, 3));
include 'def/init.php';

$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
// password check


$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$lyrics = str_replace( "'", "&#39;", trim(mysql_result($result_song, 0, "LYRICS")));	
$lyricswTip = $lyrics;

$patterns = array();
$patterns[0] = '/\'/';
$patterns[1] = '/\"/';				
$patterns[2] = '/[\n\r]{1,2}/';		
$replacements = array();
$replacements[0] = '&#39;';
$replacements[1] = '&#34;';		
$replacements[2] = '</br>';				
$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;
if ($input_language!="Arabic"){
	$strArbSize = ( $input_language == "Chinese" ) ? 4 : 2 ;
	}
?>
<title>Culture Notes:<?=$song_title?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>

  <div align="center">
 
    <table width="85%" border="0" cellspacing="0" cellpadding="3">
	<div <?=$strDirRTL?>  >
    <table width="85%" border="0" cellspacing="0" cellpadding="3" align="center">
   		<tr>
        <th align="<?=$strAlign?>">
			<font size="5" color="#254117" face="Georgia" ><?=$song_title?></font>
        </th>
 		</tr>
  <tr>
    <td align="center" valign="top" >	 
    <table width="100%" border="0" cellspacing="0" cellpadding="3">
      <tr>
        <td align="right" valign="top"><hr noshade color="#254117" size="3"></td>
	 </tr>     
	  <tr>
    <td align="center" valign="top" >
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php
$query_cn = "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' ORDER BY NID; ";
$result_cn = mysql_query($query_cn);
$num_rows = mysql_num_rows($result_cn);

$file_link = "";
$atta_file_desc = "";

$arrPhrase = ""; 
$query_notes = "" ;
$arrNID = "";
$arrNotesNum = "";
$NotesNum = 1;
$arrContent = "";
$arrImgThumb = "";
$strChked_Phrases = " ";

// in this loop, add underline and index "n" 
for ( $i=0 ; $i < $num_rows ; $i++)
{
	$phrase = mysql_result($result_cn, $i, "PHRASE") ;		
	$wholeline = mysql_result($result_cn, $i, "WHOLELINE") ;		

	$lyricswTip = ( $phrase != "" ) ? preg_replace( '/'.$phrase.'/', "<u><font color='#254117'>".$phrase."</font></u><font style='background-color: #FFFFFF;' color='#254117' size='1'><sup>n</sup></font>", $lyricswTip, 1 ) : $lyricswTip;	
}


$numLine = substr_count ($lyrics,"\n") +1;
$sublyrics_tip = explode("\n", $lyricswTip );	
$sublyrics = explode("\n", $lyrics );	

//array to store where phrase are in the lyrics
$phraseArray= array();
$phrArr=array();
for ( $i=0 ; $i < $num_rows ; $i++){
		$phrase = mysql_result($result_cn, $i, "PHRASE");
		$phrArr[]=$phrase;

}

for ($line=0; $line < $numLine; $line++)
{
	$trim_lyrics = trim($sublyrics[$line]);
	foreach ($phrArr as &$phrase){
		$pos = mb_strpos($trim_lyrics, $phrase);
		
		if ($pos !== false){
			$phraseArray[] = array("phrase"=>$phrase, "line"=>$line, "pos"=>$pos);
			$phrase="!!!!!!!";
		}
	}
}
for ($line=0; $line < $numLine; $line++)
{
//	echo ($line+1). "------------------------------------------------";

	$trim_lyrics = trim($sublyrics[$line]);
	$query_line = ($trim_lyrics == "" ) ? "" : "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' AND WHOLELINE='". $trim_lyrics."' ";	
	$result_line = ($trim_lyrics == "" ) ? "" : mysql_query($query_line);
	$chk_wline = ($trim_lyrics == "" ) ? "0" : mysql_num_rows($result_line);
	
// check if the line has phrase or line notes -------------------------------//

	$numPhraseinLine = substr_count($sublyrics_tip[$line],"<sup>n</sup>") ;
	
	if( $numPhraseinLine > 0 ) 	// with phrase(s) in the line
	{
		for ($p=0; $p < $numPhraseinLine; $p++ )	
		{
			//replace index n with actual number
			$sublyrics_tip[$line] = preg_replace( "/<sup>n<\/sup>/", "<sup>[".$NotesNum."]</sup>", $sublyrics_tip[$line],1);
			$NotesNum ++;
		}
		
		$wordinLine = explode(" ", $trim_lyrics );
		//$wordinLine = preg_split('/ /', $trim_lyrics);
		$num_wordinLine = substr_count($trim_lyrics," ") +1; 
		$orderofPhrase = 0 ;
		//phrase in this line
		$phrInLine= array();
		foreach ($phraseArray as &$phrase){
			if ($phrase['line']==$line){
				$phrInLine[]=$phrase;
			}
		}
		//sort phrInLin by position ASC
		$pos= array();
		foreach ($phrInLine as $key => $row)
		{
			$pos[$key] = $row['pos'];
		}
		array_multisort($pos, SORT_ASC, $phrInLine);
		foreach ($phrInLine as $Phr)
		{
			$notePhrase= $Phr['phrase'];
		
		/*
		for ($w=0; $w < $num_wordinLine; $w++ ) 
		{			
			$keyword = ($wordinLine[$w] == "" ) ? "&nbsp;" : rtrim($wordinLine[$w], ",?!.:\"" );
			
			$strQLike = ( strlen($keyword) > 1 ) ? "%" : "" ;
			$query_word = "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' AND PHRASE like '". $keyword . $strQLike. "' ";	
			echo "<br />";
			echo $keyword;
			echo "<br />";

			$result_word = mysql_query($query_word);
			$chk_word = mysql_num_rows($result_word);	//-- $keyword exsist in the CN phraes
			//not true in JAPN
			
			if ( $chk_word != 0 ) {	
	//	echo $chk_word."</br>";
				for ($r=0; $r < $chk_word; $r++ ) 
				{	
					$notePhrase = mysql_result($result_word, $r, "PHRASE");
					$phraseCHKline = preg_match( "/".$notePhrase ."/i" ,$trim_lyrics); //check the word belongs to the phrase
					if( $phraseCHKline == 1 ) {
						break;
					}
				}		
				*/
				$orderofPhrase++;	
				
				$strChked_Phrases .= "+" .$notePhrase;						

				$query_notes = "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' AND PHRASE='". $notePhrase."' ";	
				$result_notes = mysql_query($query_notes);
		
				$chk_link = mysql_result($result_notes, 0, "CHK_LINK") ;	
				$chk_doc = mysql_result($result_notes, 0, "CHK_DOC") ;	
				$chk_img = mysql_result($result_notes, 0, "CHK_IMG") ;	
				$chk_cont = mysql_result($result_notes, 0, "CHK_CONT") ;	
				$link = mysql_result($result_notes, 0, "LINK") ;	
				$content = trim(mysql_result($result_notes, 0, "CONTENT") ) ;	
		
				$atta_img = mysql_result($result_notes, 0, "ATTA_IMG") ;	
				$atta_doc = mysql_result($result_notes, 0, "ATTA_DOC") ;	
				for ($as=0 ; $as < sizeof($arrNID) ; $as++) //as - array size
				{
					if ( $arrNID[$as] == $notePhrase )
					{
						$orderofPhrase -- ;
						break;
					}else{
						$idx_arrNID = $NotesNum - ($numPhraseinLine+1) + $orderofPhrase ;		
						$arrNID[$idx_arrNID] = $notePhrase ;								
						$arrContent[$idx_arrNID] = ($chk_cont == "Y" ) ? $content ."</br></br>" : "" ;						
					}					
				}
			
				if ( $atta_img != "/" )
				{
					$file_link_img = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img;		

					list($width, $height) = getimagesize($file_link_img);
					$thumbW =($width > 100 ) ? 100 : $width ;
					$thumbH = ($width > 100 ) ? (($height/$width)*$thumbW) : $height ;		
			
					$arrImgThumb[$idx_arrNID] = "<img src='".$file_link_img."' width='".$thumbW."' height='".$thumbH."' style='border: 1px solid 	#999999; padding: 3px;'>";							
				}
				else
				{
					$arrImgThumb[$idx_arrNID] = "&nbsp;";
				}
				
				if ( $atta_doc != "/" )
				{
					$file_link_doc = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc;		
				$arrContent[$idx_arrNID] .= "<font color='#333333' size='1'>Related document: <a href='".$file_link_doc."' target='_blank'>". $atta_doc ."</a></font></br>";
				}		
		
				$arrContent[$idx_arrNID] .= ( $chk_link == "Y" ) ? "<font color='#333333' size='1'>Related website: <a href='".$link."' target='_blank'>". $link ."</a></font></br>": "" ;	
				
				
			 				
		}	
	}	

//------------- WHOLELINE AS NOTES ------------------------//

	if ( $chk_wline != 0 ) 

	{	
	
		$strBtn_withLine = ( $chk_wline != 0 )? "<font color='#254117' size='2'>&diams;</font><font 		size='1'><sup>[".$NotesNum."]</sup></font>" : "&nbsp;" ;			        	   
		$strBtn_noLine = "";
		$strBtn_Line = ( $chk_wline != 0 ) ? $strBtn_withLine : "&nbsp;".$strBtn_noLine ;	
	
		$arrNID[$NotesNum] = $trim_lyrics;
		//echo $NotesNum." ".$trim_lyrics."</br>";
		
		$query_notes = "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' AND WHOLELINE='". $trim_lyrics."' ";		
		$result_notes = mysql_query($query_notes);		
			
		$chk_link = mysql_result($result_notes, 0, "CHK_LINK") ;	
		$chk_doc = mysql_result($result_notes, 0, "CHK_DOC") ;	
		$chk_img = mysql_result($result_notes, 0, "CHK_IMG") ;	
		$chk_cont = mysql_result($result_notes, 0, "CHK_CONT") ;	
		$link = mysql_result($result_notes, 0, "LINK") ;	
		$content = trim(mysql_result($result_notes, 0, "CONTENT") ) ;	
		
		$atta_img = mysql_result($result_notes, 0, "ATTA_IMG") ;	
		$atta_doc = mysql_result($result_notes, 0, "ATTA_DOC") ;	
		
		$arrContent[$NotesNum] = ($chk_cont == "Y" ) ? $content ."</br></br>" : "" ;

		if ( $atta_img != "/" )
		{
			$file_link_img = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img;		

			list($width, $height) = getimagesize($file_link_img);
			$thumbW =($width > 100 ) ? 100 : $width ;
			$thumbH = ($width > 100 ) ? (($height/$width)*$thumbW) : $height ;		
			
			$arrImgThumb[$NotesNum] = "<img src='".$file_link_img."' width='".$thumbW."' height='".$thumbH."' style='border: 1px solid #999999; padding: 3px;'>";					
		
		}
		else
		{
			$arrImgThumb[$NotesNum] = "&nbsp;";
		}		
		if ( $atta_doc != "/" )
		{
			$file_link_doc = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc;		
			$arrContent[$NotesNum] .= "<font color='#333333' size='1'>Related document: <a href='".$file_link_doc."' target='_blank'>". $atta_doc ."</a></font></br>";
		}		
		
		$arrContent[$NotesNum] .= ( $chk_link == "Y" ) ? "<font color='#333333' size='1'>Related website: <a href='".$link."' target='_blank'>". $link ."</a></font></br>": "" ;	
		
	}	
	// add index to wholeline note 
	$strBtn_withLine = "&nbsp; <font color='#254117' size='2'>&diams;</font><font color='#254117'  size='1'><sup>[".$NotesNum."]</sup></font>&nbsp;";			        	   
	$strBtn_noLine = "&nbsp;";
	$strBtn_Line = ( $chk_wline != 0 ) ? $strBtn_withLine : $strBtn_noLine;	

	$chkNotesNum = ( $chk_wline != 0 )? $NotesNum ++ : $NotesNum ;
	

       				 if($input_language == "Arabic")
					{
					?>
        			<tr>
        			<td ALIGN="RIGHT"><font color="#000000" size="5"><?=$sublyrics_tip[$line]?></font></td> <!-- print lines here -->
			        
       				 <td width="50" align="left" ><?=$strBtn_Line?></td>
       				 
					<? 
			        
			        }
			        
			        else{
			        
			        ?>
			        <td width="80" align="right" ><?=$strBtn_Line?></td>
			        <td><font color="#000000" size="2"><?=$sublyrics_tip[$line]?></font></td> <!-- print lines here -->
			        <?}?>
			        </tr>
<?
}
?>
 		       </table>   	       
    </td>
    </tr>  
     <tr>
        <td colspan="3" align="right" valign="top"><hr noshade color="#254117" size="3"></td>
      </tr>  
	<tr>        
    <td valign="top" align="center">
	    <table width="85%" border="0" cellspacing="0" cellpadding="5"> 
<?php
//print_r($arrContent)."</br>";
//print_r($arrImgThumb)."</br>"; 

$num_notes = sizeof($arrNID);

for ( $a=1 ; $a <= $num_notes ; $a++)
{
	$bgcolor = ( $a % 2 == 1) ? "#FFFFFF" : "#F7F8E0" ;
	

       	 if($input_language == "Arabic")
		{?>
		<tr bgcolor="<?=$bgcolor?>" align="<?=$strAlign?>" >
       	    
       	<td width="100" valign="top" style="border-bottom: 1px dotted; border-color: #254117;"><?=$arrImgThumb[$a]?></font>
       	</td>   
       	<td valign="top" style="border-bottom: 1px dotted; border-color: #254117;"><font size="2"><?=$arrContent[$a]?></font>
       	</td>
       	<td width="200" valign="top" style="border-left: 1px dotted; border-bottom: 1px dotted; border-color: #254117;">
       	<font size="1">[<?=$a?>] </font><font size="<?=$strArbSize?>"> <?=$arrNID[$a]?></font>
       	</td>        	
        </tr>	
					
			<?		
		}
			        
		else{
			        ?>
       	<tr bgcolor="<?=$bgcolor?>" align="<?=$strAlign?>" >
       	<td width="200" valign="top" style="border-right: 1px dotted; border-bottom: 1px dotted; border-color: #254117;">
       	<font size="1">[<?=$a?>] </font><font size="2"> <?=$arrNID[$a]?></font>
       	</td>
       	<td valign="top" style="border-bottom: 1px dotted; border-color: #254117;"><font size="2"><?=$arrContent[$a]?></font>
       	</td>    
       	<td width="100" valign="top" style="border-bottom: 1px dotted; border-color: #254117;"><?=$arrImgThumb[$a]?></font>
       	</td>           	
        </tr>
        
<?
	}
}
?>
        </table>
	</td>
	</tr>	
      <tr>
        <td colspan="3" valign="top"><hr noshade color="#254117" size="3"></td>
      </tr>        
 </table> 

</div>
</body>
</html>
