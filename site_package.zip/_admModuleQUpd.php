<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SID"] ;
$qid = $_REQUEST["QID"] ;
$hid = ( $_REQUEST["HEADING"] == "0" || $_REQUEST["HEADING"] == "" ) ? "1" : $_REQUEST["HEADING"];
$q_content = trim($_REQUEST["Q_CONTENT"]);
$q_types = $_REQUEST["Q_TYPES"] ;
$q_option = trim($_REQUEST["Q_OPTION"]) ;
$q_types = $_REQUEST["Q_TYPES"] ;
$q_option = trim($_REQUEST["Q_OPTION"]);
$ans = ($q_types == "8" && strlen(trim($_REQUEST["ANS"])) > 1 ) ? substr(trim($_REQUEST["ANS"]), -1) : trim($_REQUEST["ANS"]) ;
$feedback = trim($_REQUEST["FEEDBACK"]);

//echo $_REQUEST["Q_TYPES"] ."</br>";


	switch($q_types)	
	{
		case "1":		//Open-Ended Question
			$q_option = "";
			$ans = "";
			$feedback = "";				
			break;
		case "2": 	//Fill-In Blank Question
			$q_option = "";
			$ans = "";
			$feedback = "";					
			break;
		case "3":		//Multi-Choice Question
			$feedback = "";			
			break;
		case "4":		//Single-Choice Question
			$feedback = "";				
			break;
		case "5":		//Plain Text
			$q_option = "";
			$ans = "";
			$feedback = "";		
			break;						
		case "6": 	//Fill-In Blank Question with feedback
			$q_option = "";
			$ans = "";		
			break;
	}	

// ----------------------------------------------------------- update the qu info ------------------------------

$query_updQU = "UPDATE ML_ModuleQU SET Q_CONTENT='".addslashes($q_content)."', Q_TYPES='".$q_types."', Q_OPTION='".addslashes($q_option)."', ANS='".addslashes($ans)."', FEEDBACK='".addslashes($feedback)."' WHERE QID='".$qid."' ;";
								
$result_updQU = mysql_query($query_updQU);

$query_updHeadingQU = "UPDATE ML_HeadingQU SET HID='".$hid."' WHERE QID='".$qid."' ;";
$result_updHeadingQU = mysql_query($query_updHeadingQU);

//echo $query_updQU."</br>";
//echo $query_updHeadingQU;

header('Location: _admEditModule-Q.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='); 
?>