<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SONG_ID"] ;
$hid = $_REQUEST["HID"] ;
$module = $_REQUEST["MODULE"];
$heading = trim($_REQUEST["HEADING"]);
$submitLocation = "";

switch($module)	
{
	case "QU":		
		$submitLocation = "_admEditHeadingQ"; 
		break;
	case "LT": 
		$submitLocation = "_admEditHeadingL"; 
		break;
	case "GE":	
		$submitLocation = "_admEditHeadingG"; 
		break;
	case "DW":
		$submitLocation = "_admEditHeadingW"; 
		break;
}	



// ----------------------------------------------------------- update the info ------------------------------

$query_updHeading = "UPDATE ML_Heading SET HEADING='".addslashes($heading)."' WHERE HID='".$hid."' ;";
$result_updHeading = mysql_query($query_updHeading);

echo $query_updHeading;

header('Location:'.$submitLocation.'.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
?>