<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$cid = $_REQUEST["CID"] ;

$query_course = "SELECT * FROM ML_Course, ML_CourseAccess ".
								"WHERE ML_Course.CID = ML_CourseAccess.CID ". 									
								"AND ML_Course.CID='".$cid."' ; ";
$result_course = mysql_query($query_course);

$course_title = mysql_result($result_course, 0, "ML_Course.COURSE_TITLE") ;
$strDate_S = mysql_result($result_course, 0, "ML_CourseAccess.DATE_START") ;
$strDate_E = mysql_result($result_course, 0, "ML_CourseAccess.DATE_END") ;

$date_start = ($strDate_S != "9999-12-31") ? substr($strDate_S, 5, 2). "/".substr($strDate_S, -2, 2)."/".substr($strDate_S, 0, 4) : "";
$date_end = ($strDate_E != "9999-12-31" ) ? substr($strDate_E, 5, 2). "/".substr($strDate_E, -2, 2)."/".substr($strDate_E, 0, 4) : "";	
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css"href="script/cal/calendar.css">
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/cal/calendar_us.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Course Info</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>          
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>      
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>          
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admCourse.php?language=<?=$input_language?>">Course management</a> >> Course Info Update</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <form name="COURSE" method="post" action="_admCourseUpd.php">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
	<input name="CID" type="hidden" value="<?=$cid?>" readonly>	
    <table width="100%" border="0" cellspacing="0" cellpadding="3">
      <tr>
        <th width="25%" valign="top"><font color="#<?=$color2?>">Course Title: </font></th>
        <td width="75%" valign="bottom">        
        <input name="COURSE_TITLE" type="text" value="<?=$course_title?>" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>;" size="50" maxlength="100">
        </td>
      </tr>
    	
        <td colspan="2" align="right" valign="top">
        <input type="button" value="CANCEL" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;" onClick="history.back();">
        <input type="submit" value="SUBMIT" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;
        </td>
      </tr> 
        </td>
      </tr>
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </br>
        </td>
      </tr>
 </table>           
	</form>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>