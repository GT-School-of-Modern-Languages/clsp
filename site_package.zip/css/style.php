<?php
header("Content-type: text/css");
include '../def/init.php';
require ("../config.php");

$link = connectDB();
if (!$link) {
echo "database connection fail!";
exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

?>
body {
	background-color: #FFFFFF;
	font-family: Arial, Times, Sans-Serif;
	text-align: center;
	margin: 0px 0px;
	font-size: 10px;
	letter-spacing: 1px;
}
textarea {
    resize: none;
}

.bkadm {
	background-color: #FFFFFF;
	font-family: Verdana, Sans-Serif;
	text-align: left;	
	color:#666;
	font-size: 12px;
}

.diroff {
	background-color: #FFF;
	color:#CCC;	
	border: 1px solid #CCC;		
}

.diroff a {
	color:#CCC;	
}

.diroff a:hover {
	color:#FF8C00;	
}

.diron {
	background-color: #666;
	color:#FFF;	
	border: 1px solid #666;			
}

table.bkadm {
	border-width: 0px;
	border-collapse: separate;
}

table.bkadm th {
	border-width: 0px;
	padding: 3px;
}

table.bkadm td {
	border-width: 0px;
	padding: 3px;
}

A
{
	color: #FF8C00;
	text-decoration: none;
}

.annotation a {
	color: #800000;
	text-decoration: none;
}

.path {
	color: #BDB76B;
	font-size: 8pt;
}

.path a {
	color: #808000;
	font-size: 8pt;
}

.leftMenu {
	background-color: #<?=$color1?>;
	text-align: right;
	padding-top: 15px;
	padding-bottom: 15px;
	padding-right: -5px;
	font-size: 8pt;
}

p
 {
	font-size: 10pt;
 }

h1
 {
	font-family: Helvetica, sans-serif;
	letter-spacing: -2px;
	font-size: 42pt;
	margin-top: 0px;
	margin-bottom: 0px;
	padding-top: 50px;
	padding-bottom: 50px;
 }

 h2
 {
 	color: #BDB76B;
	font-family: Helvetica, sans-serif;
	font-size: 16pt;
	padding-top: 20px;
}

 h3
 {
// 	color: #666600;
	font-family: Optima;
	font-size: 14pt;
}

 h4
 {
 	//color: #808000;	 	
	font-family: Optima;
	font-weight:bold;
	font-size: 11pt;
	padding-top: 10px;
}

// table color onmouseover
.normal { background-color: #000000 }
.normalActive { background-color: #F0E68C }
.lyrics { background-color: #F0E68C }
.lyricsActive { background-color: #F0E68C }

.menu_head
 {
 	color: #383838;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14pt;
	text-decoration: none;
	font-variant: small-caps;
 }
 
.leftMenu a:hover
{
	color: #FF8C00;
	border: none;
	padding: 14px 0px 8px 10px;
	background-color: #FFFFFF;
	text-decoration: none;
	border-top: 3px solid #FFD700;
	border-bottom: 3px solid #FFD700;
	border-left: 3px solid #FFD700;	
}

.menu_select
{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14pt;
	text-decoration: none;
	font-variant: small-caps;
	
	color: #FF9900;
	border: none;
	padding: 10px 0px 8px 10px;
	background-color: #FFFFFF;
	text-decoration: none;
	border-top: 3px solid #FFD700;
	border-bottom: 3px solid #FFD700;
	border-left: 3px solid #FFD700;	

}

/* module menu*/


 .leftModule {
	font-weight:bold;
	background-color: #EEE8AA;
	text-align: right;
	padding-top: 10px;
	padding-bottom: 10px;
	padding-right: 0px;

}

.leftModule a:hover
{
	color: #000000;
	border: none;
	padding: 0px 0px 0px 0px;
	text-decoration: underline;
	font-weight:bold;
}

.module_head
 {
 	color: #000000;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10pt;
	text-decoration: none;
	font-variant: small-caps;
	font-weight:bold;
 }
 
 
.module_select
{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10pt;
	text-decoration: none;
	font-variant: small-caps;
	background-color: #FFFFFF;	
	color: #D2691E;
	font-weight:bold;
	border: none;
	padding: 3px 0px 3px 50px;
	border-top: 3px solid #FFD700;
	border-bottom: 3px solid #FFD700;
	border-left: 3px solid #FFD700;	
	font-weight:bold;
}



/* sub menu */
.submenu_head
 {
 	color: #383838;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12pt;
	text-decoration: none;
 }
 
.subleftMenu a:hover
{
	color: #FF8C00;
	border: none;
	padding: 12px 0px 8px 10px;
	background-color: #FFFFFF;
	text-decoration: none;
	border-top: 1px solid #FFD700;
	border-bottom: 1px solid #FFD700;
	border-left: 1px solid #FFD700;	
}

.submenu_select
{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12pt;
	text-decoration: none;
	font-variant: small-caps;
	
	color: #FF8C00;
	border: none;
	padding: 10px 0px 8px 10px;
	background-color: #FFFFFF;
	text-decoration: none;
	border-top: 3px solid #FFD700;
	border-bottom: 3px solid #FFD700;
	border-left: 3px solid #FFD700;	

}

.lyrics
{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10pt;
	text-decoration: none;
}

/* langlist Start */

#page_menu {
	margin : 0px auto;
	width : 880px;
	height : 50px;
	float : none;
	clear : both;
	text-align : center;
}


/* langlist Detail */

#langlist {
	margin: 0 auto;
	padding: 20px 0 0 0;
	height: 25px;
	border-bottom: 3px solid #808000;
	font-weight:bold;
	font-variant: small-caps;
}

#langlist ul {
	margin: 0;
	padding: 0;
	list-style: none;
}

#langlist li {
	display: inline;

}

#langlist a {
	display: block;
	float: left;
	height: 20px;
	margin: 0px 3px 0px 0px;
	padding: 5px 15px 0 15px;
	
	text-decoration: none;
	font-size: 13px;
	color: #808000;
	
}

#langlist a:hover {
    background: #BDB76B;
	color: #FFFFFF;
}

#langlist .current_page_item a {
	color: #ffffff;
	background: #808000;
}

/* nextBtn Detail */

#nextBtn {
	margin: 0 auto;
	padding: 0 0 0 0;
	height: 25px;
	border-top: 3px solid #808000;
	font-weight:bold;
	font-variant: small-caps;


}

#nextBtn ul {
	margin: 0;
	padding: 0;
	list-style: none;
}

#nextBtn li {
	display: inline;
	float: right;
}

#nextBtn a {
	display: block;
	float: left;
	height: 20px;
	margin: 0px 3px 0px 0px;
	padding: 5px 15px 0 15px;
	background: #808000;	
	text-decoration: none;
	font-size: 13px;
	color: #FFFFFF;
	
}

#nextBtn a:hover {
    background: #BDB76B;
	color: #FFFFFF;
}


/* Copyrights about ML pages*/
.rights
 {
	font-family: Arial, Helvetica, sans-serif;
	color: #800000;
	font-size: 8pt;
 }
 

#dialogue #close
{
	position: absolute;
	right: 5px;
	top: 0px;
}

#dialogue #close a
{
	color: #DD0000;
	text-decoration: none;
}

#dialogue
{
	position: absolute;
	
	left: 50%;
	margin-left: -175px;
	top: 100px;
	
	width: 350px;
	padding: 20px;
	
	border: 2px solid #0000DD;
	background-color: #FFFFFF;
	
	z-index: 2000;
}

.box_rotate {
	color: #800000;
	font-size: 11pt;
	-moz-transform: rotate(90deg); 
	-o-transform: rotate(90deg); 
	-webkit-transform: rotate(90deg); 
	-ms-transform: rotate(90deg);  
	transform: rotate(90deg);  
	filter: progid:DXImageTransform.Microsoft.Matrix( M11=0.9914448613738104, M12=-0.13052619222005157,M21=0.13052619222005157, M22=0.9914448613738104, sizingMethod='auto expand');
	zoom: 1;
}
