<?php
header("Content-type: text/css");
include '../def/init.php';
require ("../config.php");

$link = connectDB();
if (!$link) {
echo "database connection fail!";
exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

?>
body {
	font: normal .8em/1.5em Arial, Helvetica, sans-serif;

	
	color: #666;
}

a {
	color: #333;
}
#nav {
	position: absolute;
	bottom: 1px;
	left: 77px;
	padding: 7px 6px 0;
	background: #<?=$color2?>  repeat-x 0 -110px;
	line-height: 100%;

	border-radius: 2em;
	-webkit-border-radius: 2em;
	-moz-border-radius: 2em;
/*
	-webkit-box-shadow: 0 1px 3px rgba(0,0,0, .4);
	-moz-box-shadow: 0 1px 3px rgba(0,0,0, .4);
*/
}
#nav li {
	margin: 0 5px;
	padding: 0 0 8px;
	float: left;
	position: relative;
	list-style: none;
}


/* main level link */
#nav a {
	font-weight: bold;
	font-size:12px;
	color: #<?=$color1?>;
	text-decoration: none;
	display: block;
	padding:  5px 20px;
	margin: 0;

	-webkit-border-radius: 1.6em;
	-moz-border-radius: 1.6em;
/*	
	text-shadow: 0 1px 1px rgba(0,0,0, .3);
*/
}
#nav a:hover {
	

	color: #fff;

}

/* main level link hover */
#nav .current a, #nav li:hover > a {
	
	color: #fff;
	border-top: solid 1px #f8f8f8;
/*
	-webkit-box-shadow: 0 1px 1px rgba(0,0,0, .2);
	-moz-box-shadow: 0 1px 1px rgba(0,0,0, .2);
	box-shadow: 0 1px 1px rgba(0,0,0, .2);

	text-shadow: 0 1px 0 rgba(255,255,255, 1);
*/
}

/* sub levels link hover */
#nav ul li:hover a, #nav li:hover li a {
	background: #<?=$color2?>;
	border: none;
	color: #fff;
	-webkit-border-radius: 1.6em;
	-moz-border-radius: 1.6em;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
}
#nav ul a:hover {
	background: #<?=$color1?> repeat-x 0 -100px !important;
	color: #<?=$color2?> !important;

	-webkit-border-radius: 0;
	-moz-border-radius: 0;
/*
	text-shadow: 0 1px 1px rgba(0,0,0, .1);
*/
}

/* dropdown */
#nav li:hover > ul {
	display: block;
	
}

/* level 2 list */
#nav ul {
	display: none;

	margin: 0;
	padding: 0;
	width: 205px;
	position: absolute;
	bottom:90%;
	left: 0;
	background: #<?=$color2?>  repeat-x 0 0;
	border: solid 1px #<?=$color2?>;

	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	border-radius: 10px;
/*
	-webkit-box-shadow: 0 1px 3px rgba(0,0,0, .3);
	-moz-box-shadow: 0 1px 3px rgba(0,0,0, .3);
	box-shadow: 0 1px 3px rgba(0,0,0, .3);
*/
}
#nav ul li {
	float: none;
	margin: 0;
	padding: 0;
}

#nav ul a {
	font-weight: normal;

/*	text-shadow: 0 1px 0 #fff;
*/
}

/* level 3+ list */
#nav ul ul {
	left: -101px;
	bottom: 0%;
}

/* rounded corners of first and last link */
/*
#nav ul li:first-child > a {
	-webkit-border-top-left-radius: 9px;
	-moz-border-radius-topleft: 9px;

	-webkit-border-top-right-radius: 9px;
	-moz-border-radius-topright: 9px;
}
#nav ul li:last-child > a {
	-webkit-border-bottom-left-radius: 9px;
	-moz-border-radius-bottomleft: 9px;

	-webkit-border-bottom-right-radius: 9px;
	-moz-border-radius-bottomright: 9px;
}
*/
/* clearfix */
#nav:after {
	content: ".";
	display: block;
	clear: both;
	visibility: hidden;
	line-height: 0;
	height: 0;
}
#nav {
	display: inline-block;
} 
html[xmlns] #nav {
	display: block;
}
 
* html #nav {
	height: 1%;
}

