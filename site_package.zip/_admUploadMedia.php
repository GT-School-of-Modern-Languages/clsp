<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>_admUploadMedia.php</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php
$unit_id = $_POST["UNIT_ID"] ;
$sid = $_POST["SONG_ID"] ;

$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID='" . $unit_id ."';" ;
$result_unit = mysql_query($query_unit);
$unit_title = mysql_result($result_unit, 0, "UNIT_TITLE");

$query_song = "SELECT * FROM ML_Song WHERE SID = '" . $sid ."';" ;
$result_song = mysql_query($query_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE");
$file_name = mysql_result($result_song, 0, "FILE_NAME") ;
$file_link = "listenings/".  strtoupper(strtoupper(substr($input_language, 0, 3))) ."/".$file_name;
$wA =  mysql_result($result_song, 0, "W_AUDIO");
$wV=  mysql_result($result_song, 0, "W_VEDIO");
$wO=  mysql_result($result_song, 0, "W_OTHER");

$strSelected_A =  ( $wA == "-" ) ? "" : "selected" ;
$strSelected_V=  ( $wV == "-" ) ? "" : "selected" ;
$strSelected_O=  ( $wO == "-") ? "" : "selected" ;

$strDisplayEm = ( $wO == "y") ? "" : "none" ;
$strDisplayFile = ( $wA == "y" || $wV == "y" ) ? "" : "none" ;

$file_desc = ""; 
$emcode = "";

if ($file_name != "/" )
{ 
	$query_songdetail = "SELECT * FROM ML_SongDetail WHERE SID = '" . $sid ."';" ;
	$result_songdetail = mysql_query($query_songdetail);	
	$num_rows = mysql_num_rows($result_songdetail);	
	
	$file_size = mysql_result($result_songdetail, 0, "FILE_SIZE") ;
	$mime_type = mysql_result($result_songdetail, 0, "MIME_TYPE") ;

	$file_desc = "[".(round($file_size/(1024*1024),2))."MB]";
} 
else 
{
	$query_songembed = "SELECT * FROM ML_SongEmbed WHERE SID = '" . $sid ."';" ;
	$result_songembed = mysql_query($query_songembed);	
	
	$emcode = (mysql_num_rows($result_songembed) != 0 ) ? mysql_result($result_songembed, 0, "EMCODE") : "" ;

}

?>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Media Files</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>          
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>      
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>             
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	 
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admMediaList.php?language=<?=$input_language ?>">Media List in <?=$input_language?></a> >> Update Media file</div></td>
    	</tr>	  
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top">
    	<form name="MediaUpload" method="post" action="_admMediaUpload.php" enctype="multipart/form-data" >
    	<input name="SID" type="hidden" value="<?=$sid?>">
    	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
    	<input name="UNIT_ID" type="hidden" value="<?=$unit_id?>">    
    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
  <tr>
	<td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
  </tr> 
      <tr>
        <td colspan="2"><font color="#<?=$color2?>"><strong> << <?=$unit_title?> >> </strong></font></td>
      </tr> 
      <tr>
        <td width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Song Title:</font></td>
        <td width="75%"><input name="SONG_TITLE" type="text" readonly value="<?=$song_title?>" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 0px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="60" maxlength="100"></td>
      </tr> 
      <tr>
        <td width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Media Type:</font></td>
        <td width="75%">
          <select name="FILE_TYPES" id="FILE_TYPES" style="color: #000000; font-size: 10pt; font-family: Verdana; border-width: 0px; background-color: #<?=$color3?>;" onchange="showFileBox()">
          	<option value="-">(choose)</option>
            <option value="1" <?=$strSelected_A?> >Audio</option>
            <option value="2" <?=$strSelected_V?> >Video</option>
            <option value="3" <?=$strSelected_O?>>Other (Embedded Video)</option>
          </select>        
        </td>
      </tr>
      <tr id="MEDIA_UPLOAD" style="display: <?=$strDisplayFile?>;" >
        <td width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Media File:</font></td>
        <td width="75%"><input name="FILE_NAME" type="file" value="<?=$file_name?>" length="60"
        style="color: #000000; font-size: 8pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="35" maxlength="100"></td>
      </tr>
      <tr id="MEDIA_EMBED" style="display: <?=$strDisplayEm?>;">
        <td width="25%" align="<?=$strTHAlign?>" valign="top">
        	<font color="#<?=$color2?>">Embedded Video:</font></td>
        <td width="75%">
			<textarea name="EMBDVIDEO" id="EMBDVIDEO" rows="8" cols="100"
	        style="color: #000000; font-size: 8pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>;background-color: #<?=$color3?>;"><?=$emcode?></textarea>        
        </td>
      </tr>      
       <tr>
        <td width="25%" valign="top" align="<?=$strTHAlign?>">
        <font color="#<?=$color2?>">Current File:</font>   
        </td>
        <td width="75%">
<?
if ($file_name != "/" )
{ 
?>        
        <font size="2" color="#<?=$color2?>"><a href="<?=$file_link?>" target="_blank"><?=$file_name?></a></font>
        <font size="1" color="#<?=$color2?>"><?=$file_desc?></font>              
<?
}else{
	echo "<font size=\"1\" color=\"#000\">".$emcode."</font></br></br>";
}
?>        
        </td>
      </tr> 
      <tr> 
        <td colspan="2" align="right">
        <input type="button" value="BACK" style="cursor: pointer; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;" onclick="javascript: history.back();">	
        <input type="submit" value="SUBMIT" style="cursor: pointer; background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">    
        </form>  </br>
      </tr> 
      <tr>
        <td colspan="2"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>       
    </table> 
    </td>
  </tr>
</table>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>