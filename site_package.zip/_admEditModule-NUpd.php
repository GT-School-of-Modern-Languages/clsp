<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<?php
$cid = $_REQUEST["CID"];
$sid = $_REQUEST["SONG_ID"] ;
$nid = $_REQUEST["NID"] ;

$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_cn = "SELECT * FROM ML_ModuleCN WHERE  NID='".$nid."'; ";
$result_cn = mysql_query($query_cn);
$wholeline = htmlspecialchars(mysql_result($result_cn, 0, "WHOLELINE"),ENT_QUOTES) ;
$phrase = mysql_result($result_cn, 0, "PHRASE") ;

$edit_one = ( $wholeline != "" ) ? $wholeline : $phrase ;

$chk_link = mysql_result($result_cn, 0, "CHK_LINK") ;
$chk_doc = mysql_result($result_cn, 0, "CHK_DOC") ;
$chk_img = mysql_result($result_cn, 0, "CHK_IMG") ;
$chk_cont = mysql_result($result_cn, 0, "CHK_CONT") ;

$link = mysql_result($result_cn, 0, "LINK") ;	
$content = trim(mysql_result($result_cn, 0, "CONTENT") ) ;	

$chked_link = ( $chk_link =="Y" ) ? "checked" : "" ;
$chked_doc = ( $chk_doc =="Y" ) ? "checked" : "" ;
$chked_img = ( $chk_img =="Y" ) ? "checked" : "" ;
$chked_cont = ( $chk_cont =="Y" ) ? "checked" : "" ;

$atta_file_desc = ( $chk_img == "Y" || $chk_doc == "Y" ) ? "" : "<font color='#383838' size='2'>(no attachment under: ".$edit_one.")</font>";

$atta_img = mysql_result($result_cn, 0, "ATTA_IMG") ;	
$img_size = mysql_result($result_cn, 0, "IMG_SIZE") ;	
	$img_size = ( round($img_size/(1024*1024),2) < 1 ) ? round($img_size/(1024),2). " KB" : round($img_size/(1024*1024),2). "MB";
$img_mime = mysql_result($result_cn, 0, "IMG_MIME") ;	
$atta_doc = mysql_result($result_cn, 0, "ATTA_DOC") ;	
$doc_size = mysql_result($result_cn, 0, "DOC_SIZE") ;	
	$doc_size = ( round($doc_size/(1024*1024),2) < 1 ) ? round($doc_size/(1024),2). " KB" : round($doc_size/(1024*1024),2). "MB";
$doc_mime = mysql_result($result_cn, 0, "DOC_MIME") ;	

if ( $chk_img == "Y" )
{
	$file_link_img = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img;		
	$atta_file_desc .= "<a href='".$file_link_img."' target=\"_blank\"><b>".$atta_img."</b></a><font size='1'>&nbsp;[".$img_mime.", ". $img_size ."] </font></br>";				
}
if ( $chk_doc == "Y" )
{
	$file_link_doc = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc;		
	$atta_file_desc .= "<a href='".$file_link_doc."' target=\"_blank\"><b>".$atta_doc."</b></a><font size='1'>&nbsp;[".$doc_mime.", ". $doc_size ."] </font></br>";				
}

$strDisplay_line = ( $wholeline != "" ) ? "" : "none" ;
$strDisplay_phrase = ( $phrase != "" ) ? "" : "none" ;	
$strDisplay_link = ( $chk_link == "Y" ) ? "" : "none" ;
$strDisplay_cont = ( $chk_cont == "Y" ) ? "" : "none" ;	
$strDisplay_img = ( $chked_img == "checked" ) ? "" : "none" ;
$strDisplay_doc = ( $chked_doc == "checked" ) ? "" : "none" ;		

?>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_L?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr>  
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>         
      <tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>     
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
  	<div <?=$strDirRTL?>  >  		
	  <table width="800" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a>>> <a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>">Edit Culture Notes </a>>> Edit Key Phrase <b><?=$edit_one?></b></div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td align="center" valign="top" >

    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
     <form name="NOTES_UPD" id="chkForm" method="post" enctype="multipart/form-data" action="_admModuleNUpd.php">
     <input name="CID" type="hidden" value="<?=$cid?>">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="NID" type="hidden" value="<?=$nid?>">     
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
     <input name="WHOLELINE" type="hidden" value="<?=$wholeline?>">     
     <input name="PHRASE" type="hidden" value="<?=$phrase?>">          
	 <tr id="showLine" style="display: <?=$strDisplay_line?>">
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Key Phrase:</font></th>
        <td width="85%">
        <input name="WHOLELINE" type="text" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="<?=$wholeline?>" size="50" maxlength="64">
        <input type="submit" value="Modifiy the Lyrics" onclick="subUnitUpd('_admCourse.php')" 
        style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">           
        </td>
      </tr> 
	 <tr id="showPhrase" style="display: <?=$strDisplay_phrase?>">
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Key Phrase:</font></th>
        <td width="85%">
        <input name="PHRASE" type="text" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="<?=$phrase?>" size="30" maxlength="64">
        </td>
      </tr> 
	 <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Type:</font></th>
        <td width="85%"><font size="2" color="#<?=$color2?>">
	     <input id="chk_value1" name="CHK_LINK" type="hidden" value="<?=$chk_link?>">
    	 <input id="chk_value2" name="CHK_CONT" type="hidden" value="<?=$chk_cont?>">       
	     <input id="chk_value3" name="CHK_IMG" type="hidden" value="<?=$chk_img?>">
    	 <input id="chk_value4" name="CHK_DOC" type="hidden" value="<?=$chk_doc?>">
        <label><input id="chk1" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(1)" <?=$chked_link?> >&nbsp;Outer Link</label></br>
        <label><input id="chk2" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(2)" <?=$chked_cont?> >&nbsp;Usage Description</label></br>
        <label><input id="chk3" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(3)" <?=$chked_img?> >&nbsp;Mouse-over Image</label></br>
        <label><input id="chk4" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(4)" <?=$chked_doc?> >&nbsp;Related Document</label></br>
      	</font></td>
      </tr> 
       <tr id="input1" style="display: <?=$strDisplay_link?>;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Link:</font></th>
        <td width="75%">
		<textarea name="LINK"  rows="2" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$link?></textarea>        
        </td>
      </tr>       
       <tr id="input2" style="display: <?=$strDisplay_cont?>;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Description:</br></font></th>
        <td width="75%">
		<textarea name="CONTENT"  rows="5" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$content?></textarea>        
        </td>
      </tr>   
       <tr  id="input3" style="display: <?=$strDisplay_img?>;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Image File:</font></th>
        <td width="75%">
        <input name="ATTA_IMG" type="file" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="45">         
        </td>
      </tr> 
       <tr id="input4" style="display: <?=$strDisplay_doc?>; ">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Document File:</font></th>
        <td width="75%">
        <input name="ATTA_DOC" type="file" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="45">         
        </td>
      </tr> 
       <tr>
        <td width="25%" align="<?=$strTHAlign?>" valign="top"><font size="2" color="#<?=$color2?>">Current attachment: </td>
        <td width="75%"><font size="2" color="#<?=$color2?>"><?=$atta_file_desc?></font>
        </td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>             
      <tr> 
        <td colspan="2" align="right" valign="top">
        <input type="reset" value="CANCEL" onclick="history.back()" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">
        <input type="submit" value="UPDATE" onclick="submittoN('_admModuleNUpd.php')" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">
    	</form>  </br></br>
        </td>
      </tr> 
    </table> 

    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table>
</br></br></br>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
