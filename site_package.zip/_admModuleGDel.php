<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SID"] ;
$gid = $_REQUEST["GID"] ;

$query_delGE = "DELETE FROM ML_ModuleGE WHERE  SID='".$sid."' AND GID='".$gid."' ;";
$result_delGE = mysql_query($query_delGE);

$query_num = "SELECT * FROM ML_ModuleGE WHERE SID='".$sid."' ORDER BY G_ORDER; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

for ( $j=0 ; $j < $num_question ; $j++)
{	
	$qestion_id = mysql_result($result_num, $j, "GID") ;
	$query_updOrder = "UPDATE ML_ModuleGE SET G_ORDER='".($j+1)."' WHERE GID='".$qestion_id."'; ";	
	echo $query_updOrder."</br>";
	$result_updOrder = mysql_query($query_updOrder) or die(mysql_error()); 
}

$query_delHeadingGE = "DELETE FROM ML_HeadingGE WHERE GID='".$gid."' ;";
$result_delHeadingGE = mysql_query($query_delHeadingGE);

echo $query_delGE;

header('Location: _admEditModule-G.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='); 
?>