<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$this_acid = $_REQUEST["ACID"];

$query_thisAccount = "SELECT * FROM ML_CoursePWD WHERE ACID='".$this_acid."'; " ;

$result_thisAccount = mysql_query($query_thisAccount);

$this_acc_name = mysql_result($result_thisAccount, 0, "ACC_NAME") ;
$this_acc_email = mysql_result($result_thisAccount, 0, "ACC_EMAIL") ;
$this_acc_pwd = mysql_result($result_thisAccount, 0, "ACC_PWD") ;	
$this_date_s = mysql_result($result_thisAccount, 0, "ACCESS_START") ;	
$this_date_e = mysql_result($result_thisAccount, 0, "ACCESS_END") ;	

$date_start = ($this_date_s != "9999-12-31") ?  substr($this_date_s, 5, 2). "/".substr($this_date_s, -2, 2)."/".substr($this_date_s, 0, 4) : "";
$date_end = ($this_date_e != "9999-12-31" ) ?  substr($this_date_e, 5, 2). "/".substr($this_date_e, -2, 2)."/".substr($this_date_e , 0, 4) : "";	
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
$color4=mysql_result($result_color, 0, "color4");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css"href="script/cal/calendar.css">
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/cal/calendar_us.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
       <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>  
   	   <tr>
        <td><div class="leftMenu"><span class="menu_select">Account Management</span></div></td>
      </tr>        
		<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>      
    </table>    
	</td>
    <td align="left" valign="top">
    <form name="ACCOUNT" method="post">
    <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>	
    <input name="language" type="hidden" value="<?=$input_language?>" readonly>	 
	<input name="STATUS" type="hidden" value="" readonly>	
	<input name="ACID" type="hidden" value="" readonly>	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">    
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >>  Account management </div></td>
    </tr>
 	<tr>
    	<td><p>&nbsp;</p><p>&nbsp;</p></td>
	</tr>
  	<tr>
    	<td align="center" valign="top" >	
    	<table width="850" border="0" cellspacing="3" cellpadding="3">
   		    <tr bgcolor="#FFFFFF">
		        <td colspan="6"><font color="#<?=$color2?>" size="5">Account(s) for the <?=$input_language?> Courses: </font></td>
			</tr>    
   		    <tr bgcolor="#FFFFFF">
		        <td colspan="6"><hr noshade color="#<?=$color2?>" size="2"></td>
			</tr>  
   		    <tr bgcolor="#FFFFFF">
		        <th><font color="#<?=$color2?>" size="2">Institute Name/Account</font><font size="2" color="#800000"><b><sup>*</sup></b></font></th>
		        <th><font color="#<?=$color2?>" size="2">Email</font></th>
		        <th><font color="#<?=$color2?>" size="2">Password</font></th> 	 
		        <th><font color="#<?=$color2?>" size="2">Access-Start</font></th>
		        <th><font color="#<?=$color2?>" size="2">Access-End</font></th>  
		        <td align="right">&nbsp;&nbsp;</td> 	  	        	
			</tr>  			
   		    <tr bgcolor="#FFFFFF">
		        <th><input name="ACC_NAME" type="text" value="<?=$this_acc_name?>"
        style="color: #000000; font-size: 9pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="40" maxlength="200">
        		</th>
		        <th><input name="ACC_EMAIL" type="text" value="<?=$this_acc_email?>"
        style="color: #000000; font-size: 9pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="25" maxlength="200">
        		</th>
		        <th><input name="ACC_PWD" type="text" value="<?=$this_acc_pwd?>"
        style="color: #000000; font-size: 9pt; font-family: Verdana;border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="10" >    
	        	    
	        	</th> 	 
		        <td><input name="ACCESS_START" type="text" value="<?=$date_start?>"
        style="color: #333; font-size: 9pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" value="" size="10" maxlength="10" >
				<script language="JavaScript">
				new tcal ({ 'formname': 'ACCOUNT', 'controlname': 'ACCESS_START'});
				</script>  		        
		        </td>
		        <td><input name="ACCESS_END" type="text" value="<?=$date_end?>"
        style="color: #333; font-size: 9pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" value="" size="10" maxlength="10">		
	        	<script language="JavaScript">
				new tcal ({ 'formname': 'ACCOUNT', 'controlname': 'ACCESS_END'});
				</script>      
	        	</td>  
		        <td align="right">    
	        	    <input type="submit" value="UPDATE" onclick="subAccount('_admAccountUpd.php','<?=$this_acid?>','UPD')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; " title="update this account">	    
					<input type="button" value="X" onclick="javascript: history.back();" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; " title="cancel update">	        	    
	        	</td> 	  	        	
			</tr>  	
   		    <tr bgcolor="#FFFFFF">
		        <td colspan="6"><hr noshade color="#<?=$color2?>" size="1"></td>
			</tr>
<?
$query_account = "SELECT * FROM ML_CoursePWD WHERE LID='".$lid."' ORDER BY ACID;" ;

$result_account = mysql_query($query_account);
$num_account= mysql_num_rows($result_account);

for ( $i=0 ; $i < $num_account ; $i++)
{
	$acid = mysql_result($result_account, $i, "ACID") ;	
	$acc_name = mysql_result($result_account, $i, "ACC_NAME") ;
	$acc_email = mysql_result($result_account, $i, "ACC_EMAIL") ;
	$acc_pwd = mysql_result($result_account, $i, "ACC_PWD") ;	
	$date_s = mysql_result($result_account, $i, "ACCESS_START") ;	
	$date_e = mysql_result($result_account, $i, "ACCESS_END") ;	
	
	$access_s = ($date_s != "9999-12-31") ?  substr($date_s, 5, 2). "/".substr($date_s, -2, 2)."/".substr($date_s, 0, 4) : "";
	$access_e = ($date_e != "9999-12-31" ) ?  substr($date_e, 5, 2). "/".substr($date_e, -2, 2)."/".substr($date_e, 0, 4) : "--/--/----";		
	
// check if the account activate
	$query_chkDate = "SELECT * FROM ML_CoursePWD WHERE ACID = " .$acid. " ". 
									"AND ACCESS_START <= '". date("Y-m-d") . "' ". 	
									"AND ACCESS_END > '". date("Y-m-d") . "'; "; 									
	
	$result_chkDate = mysql_query($query_chkDate);
	$chkDate = mysql_num_rows($result_chkDate);	
	
	//chkDate != 0 ---> course has been inactivated
	$strNABG = ($chkDate != 0 ) ? '#' . $color3 : '#' . $color4;		
?>			
   		    <tr id="account<?=$i?>" style="display:"  bgcolor="<?=$strNABG?>" onMouseover="this.bgColor='#<?=$color2?>'" onMouseout="this.bgColor='<?=$strNABG?>'">
		        <td><font size="1"><?=$acc_name?></font></th>
		        <td><font size="1"> <?=$acc_email?></font></th>
		        <td><font size="1"><?=$acc_pwd?></font></th> 	 
		        <td><font size="1"><?=$access_s?></font></th>
		        <td><font size="1"><?=$access_e?></font></th>
		        <td align="right" bgcolor="#FFFFFF">
 			       <input type="submit" value="[+]" onclick="subAccount('_admUpdAccount.php','<?=$acid?>','UPD')" onMouseover="this.style.color='#800000'" onMouseout="this.style.color='#<?=$color2?>'" style="cursor: pointer; background: #FFFFFF; border-width: 0px; color: #<?=$color2?>; font-size: 8pt; font-family: Verdana;" title="edit">
	  	    	  <input type="button" value="[-]" onclick="preDelete('da','<?=$acid?>','<?=$i?>')" onMouseover="this.style.color='#800000'" onMouseout="this.style.color='#<?=$color2?>'" style="cursor: pointer; background: #FFFFFF; border-width: 0px; color: #<?=$color2?>; font-size: 8pt; font-family: Verdana;" title="delete">     		        
		        </td> 	  	        	
			</tr>
   		    <tr id="account<?=$i?>_del" style="display: none" bgcolor="#<?=$color2?>" height="15">
		        <td colspan="5" align="center">
			        <font size="1">Delete <b>"<?=$acc_name?>"</b> from accessing the <?=$input_language?> Courses.</font>
			         &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
    	   			 <input type="submit" value="CONFIRM" onclick="subAccount('_admAccountUpd.php','<?=$acid?>','DEL')" title="delete this account"
        			style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana; text-decoration:underline">    			 
       				 <input type="button" value="CANCEL DELETE" onclick="preDelete('cda','<?=$acid?>','<?=$i?>')" title="go back to account list"
        			style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #800000; font-size: 6pt; font-family: Verdana; text-decoration:underline">		        
		        </br></br>
		        </td>
		        <td bgcolor="#FFFFFF">&nbsp;&nbsp;</td>		        
			</tr> 			
 <?
}

$strNoAccount = ( $num_account == 0 ) ? "No account created in ". $input_language ." courses." : "";
echo "<font sizze='2'>". $strNoAccount . "</font>" ;
 
 ?>  		 
   		    <tr bgcolor="#FFFFFF">
		        <td colspan="6"><hr noshade color="#<?=$color2?>" size="1"></td>
			</tr> 	
   		    <tr bgcolor="#FFFFFF">
		        <td colspan="6">
		        <font size="1">
		        	<font color="#800000"><b>*</b></font> Institute Name/Account column CAN NOT be blank. </br>
		        	** if the Password column left blank, system will generate a series of 10 digits random letters or numbers automatically.</br>
		        	*** If the Access dates left blank, the default start date will be the day the account created, and no end date.
		        </font>
		        </td>
			</tr> 			
 		</table> 
 		
		</td>
	</tr>
 	<tr>
    	<td><p>&nbsp;</p><p>&nbsp;</p></td>
	</tr>
</table>
</td>
</tr>
</table>
</form>
</td>
</tr>
<tr>
<td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
</tr>
</table>
</body>
</html>