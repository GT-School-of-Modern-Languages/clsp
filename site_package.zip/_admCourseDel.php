<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["language"];
$cid = $_REQUEST["CID"];
$uid = strtoupper(substr($input_language, 0, 3));



// ----------------------------------------------------------- delete info ------------------------------

$query_delCourse = "DELETE FROM ML_Course WHERE CID='".$cid."' ;";
$result_delCourse = mysql_query($query_delCourse);

$query_delCourseUnit = "DELETE FROM ML_CourseUnit WHERE CID='".$cid."' ;";
$result_delCourseUnit = mysql_query($query_delCourseUnit);

$query_delCourseAccess = "DELETE FROM ML_CourseAccess WHERE CID='".$cid."' ;";
$result_delCourseAccess = mysql_query($query_delCourseAccess);

$query_delModuleTitleForCourse = "DELETE FROM ML_ModuleTitle WHERE CID='".$cid."' ;";
$result_delModuleTitleForCourse = mysql_query($query_delModuleTitleForCourse);

$query_thisCourseAccess = "SELECT * FROM ML_CourseAccess, ML_CourseUnit WHERE ".
											"ML_CourseAccess.CID = ML_CourseUnit.CID ".
											"AND ML_CourseAccess.CID = '".$cid."'; ";
$result_thisCourseAccess = mysql_query($query_thisCourseAccess);
$num_thisCourseAccess= mysql_num_rows($result_thisCourseAccess);

echo $query_queCourseAccess."</br>";

for ( $i=0 ; $i < $num_thisCourseAccess ; $i++)
{
	$unit_id = mysql_result($result_thisCourseAccess, $i, "UNIT_ID");	

	$query_delUnitAccess = "DELETE FROM ML_UnitAccess WHERE UNIT_ID='".$unit_id."' ;";
	$result_delUnitAccess = mysql_query($query_delUnitAccess);
	
	$query_delSong = "DELETE FROM ML_Song, ML_SongDetail ".
	"WHERE ML_Song.SID=ML_SongDetail.SID ". 
	"AND ML_Song.SID LIKE '".$unit_id."%' ;";
	$result_delSong = mysql_query($query_delSong);	
	
	$query_delSongEmb = "DELETE FROM ML_SongEmbed WHERE SID LIKE '".$unit_id."%' ;";
	$result_delSongEmb = mysql_query($query_delSongEmb);	

}

header('Location:_admCourse.php?language='.$input_language); 

?>