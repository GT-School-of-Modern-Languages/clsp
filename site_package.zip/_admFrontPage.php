<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$query_mainTitle = "SELECT * FROM ML_UI WHERE NAME='MAIN_TITLE'";
$result_mainTitle = mysql_query($query_mainTitle);
$main_title = mysql_result($result_mainTitle, 0, "TEXT");

$query_contents = "SELECT * FROM ML_UI WHERE NAME='INTRO_CONTENTS'";
$result_contents = mysql_query($query_contents);
$intro_contents = mysql_result($result_contents, 0, "TEXT");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css"href="script/cal/calendar.css">
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/cal/calendar_us.js"></script>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
	</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
	</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Front Page</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>  
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>       
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr> 
    </table>    
</td>
    <td align="left" valign="top">
    
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >>  Front Page </div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <form name="COURSE" method="post" action="_admEditFrontPage.php">
	<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
	<input name="language" type="hidden" value="<?=$input_language?>" readonly>	
	<input name="CID" type="hidden" value="" readonly>	
	<input name="UNIT_ID" type="hidden" value="" readonly>		
    <table width="800" border="0" cellspacing="0" cellpadding="3" bgcolor="#FFFFFF">
      <tr bgcolor="#FFFFFF">
        <th width="20%" valign="top"><font color="#<?=$color2?>">Main Title: </font></th>
        <td width="80%" valign="top">        
        <input name="MAIN_TITLE" value="<?=$main_title?>" type="text" 
        style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="50" maxlength="100">
        </td>
      </tr>

      <tr bgcolor="#FFFFFF">
          <th width="20%" valign="top"><font color="#<?=$color2?>">Contents/HTML: </font></th>
            <th width="20%" valign="top"></th>
            <td width="80%" valign="top"> </td>       
      </tr>  

      <tr bgcolor="#FFFFFF">
          <th width="20%" valign="top">&nbsp;</th>
            <th width="10%" valign="top">
              <textarea name="CONTENTS" rows="30" cols="90"><?=$intro_contents?></textarea></th>
            <td width="90%" valign="top"> </td>       
      </tr>  

    	<tr bgcolor="#FFFFFF">
    	    <th width="20%" valign="top">&nbsp;</th>
            <td width="80%" valign="top" align="right">                
            <input type="submit" value="Apply Change" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; " >
            </font>
            </td>
         </tr>      
         <tr bgcolor="#FFFFFF">
            <td colspan="2">
            <hr noshade color="#<?=$color2?>" size="2">
         </tr>     

       </form>
    </td>
    </tr>
  </table>
   
</body>
</html>


