<?php
session_start();

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
  header('Location: index.php'); 
}
if(!isset($_SESSION['ACID'])) {
  header("Location: login.php?ULANGUAGE=" . $input_language);
}
$acid = $_SESSION['ACID'];
$_SESSION['ACID'] = $acid;

$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';
require ("config.php");
$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
$unit_id = substr($sid, 0, 6);

$query_StartEnd = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='GE' ORDER BY H_ORDER;"; 
$result_StartEnd = mysql_query($query_StartEnd);
$num_StartEnd = mysql_num_rows($result_StartEnd);

$start_hid = 1;
$end_hid = 1;

if ( $num_StartEnd != 0){
	$start_hid = mysql_result($result_StartEnd, 0, "HID"); 
	$end_hid = mysql_result($result_StartEnd, ($num_StartEnd-1), "HID"); 
}

$query_hid = ( $_REQUEST["HID"] == "0" ) ? $start_hid : $_REQUEST["HID"];

$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);

$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$len_song_title = mb_strlen($song_title,'UTF-8');
$s_song_title  = ($len_song_title > 30 ) ? substr($song_title, 0, 25) . "..." : $song_title ;


$target_dir = "listenings/".  strtoupper(substr($input_language, 0, 3))."/" ;
$target_file = mysql_result($result_song, 0, "FILE_NAME");

$query_ge = "SELECT * FROM ML_ModuleGE, ML_Heading, ML_HeadingGE ".
						"WHERE ML_ModuleGE.GID = ML_HeadingGE.GID ".
						"AND ML_Heading.HID = ML_HeadingGE.HID ".
						"AND ML_ModuleGE.SID='".$sid."' " ;		

$query_nonHeading = $query_ge."AND ML_HeadingGE.HID ='1' ;";
$result_nonHeading= mysql_query($query_nonHeading);
$num_nonHeading = mysql_num_rows($result_nonHeading);
									
$query_ge .="AND ML_Heading.HID='".$query_hid."' ORDER BY ML_ModuleGE.G_ORDER;" ;
$result_ge= mysql_query($query_ge);
$num_ge = mysql_num_rows($result_ge);

$query_heading = "SELECT * FROM ML_Heading WHERE HID='".$query_hid."'; ";
$result_heading= mysql_query($query_heading);
$heading = ( $query_hid == 1 ) ? "Other Grammar Exercises" : mysql_result($result_heading, 0, "HEADING") ;
$current_order = mysql_result($result_heading, 0, "H_ORDER") ;

// if there are previous or next heading
$query_preHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='GE' AND H_ORDER < ".$current_order." ORDER BY H_ORDER DESC;" ;
$query_nextHeading = "SELECT * FROM ML_Heading WHERE SID='".$sid."' AND MODULE='GE' AND H_ORDER > ".$current_order." ORDER BY H_ORDER;"; 

$result_preHeading = mysql_query($query_preHeading);
$num_pre = mysql_num_rows($result_preHeading);
$result_nextHeading = mysql_query($query_nextHeading);
$num_next = mysql_num_rows($result_nextHeading);
$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;
$fontSize = ( $lid == "ARA" ) ? 13 : 10 ;
if($lid!="ARA"){
	if($lid=="CHI"){
		$fontSize=13;
		}
		}
        
$query_acc_course = "SELECT * FROM ML_Course, ".
                      "(SELECT * FROM ML_CourseAccess ".
                          "WHERE CPID='". $acid ."' ". 
                          "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".   
                          "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                      ") AS courseAccess ". 
                      "WHERE ML_Course.CID=courseAccess.CID AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

$result_acc_course = mysql_query($query_acc_course);
$num_acc_course = mysql_num_rows($result_acc_course);

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
   <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
        <img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></a></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
        <font size="10" color="black"> </font></a></td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>"><span class="menu_head"><font color="#<?=$color2?>"><b><?=$s_song_title?></b></font></span></div></td>
      </tr>
<?
$query_numN = "SELECT * FROM ML_ModuleCN WHERE SID='". $sid."' ;";
$result_numN = mysql_query($query_numN);
$num_n = mysql_num_rows($result_numN); 

$query_chkLyrics = "SELECT LYRICS FROM ML_Song WHERE SID='". $sid."' ;";
$result_chkLyrics = mysql_query($query_chkLyrics);
$chkLyrics = mysql_result($result_chkLyrics, 0, "LYRICS");

$num_n = ( $num_n == 0 && $chkLyrics != "" ) ? 1 : $num_n;
				
$query_numQ = "SELECT * FROM ML_ModuleQU WHERE SID='". $sid."' ;";
$result_numQ = mysql_query($query_numQ);
$num_q = mysql_num_rows($result_numQ);			

$query_numL = "SELECT * FROM ML_ModuleLT WHERE SID='". $sid."' ;";
$result_numL = mysql_query($query_numL);
$num_l = mysql_num_rows($result_numL);		

$query_numG = "SELECT * FROM ML_ModuleGE WHERE SID='". $sid."' ;";
$result_numG = mysql_query($query_numG);
$num_g = mysql_num_rows($result_numG);		

$query_numW = "SELECT * FROM ML_ModuleDW WHERE SID='". $sid."' ;";
$result_numW = mysql_query($query_numW);
$num_w = mysql_num_rows($result_numW);					

$query_numS = "SELECT * FROM ML_ModuleLS WHERE SID='". $sid."' ;";
$result_numS = mysql_query($query_numS);
$num_s = mysql_num_rows($result_numS);		

$query_course = "SELECT * FROM ML_CourseUnit, ML_Course ".
                        "WHERE ML_CourseUnit.CID = ML_Course.CID ".
                        "AND ML_CourseUnit.UNIT_ID='".$unit_id."' ;";
                        
$result_course = mysql_query($query_course);
$current_course_title  = mysql_result($result_course, 0, "COURSE_TITLE");
$current_cid  = mysql_result($result_course, 0, "CID");

$gid = strtoupper(substr($input_language, 0, 3));
$query_module_title = "SELECT * FROM ML_ModuleTitle WHERE CID='".$current_cid."' AND LID='".$lid."';";
$result_module_title = mysql_query($query_module_title);
				
$mn_title = ($num_n != 0 ) ? mysql_result($result_module_title, 0, "MODULE_N") : "" ;
$mq_title  = ($num_q != 0 ) ? mysql_result($result_module_title, 0, "MODULE_Q") : "" ;
$ml_title  = ($num_l != 0 ) ? mysql_result($result_module_title, 0, "MODULE_L") : ""  ;
$mg_title  = ($num_g != 0 ) ? mysql_result($result_module_title, 0, "MODULE_G") : ""  ;
$mw_title  = ($num_w != 0 ) ? mysql_result($result_module_title, 0, "MODULE_W") : ""  ;
$ms_title  = ($num_s != 0 ) ? mysql_result($result_module_title, 0, "MODULE_S") : ""  ;

$query_module = "SELECT * FROM ML_Module ORDER BY MOD_INDEX;";
$result_module = mysql_query($query_module);
$num_module = mysql_num_rows($result_module);

for ($i=0 ; $i< $num_module ; $i++){
	$page = mysql_result($result_module, $i, "MOD_PAGE");
	$module = mysql_result($result_module, $i, "MODUEL");
	$moduel_title = "";
	$chkModule = 0 ;

	switch($module)	
	{
	case "Listening Task":
			
			$chkModule = $num_l ;
			if($ml_title=="")
				$moduel_title = $module;
			else
				$moduel_title= $ml_title;
			break;
		case "Culture Notes":
			$chkModule = $num_n ;
			if($mn_title=="")
				$moduel_title = $module;
			else
				$moduel_title=$mn_title;
			break;
		case "Grammar Exercise":
			$chkModule = $num_g ;	
			if($mg_title=="")	
				$moduel_title = $module;
			else
				$moduel_title=$mg_title;
			break;
		case "Questions for Understanding":
			$chkModule =  $num_q ;
			if($mq_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mq_title;
			break;
		case "Discussion and Writing":
			$chkModule = $num_w ;
			if($mw_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mw_title;
			break;
		case "Listening Suggestion": 	
			$chkModule = $num_s ;
			if($ms_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $ms_title;
			break;
	}
		
	if ( $chkModule != 0 ) {
		
		$strHead = ( $module == "Grammar Exercise" ) ? "<span class=\"menu_select\"><font size=\"$strArbSize\">".$moduel_title."</font></span>" :
		"<a href=\"".$page."?ULANGUAGE=".$input_language."&SID=".$sid."&PWD=".$pwd."&HID=0\"><span class=\"menu_head\"><font size=\"$strArbSize\" color=\"#383838\">".$moduel_title."</font></span></a>" ;
?>
      <tr>
        <td><div class="leftMenu"><?=$strHead?></div></td>
      </tr>
<?
	}
}
?>   
    </table>

<link href="css/navstyle.php" rel="stylesheet" type="text/css" />

<ul id="nav" >
   
<?

if($num_acc_course==1){
  
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {  

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>">Navigation</a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                              "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                              "AND ML_CourseUnit.CID='".$each_cid."' ".
                                              "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);


                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);
                        for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>
    <?}}
}
else{
    ?>
    <li><a href="#">Navigation</a>
        <ul><?
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>"><?=$course_title2?></a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                            "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                            "AND ML_CourseUnit.CID='".$each_cid."' ".
                                            "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);

                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);



                         for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}}?>
                </ul>
           </li>

    <?}?>
   </ul> 
  </li>




<?}?>
        
</ul>


</td>
    <td align="center" valign="top"> 
	<div <?=$strDirRTL?>  >  	     
    <table width="650" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <table width="100%" border="0" cellspacing="0" cellpadding="3">
     <Form name="GRAMMAR" method="post" id="TLIST">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="HID" type="hidden" value="<?=$query_hid?>">    
	 <input name="PWD" type="hidden" value="<?=$pwd?>">    	 
	 <input name="MODULE" type="hidden" value="GE">   	     

      <tr bgcolor="#<?=$color2?>">
        <td colspan="2" valign="bottom"><font color="#FFFFFF" size="4">&nbsp;&nbsp;<?=$heading?></font> 
        </td>
      </tr> 
      <tr bgcolor="#<?=$color2?>"> 
        <td colspan="2" align="right" valign="top">
	    <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr>
       		<td width="50%" align="left">
<?php
	if ( $num_ge >= 0 || ($num_ge == 1 && $num_nonHeading == 1 )  )
	{
		if ( $num_pre > 0 )
		{		
			$pre_hid = mysql_result($result_preHeading, 0, "HID") ;
?>
        	&nbsp;&nbsp;
        	<input type="image" src="images/pre.png" width="10" height="10" onclick="chgTopics('grammar.php','GE','<?=$pre_hid ?>')"   style="cursor: pointer;">
        	<input type="submit" value="Previous Topic" onclick="chgTopics('grammar.php','GE','<?=$pre_hid ?>')"  
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;"> 
<?php
		}
		else
		{
			if ( $num_nonHeading != 0 && $query_hid == 1 && $end_hid != 1 )
			{
				$pre_hid = $end_hid;			
?>
        	&nbsp;&nbsp;
        	<input type="image" src="images/pre.png" width="10" height="10" onclick="chgTopics('grammar.php','GE','<?=$pre_hid ?>')"   style="cursor: pointer;">     
	        <input type="submit" value="Previous Topic" onclick="chgTopics('grammar.php','GE','<?=$pre_hid ?>')"  
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">
<?php
			}
		}
?>
       		</td>
        	<td width="50%" align="right">
<?php
		if ( $num_next > 0 &&  $query_hid != 1 )
		{		
			$next_hid = mysql_result($result_nextHeading, 0, "HID") ;		
?>
	        <input type="submit" value="Next Topic" onclick="chgTopics('grammar.php','GE','<?=$next_hid?>')"  
        	style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">
        	<input type="image" src="images/next.png" width="10" height="10" onclick="chgTopics('grammar.php','GE','<?=$next_hid?>')" style="cursor: pointer;">&nbsp;&nbsp;
<?php
		}
		else
		{
			if ( $num_nonHeading != 0 && $query_hid != 1 )
			{
				$next_hid = 1;	
?>
	        <input type="submit" value="Next Topic" 
	        onclick="chgTopics('grammar.php','GE','<?=$next_hid ?>')"  
        	style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">
        	<input type="image" src="images/next.png" width="10" height="10" onclick="chgTopics('grammar.php','GE','<?=$next_hid?>')" style="cursor: pointer;">&nbsp;&nbsp;
<?php
			}
			else
			{
				echo "</br>";
			}
		}
	}
	else
	{
		echo "</br>";
	}
?>
        	</td>
        </tr>
		</table>
        </td>
      </tr> 
<?php

$PagewithFeedback	 = 0; // no feedback option in this section

for ( $i=0 ; $i < $num_ge ; $i++)
{
	$strAns = "";
	$strTask = "";
	$strFB = "";

	$gid = mysql_result($result_ge, $i, "GID") ;
	$g_content =str_replace("\n", "</br>", mysql_result($result_ge, $i, "G_CONTENT")); 
	$g_types = mysql_result($result_ge, $i, "G_TYPES") ;
	$g_option = str_replace("\n", "</br>", mysql_result($result_ge, $i, "G_OPTION")); 	
	$hid = mysql_result($result_ge, $i, "HID");		
	$heading =  mysql_result($result_ge, $i, "HEADING"); 		

	$task_ans =  mysql_result($result_ge, $i, "ANS"); 		
	$preFeedback =  mysql_result($result_ge, $i, "FEEDBACK"); 		
	$PagewithFeedback	= ($preFeedback != "" )? $PagewithFeedback+1 : $PagewithFeedback ;
	
	$nextLine = array("\r\n", "\n\r", "\n");
	$task_feedback = str_replace($nextLine, "</br>", $preFeedback);	
	
	$task_optNum = substr_count(mysql_result($result_ge, $i, "G_OPTION"),"\n") +1 ;
	$task_eachOpt = explode("\n", mysql_result($result_ge, $i, "G_OPTION"));

	for ( $n = 0 ; $n < $task_optNum ; $n++)
	{	
		$strAnsChk = ( substr_count($task_ans, $n+1 ) == 0 ) ? "<font color='#FFFFFF'>_</font>" : "x" ; 	
		$strFB .= "<font color='#<?=$color2?>'>".$strAnsChk."</font>&nbsp;".$task_eachOpt[$n]."</br>"; 	
	}			
	$strFB = ( $g_types == 6 ) ? $task_feedback : $strFB."</br>".$task_feedback ;

	switch($g_types)	
	{
		case "1":		//Open-Ended Question
			$strAns = "<textarea name=\"ANS".$gid."\"  rows=\"3\" cols=\"65\" style=\"color: #000000; font-size: ".$fontSize."pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;\"></textarea> ";		
			$strTask = $g_content."</font></br></br>".$strAns;			
			break;
		case "2": 	//Blank Question
			$uline_count = substr_count($g_content, "_");
			$strTask = $g_content . "</br>";
			for ( $c=0 ; $c < $uline_count ; $c++){
				$strAns = "&nbsp;<input id=\"ANS".$gid."-".$c."\" name=\"ANS".$gid."-".$c."\" type=\"text\"style=\"color: #000000; font-size: ".$fontSize."pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;\" size=\"15\" maxlength=\"20\" onblur=\"setBlankRes(".$gid.",".$uline_count.")\">&nbsp;";
				$strTask = preg_replace("/_/",  $strAns, $strTask,1);
			}	
			break;
		case "3":		//Multi-Choice Question
			$mc_count = substr_count($g_option, "</br>") +1 ;
			$strTask = "";
			$ifChk = ""; 
			for ( $c=0 ; $c < $mc_count ; $c++){
				$strAns = "<input id=\"CHK".$gid."_".($c+1)."\" name=\"CHK".$gid."\"  type=\"checkbox\" value=\"".($c+1)."\" ".$ifChk." onclick=\"setChkboxRes(".$gid.", ".$task_optNum.")\">";
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $g_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}	
			$strTask = $g_content . "</br></br>".$strTask;		
			break;
		case "4":		//Single-Choice Question
			$sc_count = substr_count($g_option, "</br>") +1 ;
			$strTask = "";
			$ifChk = ""; 
			for ( $c=0 ; $c < $sc_count ; $c++){
				$strAns = "<input id=\"CHK".$gid."_".($c+1)."\" name=\"CHK".$gid."\" type=\"radio\" value=\"".($c+1)."\" ".$ifChk." onclick=\"setRadioRes(".$gid.", ".($c+1).")\">";	
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $g_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}
			$strTask = $g_content . "</br></br>".$strTask;	
			break;
		case "5":		//Plain Text
			$strTask = $g_content."</br></br>"; 	
			break;						
			
		case "6": 	//Fill-in-Blank Question with feedback
			$uline_count = substr_count($g_content, "_");
			$strTask = $g_content . "";
			for ( $c=0 ; $c < $uline_count ; $c++){
				$strAns = "&nbsp;<input id=\"ANS".$gid."-".$c."\" name=\"ANS".$gid."-".$c."\" type=\"text\"style=\"color: #000000; font-size: ".$fontSize."pt; font-family: optima; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;\" size=\"15\" maxlength=\"20\" onblur=\"setBlankRes(".$gid.",".$uline_count.")\">&nbsp;";
				$strTask = preg_replace("/_/",  $strAns, $strTask,1)."</br>";
			}	
			break;	
			
		case "7":		//Multi-Answer Question with feedback
			$mc_count = substr_count($g_option, "</br>") +1 ;
			$strTask = "";
			for ( $c=0 ; $c < $mc_count ; $c++){
				$strAns = "<input id=\"CHK".$gid."_".($c+1)."\" name=\"CHK".$gid."\" type=\"checkbox\" value=\"".($c+1)."\" onclick=\"setChkboxRes(".$gid.", ".$task_optNum.")\">";
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $g_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}	
			$strTask = $g_content . "</br></br>".$strTask;		
			break;
			
		case "8":		//Multiple Choice Question with feedback
			$sc_count = substr_count($g_option, "</br>") +1 ;
			$strTask = "";
			for ( $c=0 ; $c < $sc_count ; $c++){
				$strAns = "<input id=\"CHK".$gid."_".($c+1)."\" name=\"CHK".$gid."\"  type=\"radio\" value=\"".($c+1)."\" onclick=\"setRadioRes(".$gid.", ".($c+1).")\">";	
				if ($c == 0 ) {
					$strTask .=  $strAns."&nbsp;&nbsp;" ;
				}
				else if ($c == 1 ){
					$strTask .= preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $g_option, 1); 
				}else{
					$strTask = preg_replace("/<\/br>/", "<br>". $strAns."&nbsp;&nbsp;", $strTask, 1); 
				}
			}
			$strTask = $g_content . "</br></br>".$strTask;	
			break;				
						
	}	
?>
    <tr >
    <td colspan="3" valign="top">
        <hr noshade color="#<?=$color2?>" size="1"><br></font>
    </td>
    </tr>  
	<tr>        
    <td colspan="2" valign="top" align="center">
	    <table width="95%" border="0" cellspacing="0" cellpadding="0"> 
       	<tr  id="Q<?=$gid?>">
       	<td width="40" valign="top" align="right">&nbsp;&nbsp;</td>
       	<td valign="top"><font size="<?=$strArbSize?>"><?=$strTask?></font>
<?php
if ( $g_types != 1){
?>       	
       	<input id="ANS<?=$gid?>" name="ANS<?=$gid?>" type="hidden" value="">
<?
}
?>       	
       	</td>
       	<td width="40" valign="top" align="right">&nbsp;&nbsp;</td>       	
        </tr>        	
		</table>
	</td>
	</tr>
<?php
}
?>
        </td>
      </tr>   
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
      <tr>
        <td colspan="2" align="right" valign="top">           
<?
if ($PagewithFeedback != 0 ){
?>
			<input type="submit" value="CHECK ANSWERS" onclick="openFB()" 
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;"> 
<?
}
?>    	    
    	    &nbsp;&nbsp;  
<?      
if($PagewithFeedback == 0){
?>
			<input type="submit" value="PRINT or SAVE" onclick="openPrint()" 
    	    style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;">  
    	    &nbsp;</br></br>     
<?
}
?>
        </td>
      </tr>    
 </table> 
    </td>
  </tr> 
</table></br></br>
</Form>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>  
</table>
</body>
</html>
