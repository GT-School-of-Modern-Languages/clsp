<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<?php

$sid = $_REQUEST["SID"] ;
$qid = $_REQUEST["QID"] ;

$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_songqu =  "SELECT * FROM ML_Song, ML_ModuleQU ".
						"WHERE ML_Song.SID = ML_ModuleQU.SID ".
						"AND ML_ModuleQU.QID='".$qid."' ".
						"AND ML_Song.SID='".$sid."';";				
						
$result_songqu = mysql_query($query_songqu);
$song_title = mysql_result($result_songqu, 0, "SONG_TITLE");	
$q_content = trim(mysql_result($result_songqu, 0, "Q_CONTENT"));	
$q_types = ($_REQUEST["Q_TYPES"] == "0" || $_REQUEST["Q_TYPES"] == mysql_result($result_songqu, 0, "Q_TYPES") ) ? 
mysql_result($result_songqu, 0, "Q_TYPES") : $_REQUEST["Q_TYPES"] ;	

$q_option = ($_REQUEST["Q_OPTION"] =="" || trim($_REQUEST["Q_OPTION"]) == trim(mysql_result($result_songqu, 0, "Q_OPTION")) ) ? trim(mysql_result($result_songqu, 0, "Q_OPTION")) : $_REQUEST["Q_OPTION"] ;	

$task_optNum = substr_count($q_option,"\n") +1 ;
$task_eachOpt = explode("\n", $q_option);
$task_optText = str_replace("\n", "</br>", $q_option );

$ans = mysql_result($result_songqu, 0, "ANS");	
$feedback = mysql_result($result_songqu, 0, "FEEDBACK");	

$strChkDisplay = ( $q_types == 3 || $q_types == 4 || $q_types == 7 || $q_types == 8 ) ? "" : "none";
$strChkDisplay_ans = ( $q_types == 7 || $q_types == 8 ) ? "" : "none";
$strChkDisplay_feedback = ( $q_types == 6 || $q_types == 7 || $q_types == 8  ) ? "" : "none";

$strChkTypes_1 = ( $q_types == "1" ) ? "checked" : "";
$strChkTypes_2 = ( $q_types == "2" ) ? "checked" : "";
$strChkTypes_3 = ( $q_types == "3" ) ? "checked" : "";
$strChkTypes_4 = ( $q_types == "4" ) ? "checked" : "";
$strChkTypes_5 = ( $q_types == "5" ) ? "checked" : "";
$strChkTypes_6 = ( $q_types == "6" ) ? "checked" : "";
$strChkTypes_7 = ( $q_types == "7" ) ? "checked" : "";
$strChkTypes_8 = ( $q_types == "8" ) ? "checked" : "";

$task_strAns = "";
$task_strTask = "";

switch($q_types)	
{
	case "7":		//Multi-Answer Question
		for ( $i = 0 ; $i < $task_optNum ; $i++)
		{	
			$strAns = ( substr_count($ans, $i+1 ) == 0 ) ? "" : "checked" ;
			$task_strAns = "<input id=\"CHK".($i+1)."\" name=\"CHK\" type=\"checkbox\" onclick=\"setChkboxAns(".$task_optNum.")\" value=\"".($i+1)."\" ".$strAns.">";		
			$task_strTask .= $task_strAns."&nbsp;".$task_eachOpt[$i]."</br>"; 	
		}
	break;
	case "8":		//Multiple-Choice Question
		for ( $i = 0 ; $i < $task_optNum ; $i++)
		{	
			$strAns = ( substr_count($ans, $i+1 ) == 0 ) ? "" : "checked" ;
			$task_strAns = "<input id=\"CHK".($i+1)."\" name=\"CHK\" type=\"radio\" onclick=\"setRadioAns(".($i+1).")\" value=\"".($i+1)."\" ".$strAns.">";	
			$task_strTask .= $task_strAns."&nbsp;".$task_eachOpt[$i]."</br>"; 	
		}
		break;				
}	

$query_heading = "SELECT * FROM ML_Heading  WHERE SID='".$sid."' AND MODULE='QU' ORDER BY HID ;" ;
$result_heading= mysql_query($query_heading);
$num_heading = mysql_num_rows($result_heading);

$query_qu = "SELECT * FROM ML_ModuleQU, ML_Heading, ML_HeadingQU ".
						"WHERE ML_ModuleQU.QID = ML_HeadingQU.QID ".
						"AND ML_Heading.HID = ML_HeadingQU.HID ".
						"AND ML_ModuleQU.QID='".$qid."' ORDER BY ML_Heading.HID ;" ;

$result_qu= mysql_query($query_qu);
$query_hid = mysql_result($result_qu, 0, "HID");	

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-N.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_Q?></span></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_L?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>         
      <tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>    
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a> >> <a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>">Headings/Directions for "Questions for Understanding" </a>>> <a href="_admEditModule-Q.php?ULANGUAGE=<?=$input_language?>&SONG_ID=<?=$sid?>&HID=">Edit "Questions for Understanding" Module</a> >> Update Questions for Understanding</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
     <form name="QUESTION_UNDERSTANDING" method="post">
     <input name="CID" type="hidden" value="<?=$cid?>">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
	 <input name="QID" type="hidden" value="<?=$qid?>">      
	 <input name="HID" type="hidden" value="<?=$query_hid?>">      
    <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Song Title: </font></th>
        <td width="85%"><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>"
        style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr>       
<?php

if ( $num_heading > 0 )
{		

?>
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Heading: </font></th>
        <td width="85%">
          <select name="HEADING" style="color: #<?=$color2?>; font-size: 12pt; font-family: Verdana; border-width: 0px; background-color: #<?=$color3?>;" onchange="showQuestion(this,'QU')">
          	<option value="1">(remove heading)</option>
 <?php
	for ( $j=0 ; $j < $num_heading ; $j++)
	{	
		$heading = mysql_result($result_heading, $j, "HEADING");	
		$hid = mysql_result($result_heading, $j, "HID");	
		if ( $heading != "" )
		{
			$strSelect [$j] = ( $hid == $query_hid ) ? "selected" : "" ; 
?>         	
            <option value="<?=$hid?>" <?=$strSelect[$j]?> ><?=$heading?></option>
<?
		}
	}
?>          
          </select>   	     
          <input type="submit" value="CREATE NEW HEADING" onclick="submittoQ('_admEditHeadingQ.php','')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">			
        </td>
      </tr> 
<?
}
else
{
	echo "<input name=\"HEADING\" type=\"hidden\" value=\"1\">";
}
?> 
	 
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Question:</font></th>
        <td width="75%"><font color="#800000" size="1">( put one listening task at a time in the column below )  </font>
      	</td>
      </tr> 
	 <tr>
        <th width="25%" align="right" valign="top">&nbsp;</th>
        <td width="75%">
		<textarea name="Q_CONTENT"  rows="4" cols="65" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$q_content?></textarea>   
      	</td>
      </tr>       
	 <tr>
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Question Type:</font></th>
        <td width="75%"><font size="2" color="#<?=$color2?>">
        <label><input type="radio" name="Q_TYPES" value="5" <?=$strChkTypes_5?> onclick="showOption(0)">Plain Text Only</label></br>
        <label><input type="radio" name="Q_TYPES" value="1" <?=$strChkTypes_1?> onclick="showOption(0)">Open-Ended Question</label></br>
        <label><input type="radio" name="Q_TYPES" value="2" <?=$strChkTypes_2?> onclick="showOption(0)">Fill-In Blank Question <font size="1" color="#800000">** use <b>UNDERLINE(_)</b> for the blank in the question **</font></label></br>
        <label><input type="radio" name="Q_TYPES" value="3" <?=$strChkTypes_3?> onclick="showOption(1)">Multi-Answer Question</label></br>
        <label><input type="radio" name="Q_TYPES" value="4" <?=$strChkTypes_4?> onclick="showOption(1)">Multiple-Choice Question</label></br>
  		</br>      
        <label><input type="radio" name="Q_TYPES" value="6" onclick="showOption(4)" <?=$strChkTypes_6?> >Fill-In Blank Question with Feedback<font size="1" color="#800000">(use <b>UNDERLINE, _</b> for the blank in the question)</font></label></br>       
        <label><input type="radio" name="Q_TYPES" value="7" onclick="showOption(3)" <?=$strChkTypes_7?> >Multi-Answer Question with Feedback</label></br>
        <label><input type="radio" name="Q_TYPES" value="8" onclick="showOption(3)" <?=$strChkTypes_8?> >Multiple-Choice Question with Feedback</label></br>           	
      	</font></td>
      </tr> 
      	</font></td>
      </tr> 
      <tr>
        <td colspan="2" align="center">
        </td>
      </tr>
       <tr  id="trOption" style="display: <?=$strChkDisplay?> ;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Options:</br></font></th>
        <td width="75%">  <font color="#800000" size="1">** Put options in separate lines **  </font>
        </td>
      </tr>
       <tr id="trOptionText" style="display: <?=$strChkDisplay?>  ;">
        <th width="25%" align="right" valign="top">&nbsp;</th>
        <td width="75%">
		<textarea name="Q_OPTION"  rows="5" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$q_option?></textarea>        
        </td>
      </tr>      
      </tr>      
       <tr id="trSetAns" style="display: ;">
        <th width="25%" valign="top">&nbsp;</th>
        <td width="75%">
        <input type="submit" value="Update Answer Option(s)" onclick="submittoQ('_admEditModule-QUpd.php','<?=$qid?>')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">       
        </td>
      </tr>  
       <tr id="trAnsText" style="display:<?=$strChkDisplay_ans?>">
        <th width="25%" valign="top" align="<?=$strTHAlign?>"><font color="#<?=$color2?>" size="2">Answer(s):</br></font>
        <input type="hidden" name="ANS" id="ANS" value="<?=$ans?>">
        </th>
        <td width="75%"><hr noshade color="#<?=$color2?>" size="1">
        <font color="#<?=$color2?>" size="2"><?=$task_strTask?></font>
        </font></td>
     	</tr> 
       <tr id="trFeedbackText" style="display:<?=$strChkDisplay_feedback?>">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>" size="2">Feedback Information</font></th>
        <td width="75%">  <font color="#800000" size="1">
        ** Put feedback for each field in separate lines **  </br>
        ** Each field can have more than one potential answer. Separate each potential answer with <b>":"</b> symbol. **</br></br>
        Ex: phrase1 for field A: phrase2 for field A: phrase3 for field A: phrase4 for field A</br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;phrase5 for field B: phrase6 for field B
        </font></br></br>
		<textarea id="FEEDBACK" name="FEEDBACK"  rows="5" cols="65" style="color: #000000; font-size: 8pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"><?=$feedback?></textarea>        
        </td>
      </tr>            
      <tr> 
        <td colspan="2" align="right" valign="top">
        <input type="button" value="CANCEL" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;" onclick="history.back();">
        <input type="submit" value="UPDATE" onclick="submittoQ('_admModuleQUpd.php','<?=$qid?>')" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">&nbsp;&nbsp;
        </td>
      </tr> 
      </form>
	<tr>        
    <td colspan="2" valign="top" align="center"></td>
	</tr>
        </td>
      </tr>   
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>    
 </table> 
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table></br></br>
	</td>
</tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>