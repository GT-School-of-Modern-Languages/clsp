<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN"
   "http://www.w3.org/TR/html4/frameset.dtd">
<HTML>
<HEAD>
<TITLE>Critical Language Song Project</TITLE>
</HEAD>

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<TITLE>Critical Language Song Project</TITLE>
<FRAMESET rows="0%, 100%" FRAMEBORDER="no">
  <FRAME noresize>
  <FRAME src="index_intro.php" noresize>
</FRAMESET>
</HTML>
