<?php

$input_language = $_REQUEST["language"] ;
if ( $input_language == "" ){
	header('Location:./admin/'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$query_courseUnitAndUnit = "SELECT * FROM ML_CourseUnit INNER JOIN ML_Unit ON ML_CourseUnit.UNIT_ID=ML_Unit.UNIT_ID WHERE ML_Unit.UNIT_ID like '".$lid."%' ORDER BY UNIT_ORDER;" ;
$result_courseUnitAndUnit = mysql_query($query_courseUnitAndUnit);

$query_course = "SELECT * FROM ML_Course WHERE LID like '".$lid."%' ORDER BY CID;" ;
$result_course = mysql_query($query_course);
$num_course = mysql_num_rows($result_course);

$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>_admModuleList.php</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js?version=21"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Module Management</span></div></td>
      </tr>    
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>        
<tr>
        <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr> 
    </table>    
</td>
    <td align="left" valign="top">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	 
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> Modules Management in <?=$input_language?></div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
  
    <form name="MODULE_LIST" method="post" action="">      
    <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>
    <input name="SONG_ID" type="hidden" value="" >    
    <input name="CID" type="hidden" value="" >
        
    <?php
    if ( $num_course != 0 )
    {
    	for ($i=0 ; $i< $num_course ; $i++){
        $cid = mysql_result($result_course, $i, "CID");
        $query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
        $result_mtitle = mysql_query($query_mtitle);
        
        $query_ctitle = "SELECT * FROM ML_Course WHERE CID='".$cid."'; ";
        $result_ctitle = mysql_query($query_ctitle);
        $ctitle = mysql_result($result_ctitle, 0, "COURSE_TITLE")

        ?>
        <table width="100%" border="0" cellspacing="0" cellpadding="3" bgcolor="#<?=$color3?>">       
          <tr>
            <td colspan="8"><hr noshade color="#<?=$color2?>" size="3"><font color="#383838" size="4" face="Verdana, Geneva, sans-serif, Time">&nbsp<?=$ctitle;?></font></td>
          </tr>

          <tr>
            <td colspan="8"><hr noshade color="#<?=$color2?>" size="3"></td>
          </tr>     
        
          
          <tr>
            <td colspan="2" align="center">
                <input type="submit" value="Modify Module Title" onclick="submittoC('_admEditModuleTitle.php','<?=$cid?>');" style="cursor: pointer; background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 8pt; font-family: Verdana;"> </br>
            </td>      
            
            <td width="12%" align="center"><font color="#383838" size="2" face="Verdana, Geneva, sans-serif, Times" ><?=mysql_result($result_mtitle, 0, "MODULE_N");?></font></td>
            <td width="12%" align="center"><font color="#383838" size="2" face="Verdana, Geneva, sans-serif, Times" ><?=mysql_result($result_mtitle, 0, "MODULE_Q");?></font></td>
            <td width="12%" align="center"><font color="#383838" size="2" face="Verdana, Geneva, sans-serif, Times" ><?=mysql_result($result_mtitle, 0, "MODULE_L");?></font></td>
            <td width="12%" align="center"><font color="#383838" size="2" face="Verdana, Geneva, sans-serif, Times" ><?=mysql_result($result_mtitle, 0, "MODULE_G");?></font></td>
            <td width="12%" align="center"><font color="#383838" size="2" face="Verdana, Geneva, sans-serif, Times" ><?=mysql_result($result_mtitle, 0, "MODULE_W");?></font></td>
            <td width="12%" align="center"><font color="#383838" size="2" face="Verdana, Geneva, sans-serif, Times" ><?=mysql_result($result_mtitle, 0, "MODULE_S");?></font></td>
          </tr> 


          <?
          //$query_unit = "SELECT * FROM ML_Unit WHERE UNIT_ID like '".$lid."%' AND CID='".$cid."' ORDER BY UNIT_ORDER;" ;
          $query_unit = "SELECT * FROM ML_CourseUnit INNER JOIN ML_Unit ON ML_CourseUnit.UNIT_ID=ML_Unit.UNIT_ID WHERE ML_CourseUnit.CID='".$cid."' AND ML_Unit.UNIT_ID like '".$lid."%' ORDER BY UNIT_ORDER;" ;
          $result_unit = mysql_query($query_unit);
          $num_unit = mysql_num_rows($result_unit);

          for($j=0 ; $j < $num_unit ; $j++) {
            $unit_id = mysql_result($result_unit, $j, "UNIT_ID");
            $query_song = "SELECT * FROM ML_Song WHERE SID like '". $unit_id ."_%'; ";
            $result_song = mysql_query($query_song);
            $num_song = mysql_num_rows($result_song);
          
            ?>

            <tr>
              <td colspan="8"><hr noshade color="#<?=$color2?>" size="1"></td>
            </tr>    
            <tr>
              <th colspan="8" align="<?=$strAlign?>"><font  color="#<?=$color2?>" size="2"><< <?=mysql_result($result_unit, $j, "UNIT_TITLE");?> >></font></th>
            </tr>  

            <?

            for($k=0 ; $k < $num_song ; $k++) {
             
              $song_title = mysql_result($result_song, $k, "SONG_TITLE") ;
              $sid = mysql_result($result_song, $k, "SID") ;
              $strStyleN = "style='cursor: pointer; background: #FFFFFF; color: #<?=$color2?>; font-size: 8pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>;' ";
              $strStyleY = "style='cursor: pointer; background: #<?=$color2?>; color: #FFFFFF; font-size: 8pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #FFFFFF;' ";

              $query_numN = "SELECT * FROM ML_ModuleCN WHERE SID='". $sid."' ;";
              $result_numN = mysql_query($query_numN);
              $num_n = mysql_num_rows($result_numN);
              $str_btnN = ( $num_n > 0 ) ? "value='".$num_n."' ". $strStyleY : "value='x' ". $strStyleN;
              
              $query_numQ = "SELECT * FROM ML_ModuleQU WHERE SID='". $sid."' ;";
              $result_numQ = mysql_query($query_numQ);
              $num_q = mysql_num_rows($result_numQ);
              $str_btnQ = ( $num_q > 0 ) ? "value='".$num_q."' ". $strStyleY : "value='x' ". $strStyleN;        

              $query_numL = "SELECT * FROM ML_ModuleLT WHERE SID='". $sid."' ;";
              $result_numL = mysql_query($query_numL);
              $num_l = mysql_num_rows($result_numL);
              $str_btnL = ( $num_l > 0 ) ? "value='".$num_l."' ". $strStyleY : "value='x' ". $strStyleN;      

              $query_numG = "SELECT * FROM ML_ModuleGE WHERE SID='". $sid."' ;";
              $result_numG = mysql_query($query_numG);
              $num_g = mysql_num_rows($result_numG);
              $str_btnG = ( $num_g > 0 ) ? "value='".$num_g."' ". $strStyleY : "value='x' ". $strStyleN;      

              $query_numW = "SELECT * FROM ML_ModuleDW WHERE SID='". $sid."' ;";
              $result_numW = mysql_query($query_numW);
              $num_w = mysql_num_rows($result_numW);
              $str_btnW = ( $num_w > 0 ) ? "value='".$num_w."' ". $strStyleY : "value='x' ". $strStyleN;              

              $query_numS = "SELECT * FROM ML_ModuleLS WHERE SID='". $sid."' ;";
              $result_numS = mysql_query($query_numS);
              $num_s = mysql_num_rows($result_numS);
              $str_btnS = ( $num_s > 0 ) ? "value='v' ". $strStyleY : "value='x' ". $strStyleN;               
              
              $songOrder = ($num_song == 1 ) ? "" : $k + 1 .") ";

              ?>

              <tr onMouseOver="this.className='normalActive'" onMouseOut="this.className='normal'" class="normal">
                  <td align="<?=$strAlign?>">&nbsp;</td>
                  <td align="<?=$strAlign?>"><font size="1" face="Verdana, Geneva, sans-serif"><?=$songOrder?><?=$song_title ?></font></td>
                  <td align="center"><input type="submit" name="CHK_N" onclick="submittoM('_admEditModule-N.php','<?=$cid?>','<?=$sid?>')" title="Edit <?=mysql_result($result_mtitle, 0, "MODULE_N");?>" <?=$str_btnN?> ></td>
                  <td align="center"><input type="submit" name="CHK_Q" onclick="submittoM('_admEditHeadingQ.php','<?=$cid?>','<?=$sid?>')" title="Edit <?=mysql_result($result_mtitle, 0, "MODULE_Q");?>" <?=$str_btnQ?> ></td>
                  <td align="center"><input type="submit" name="CHK_L" onclick="submittoM('_admEditHeadingL.php','<?=$cid?>','<?=$sid?>')" title="Edit <?=mysql_result($result_mtitle, 0, "MODULE_L");?>" <?=$str_btnL?> ></td>
                  <td align="center"><input type="submit" name="CHK_G" onclick="submittoM('_admEditHeadingG.php','<?=$cid?>','<?=$sid?>')" title="Edit <?=mysql_result($result_mtitle, 0, "MODULE_G");?>" <?=$str_btnG?> ></td>
                  <td align="center"><input type="submit" name="CHK_W" onclick="submittoM('_admEditHeadingW.php','<?=$cid?>','<?=$sid?>')" title="Edit <?=mysql_result($result_mtitle, 0, "MODULE_W");?>" <?=$str_btnW?> ></td>
                  <td align="center"><input type="submit" name="CHK_S" onclick="submittoM('_admEditModule-S.php','<?=$cid?>','<?=$sid?>')" title="Edit <?=mysql_result($result_mtitle, 0, "MODULE_S");?>" <?=$str_btnS?> ></td>
              </tr>   
                   
            <?
            }
          }
          ?>

          <tr>
          <td colspan="8"><hr noshade color="#<?=$color2?>" size="3"></td>
          </tr> 

        </table>
        </br>
      <?
      }
    }
    ?>
             </form>

	</td>
</tr>
    </table></br></br></br>
 	</td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
