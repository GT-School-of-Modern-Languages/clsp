<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SID"] ;
$qid = $_REQUEST["QID"] ;

echo $qid;

$query_delQU = "DELETE FROM ML_ModuleQU WHERE  SID='".$sid."' AND QID='".$qid."' ;";
$result_delQU = mysql_query($query_delQU);

$query_num = "SELECT * FROM ML_ModuleQU WHERE SID='".$sid."' ORDER BY Q_ORDER; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

for ( $j=0 ; $j < $num_question ; $j++)
{	
	$upd_qid = mysql_result($result_num, $j, "QID") ;
	$query_updOrder = "UPDATE ML_ModuleQU SET Q_ORDER='".($j+1)."' WHERE QID='".$upd_qid."'; ";	
	echo $query_updOrder."</br>";
	$result_updOrder = mysql_query($query_updOrder) or die(mysql_error()); 
}

$query_delHeadingQU = "DELETE FROM ML_HeadingQU WHERE QID='".$qid."' ;";
echo $query_delHeadingQU;
$result_delHeadingQU = mysql_query($query_delHeadingQU) or die(mysql_error()); 

echo $query_delQU.'</br>';


header('Location: _admEditModule-Q.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='); 
?>