<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;

$query_delLS = "DELETE FROM ML_ModuleLS WHERE  SID='".$sid."';";
$result_delLS = mysql_query($query_delLS);

header('Location: _admEditModule-S.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
echo $query_delLS;
?>