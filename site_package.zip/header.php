<?php
$input_language = $_REQUEST["ULANGUAGE"];
if ( $input_language == "" ){
header('Location:index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));

include 'def/init.php';
require ("config.php");
$link = connectDB();

if (!$link) {
echo "database connection fail!";
exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;

$query_hid = $_REQUEST["HID"];
?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<body bgcolor="#<?=$color1?>" style="margin:0px;">
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    <a onmouseover="this.style.cursor='pointer'" target="_blank" onclick="window.top.location='http://www.modlangs.gatech.edu/'"><img src=" " border="0"></a></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
    <a onmouseover="this.style.cursor='pointer'" onclick="window.top.location='http://mlg-grant.iac.gatech.edu/'"><img src="images/CSP_title_<?=$lid?>.png" border="0"></a></td>
  </tr>
</table>
</body>
</html>
