<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SID"] ;
$q_content = trim($_REQUEST["Q_CONTENT"]);
$q_types = ( $_REQUEST["Q_TYPES"] == "0" || $_REQUEST["Q_TYPES"] == "" ) ? "5" : $_REQUEST["Q_TYPES"];
$q_option = trim($_REQUEST["Q_OPTION"]);
$hid = ( $_REQUEST["HID"] == "0" || $_REQUEST["HID"] == "" ) ? "1" : $_REQUEST["HID"];

$ans = ($q_types == "8" && strlen(trim($_REQUEST["ANS"])) > 1 ) ? substr(trim($_REQUEST["ANS"]), -1) : trim($_REQUEST["ANS"]) ;
$feedback =  trim($_REQUEST["FEEDBACK"]) ;

$query_num = "SELECT * FROM ML_ModuleQU WHERE SID='".$sid."'; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

$query_addQU = "INSERT INTO ML_ModuleQU VALUES('".$sid."','','".addslashes($q_content)."','".$q_types."','".addslashes($q_option)."','".($num_question+1)."','".$ans."','".addslashes($feedback)."');" ;
$result_addQU = mysql_query($query_addQU);

$query_selQU = "SELECT * FROM ML_ModuleQU WHERE SID='".$sid."' AND Q_CONTENT='".addslashes($q_content)."' ;" ;
$result_selQU = mysql_query($query_selQU);
$qid = mysql_result($result_selQU, 0, "QID") ;

$query_addheadingQU = "INSERT INTO ML_HeadingQU VALUES('".$hid."','".$qid."');" ;
$result_addheadingQU = mysql_query($query_addheadingQU);

echo $query_addQU."</br>";
echo $query_addheadingQU;

header('Location: _admEditModule-Q.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID=#Q'.$qid); 
?>