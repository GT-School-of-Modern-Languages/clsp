<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"];
$module = $_REQUEST["MODULE"];
$heading = trim($_REQUEST["HEADING"]);
$sid = $_REQUEST["SONG_ID"];
$submitLocation = "";
//$headingNoneTitle = "";

switch($module)	
{
	case "QU":		
		$submitLocation = "_admEditModule-Q"; 
		//$headingNoneTitle = "Questions for Understanding to the Song";
		break;
	case "LT": 
		$submitLocation = "_admEditModule-L"; 
		//$headingNoneTitle = "Listening Tasks of the Song";
		break;
	case "GE":	
		$submitLocation = "_admEditModule-G"; 
		//$headingNoneTitle = "Questions about Grammer in the Song";
		break;
	case "DW":
		$submitLocation = "_admEditModule-W"; 
		//$headingNoneTitle = "Discussion and Writing of the Song";
		break;
}	
	
if ( $heading != "" )
{
	$query_maxOrder = "SELECT MAX(H_ORDER) FROM ML_Heading WHERE SID='".$sid."' AND MODULE='".$module."' ;" ;
	$result_maxOrder = mysql_query($query_maxOrder);
	$arr_maxOrder = mysql_fetch_array($result_maxOrder);

	$nextOrder = $arr_maxOrder[0] +1 ;
	echo $nextOrder;

	$query_addHeading = "INSERT INTO ML_Heading VALUES ('','".$sid."','".$module."','".addslashes($heading)."','".$nextOrder."');" ;
	$result_addHeading = mysql_query($query_addHeading);

	$query_getHID = "SELECT HID FROM ML_Heading WHERE SID='".$sid."' AND MODULE='".$module."' AND HEADING='".addslashes($heading)."' ;" ;
	$result_getHID = mysql_query($query_getHID);
	$hid = mysql_result($result_getHID, 0, "HID");	

}

header('Location: '.$submitLocation.'.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='.$hid); 
?>