<?php

$input_language = $_REQUEST["ULANGUAGE"] ;
if ( $input_language == "" ){
	header('Location:/admin/index.php'); 
}
$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");



?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php

$sid = $_REQUEST["SONG_ID"] ;

$cid = $_REQUEST["CID"];
$query_mtitle = "SELECT * FROM ML_ModuleTitle WHERE LID='".$lid."' AND CID='".$cid."';" ;
$result_mtitle = mysql_query($query_mtitle);
$title_N = mysql_result($result_mtitle, 0, "MODULE_N");
$title_Q = mysql_result($result_mtitle, 0, "MODULE_Q");
$title_L = mysql_result($result_mtitle, 0, "MODULE_L");
$title_G = mysql_result($result_mtitle, 0, "MODULE_G");
$title_W = mysql_result($result_mtitle, 0, "MODULE_W");
$title_S = mysql_result($result_mtitle, 0, "MODULE_S");

$query_song =  "SELECT * FROM ML_Song WHERE  SID='".$sid."';";
$result_song = mysql_query($query_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE");	
$lyrics = trim(mysql_result($result_song, 0, "LYRICS"));		

$lyricswTip = $lyrics;

$patterns = array();
$patterns[0] = '/\'/';
$patterns[1] = '/\"/';				
$patterns[2] = '/[\n\r]{1,2}/';		
$replacements = array();
$replacements[0] = '&#39;';
$replacements[1] = '&#34;';		
$replacements[2] = '</br>';				

?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admMediaList.php?language=<?=$input_language ?>"><span class="menu_head">Media Files</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>       
      <tr>
        <td><div class="leftModule"><span class="module_select"><?=$title_N?></span></div></td>
      </tr>  
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingQ.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_Q?></span></a></div></td>
      </tr>
     <tr>
        <td><div class="leftModule"><a href="_admEditHeadingL.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_L?></span></a></div></td>
      </tr> 
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingG.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_G?></span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftModule"><a href="_admEditHeadingW.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_W?></span></a></div></td>
      </tr>    
      <tr>
        <td><div class="leftModule"><a href="_admEditModule-S.php?ULANGUAGE=<?=$input_language?>&CID=<?=$cid?>&SONG_ID=<?=$sid?>"><span class="module_head"><?=$title_S?></span></a></div></td>
      </tr>  
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>  
      <td><div class="leftMenu"><a href="_admUploadFile.php?language=<?=$input_language ?>"><span class="menu_head">File Upload</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admFeedback.php?language=<?=$input_language ?>"><span class="menu_head">Feedback</span></a></div></td>
      </tr>          
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	<div <?=$strDirRTL?>  >  	  	
	  <table width="800" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admModuleList.php?language=<?=$input_language?>">Modules Management in <?=$input_language?> </a>>> Edit Culture Notes</div></td>
    </tr>
  <tr>
    <td><p>&nbsp;</p><p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" >
    <table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td align="center" valign="top" >
  
    <table width="100%" border="0" cellspacing="0" cellpadding="5" bgcolor="#<?=$color3?>">
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr> 
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="bottom"><font color="#<?=$color2?>">Song Title: </font></th>
        <td width="85%"><input name="SONG_TITLE_ORIGIN" type="text" readonly value="<?=$song_title?>"
        style="color: #<?=$color2?>; font-size: 14pt; font-family: Verdana; border-width: 0px; font-weight:bold; background-color: #<?=$color3?>;" size="30" maxlength="100"></td>
      </tr> 
      <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Lyrics:</font></th>
        <td width="85%">
          <table width="95%" cellspacing="0" cellpadding="5"> 
            <tr>
            	<td valign="top" bgcolor="#<?=$color2?>">
		        <table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php
$query_cn = "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."'; ";
$result_cn = mysql_query($query_cn);
$num_rows = mysql_num_rows($result_cn);

$file_link = "";
$atta_file_desc = "";

for ( $i=0 ; $i < $num_rows ; $i++)
{
	$phrase = mysql_result($result_cn, $i, "PHRASE") ;		
	$wholeline = mysql_result($result_cn, $i, "WHOLELINE") ;		
	$nid =  mysql_result($result_cn, $i, "NID") ;		
	$chk_link = mysql_result($result_cn, $i, "CHK_LINK") ;	
	$chk_doc = mysql_result($result_cn, $i, "CHK_DOC") ;	
	$chk_img = mysql_result($result_cn, $i, "CHK_IMG") ;	
	$chk_cont = mysql_result($result_cn, $i, "CHK_CONT") ;	
	$link = trim(mysql_result($result_cn, $i, "LINK") ) ;	
	$content = trim(mysql_result($result_cn, $i, "CONTENT") );		
	$content = preg_replace($patterns, $replacements, $content);
		
	$atta_img = mysql_result($result_cn, $i, "ATTA_IMG") ;	
	$img_size = mysql_result($result_cn, $i, "IMG_SIZE") ;	
		$img_size = ( round($img_size/(1024*1024),2) < 1 ) ? round($img_size/(1024),2). " KB" : round($img_size/(1024*1024),2). "MB";
	$img_mime = mysql_result($result_cn, $i, "IMG_MIME") ;	
	$atta_doc = mysql_result($result_cn, $i, "ATTA_DOC") ;	
	$doc_size = mysql_result($result_cn, $i, "DOC_SIZE") ;	
		$doc_size = ( round($doc_size/(1024*1024),2) < 1 ) ? round($doc_size/(1024),2). " KB" : round($doc_size/(1024*1024),2). "MB";
	$doc_mime = mysql_result($result_cn, $i, "DOC_MIME") ;	
	
	if ($atta_img != "/" || $atta_doc != "/" )
	{ 
		if ( $atta_img != "/" )
		{
			$file_link_img = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img;		
			$atta_file_desc .= "<a href='".$file_link_img."' target=\"_blank\"><b>".$atta_img."</b></a><font size='1'>&nbsp;[".$img_mime.", ". $img_size ."] </font></br>";				
		}
		if ( $atta_doc != "/" )
		{
			$file_link_doc = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc;		
			$atta_file_desc .= "<a href='".$file_link_doc."' target=\"_blank\"><b>".$atta_doc."</b></a><font size='1'>&nbsp;[".$doc_mime.", ". $doc_size ."] </font></br>";				
		}		
	}	
	
	$content_link = ( $chk_link == "Y" && $chk_doc != "Y" ) ? "</br>Click for more information. </br></br>" : "";
	$content_document = ( $chk_doc == "Y" ) ? "</br>Click to download related document. </br></br>" : "";
	$content_cont = ( $chk_cont == "Y" ) ? $content." </br></br>" : "";

	if ($chk_img == "Y")		
	{
			list($width, $height) = getimagesize($file_link_img);

			$newwidth = ($width > 400 ) ? 400 : $width ;
			$newheight = ($width > 400 ) ? (($height/$width)*$newwidth) : $height ;		
			if ( $newheight > 400 ){
				$newheight = 400 ;
				$newwidth = ($width/$height) * $newheight ;				
			}
	}		
	
	$content_img = ( $chk_img == "Y" ) ? "<img src=\'".$file_link_img."\' width=\'".$newwidth."\' height=\'".$newheight."\'>" : "" ;	

	$tip_link = ( $chk_link == "Y" || $chk_doc == "Y" ) ? ( ( $chk_doc == "Y") ? $file_link_doc : $link ): "javascript:void(0);" ;
	$tip_width = ($atta_img != "/" ) ? ( ($width < 400 ) ? $width : $newwidth ) : ( (strlen($content) < 45 ) ? "0" : "400" );
	$tip_content = "'" . $content_document . $content_cont . $content_img . $content_link. "',PADDING, 10, WIDTH,".$tip_width ;  
	$strTips = "href=\"".$tip_link."\" onMouseOver=\"Tip(".$tip_content.");\" onMouseOut=\"UnTip();\" ";

	$btnPhraseUpd = "<sup><a title='edit note info' href='_admEditModule-NUpd.php?ULANGUAGE=".$input_language."&CID=".$cid."&SONG_ID=".$sid."&NID=".$nid."'><font color='#800000' size='1'>[+]</font></b></a></sup>";
	
	$btnPhraseDel = "<sup><a title=\"delete this note info\" onclick=\"return confCNDel('".$phrase."')\" href=\"_admModuleNDel.php?ULANGUAGE=".$input_language."&CID=".$cid."&SONG_ID=".$sid ."&NID=".$nid."\" ><font color='#800000' size='1'>[-]</font></b></a></sup>";

	$lyricswTip = ( $phrase != "" ) ? preg_replace( '/'.$phrase.'/', "<font style='background-color: #EEE8AA'><b><a ".$strTips." target='_blank '>".$phrase."</a></b>".$btnPhraseUpd ."&nbsp;".$btnPhraseDel."</font>", $lyricswTip, 1 ) : $lyricswTip;	
}

$numLine = substr_count ($lyrics,"\n") ;
$sublyrics_tip = explode("\n", $lyricswTip );	
$sublyrics = explode("\n", $lyrics );	
for ($line=0; $line <= $numLine; $line++)
{
	$trim_lyrics = addslashes(trim($sublyrics[$line]));			
	$query_line = ($trim_lyrics == "" ) ? "" : "SELECT * FROM ML_ModuleCN WHERE  SID='".$sid."' AND WHOLELINE='". $trim_lyrics."' ";	
	$result_line = ($trim_lyrics == "" ) ? "" : mysql_query($query_line);
	$chk_wline = ($trim_lyrics == "" ) ? "0" : mysql_num_rows($result_line);
	$nid_line = "";
	$strTips_line = "";
	
	if ( $chk_wline != 0 ) 
	{
		
		$nid_line = mysql_result($result_line, 0, "NID");		
		$link_line = mysql_result($result_line, 0, "LINK") ;	
		$content_line = addslashes(trim(mysql_result($result_line, 0, "CONTENT") ) );							
		$content_line = preg_replace($patterns, $replacements, $content_line);
	
		$atta_img_line = mysql_result($result_line, 0, "ATTA_IMG") ;	
		$atta_doc_line = mysql_result($result_line, 0, "ATTA_DOC") ;	
		$file_link_img_line = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_img_line;		
		$file_link_doc_line = "attachment/".  strtoupper(substr($input_language, 0, 3)) ."/".$atta_doc_line;	
//		echo $file_link_img_line;
		$content_link_line = ( $link_line != "http://" ) ? " </br> Click for more information. </br></br>" : ""; 
		$content_document_line = ( $atta_doc_line != "/" ) ? "</br>Click to download related document. </br></br>" : "";
		$content_cont_line = ( ! empty($content_line) ) ? $content_line." </br></br>" : "";

		if ($atta_img_line != "/")		
		{
			list($width, $height) = getimagesize($file_link_img_line);
			$newwidth =($width > 400 ) ? 400 : $width ;
			$newheight = ($width > 400 ) ? (($height/$width)*$newwidth) : $height ;		
		}		
	
		$content_img_line = ( $atta_img_line != "/" ) ? "<img src=\'".$file_link_img_line."\' width=\'".$newwidth."\' height=\'".$newheight."\'>" : "" ;	

		$tip_link_line = ( $link_line != "http://" || $atta_doc_line != "/" ) ? ( ( $atta_doc_line != "/") ? $file_link_doc_line : $link_line ): "javascript:void(0);" ;
		$tip_width_line = ($atta_img_line != "/" ) ? ( ($width < 400 ) ? $width : $newwidth ) : ( (strlen($content_line) < 45 ) ? "0" : "400" );
		$tip_content_line = "'" . $content_document_line . $content_cont_line . $content_img_line . $content_link_line. "',PADDING, 10, WIDTH,".$tip_width_line ;  
		$strTips_line = "href=\"".$tip_link_line."\" onMouseOver=\"Tip(".$tip_content_line.");\" onMouseOut=\"UnTip();\" ";
	}	
	
	$btnLineUpd = "<sup><a href='_admEditModule-NUpd.php?ULANGUAGE=".$input_language."&CID=".$cid."&SONG_ID=".$sid."&NID=".$nid_line."'><font color='#800000' size='1'>[+]</font></b></a></sup>&nbsp;";

	$btnLineDel = "<sup><a title=\"delete this note info\" onclick=\"return confCNDel('".trim($sublyrics[$line])."')\" href='_admModuleNDel.php?ULANGUAGE=".$input_language."&CID=".$cid."&SONG_ID=".$sid."&NID=".$nid_line."'><font color='#800000' size='1'>[-]</font></b></a></sup>&nbsp;";		
	
	$strBtn_withLine = "<font style='background-color: #EEE8AA'>&nbsp;". $btnLineUpd .$btnLineDel."<a ".$strTips_line." target='_blank '> &diams;</a></font>&nbsp;";	
			        	   
	$strBtn_noLine = "<input type='button' value='&loz;' title='click to add whole line as key phrase.' onClick='selectLine(\"".$trim_lyrics."\");' style='background: #<?=$color2?>; border-width: 0px; color: #EEE8AA; font-size: 8pt; font-family: Verdana; cursor: pointer; '>";
	
	$strBtn_Line = ( $chk_wline != 0 ) ? $strBtn_withLine : ( $trim_lyrics == ""  ? "&nbsp;" : $strBtn_noLine) ;

?>
        			<tr>
       				 <td width="80" align="right" ><font size="2"><?=$strBtn_Line?>&nbsp;</font></td>
			        <td><font color="#000000" size="2"><?=$sublyrics_tip[$line]?></font></td>
			        </tr>
<?
}
?>
 		       </table>            	
            	</td>
            	</tr>
            	<tr>
            	<td valign="bottom" bgcolor="#<?=$color2?>" align="right">
                <input type="button" value="SELECT" onClick="selectPhrase();"
                style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">    
                </td>
        	</tr> 
        </table>   
        </td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr> 
     <Form name="NOTES" method="post" enctype="multipart/form-data" id="mainForm" onSubmit="return chkSubm()">
     <input name="CID" type="hidden" value="<?=$cid?>">
     <input name="SID" type="hidden" value="<?=$sid?>">
     <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">     
     <input name="chkForm" id="chkForm" type="hidden" value="">          
	 <tr id="showLine" style="display: none">
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Key Phrase:</font></th>
        <td width="85%">
        <input name="WHOLELINE" type="text" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="50" maxlength="64">
        </td>
      </tr> 
	 <tr id="showPhrase" style="display: ">
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Key Phrase:</font></th>
        <td width="85%">
        <input name="PHRASE" type="text" style="color: #000000; font-size: 10pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" value="" size="30" maxlength="64">
        </td>
      </tr> 
	 <tr>
        <th width="15%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Type:</font></th>
        <td width="85%"><font size="2" color="#<?=$color2?>">
	     <input id="chk_value1" name="CHK_LINK" type="hidden" value="N">
    	 <input id="chk_value2" name="CHK_CONT" type="hidden" value="N">       
	     <input id="chk_value3" name="CHK_IMG" type="hidden" value="N">
    	 <input id="chk_value4" name="CHK_DOC" type="hidden" value="N">
        <label><input id="chk1" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(1)">&nbsp;Outer Link</label></br>
        <label><input id="chk2" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(2)">&nbsp;Usage Description</label></br>
        <label><input id="chk3" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(3)">&nbsp;Mouse-over Image</label></br>
        <label><input id="chk4" type="checkbox" name="CHK_TYPE" value="Y" onclick="showInput(4)">&nbsp;Related Document</label></br>
      	</font></td>
      </tr> 
       <tr id="input1" style="display: none;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Link:</font></th>
        <td width="75%">
		<textarea name="LINK" rows="2" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" dir="ltr">http://</textarea>        
        </td>
      </tr>       
       <tr id="input2" style="display: none;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Description:</br></font></th>
        <td width="75%">
		<textarea name="CONTENT"  rows="5" cols="50" style="color: #000000; font-size: 10pt; font-family: Verdana; border-style: solid; border-width: 1px; border-color: #<?=$color2?>; background-color: #<?=$color3?>;"></textarea>        
        </td>
      </tr> 
       <tr  id="input3" style="display: none;">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Image File:</font></th>
        <td width="75%">
        <input name="ATTA_IMG" type="file" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="45">         
        </td>
      </tr> 
       <tr id="input4" style="display: none; ">
        <th width="25%" align="<?=$strTHAlign?>" valign="top"><font color="#<?=$color2?>">Document File:</font></th>
        <td width="75%">
        <input name="ATTA_DOC" type="file" 
        style="color: #000000; font-size: 10pt; font-family: Verdana; border-width: 1px; border-style: solid; border-color: #<?=$color2?>; background-color: #<?=$color3?>;" size="45">         
        </td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="3"></td>
      </tr>             

      <tr> 
        <td colspan="2" align="right" valign="top">  
        <input type="reset" value="CLEAR" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 10pt; font-family: Verdana;">     
        <input type="submit" value="SAVE" onclick="submittoN('_admModuleNAdd.php')" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; "></br>     
       </td>
      </tr> 

       <tr>
        <td width="25%" align="<?=$strTHAlign?>" valign="top"><font size="2" color="#<?=$color2?>">Current attachment: </td>
        <td width="75%"><font size="2" color="#<?=$color2?>"><?=$atta_file_desc?></font>
        </td>
      </tr> 
      <tr>
        <td colspan="2" align="right" valign="top"><hr noshade color="#<?=$color2?>" size="1"></td>
	 </tr> 
    </table> 
    </Form>   
    </td>
  </tr>
    </table>   
    </td>
  </tr> 
</table>
</br></br></br>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>
