<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$cid = $_REQUEST["CID"] ;
$sid = $_REQUEST["SONG_ID"] ;
$lid = $_REQUEST["LID"] ;

$query_delLT = "DELETE FROM ML_ModuleLT WHERE  SID='".$sid."' AND LID='".$lid."' ;";
$result_delLT = mysql_query($query_delLT);

$query_num = "SELECT * FROM ML_ModuleLT WHERE SID='".$sid."' ORDER BY L_ORDER; " ;
$result_num= mysql_query($query_num);
$num_question = mysql_num_rows($result_num);

for ( $j=0 ; $j < $num_question ; $j++)
{	
	$qestion_id = mysql_result($result_num, $j, "LID") ;
	$query_updOrder = "UPDATE ML_ModuleLT SET L_ORDER='".($j+1)."' WHERE LID='".$qestion_id."'; ";	
	echo $query_updOrder."</br>";
	$result_updOrder = mysql_query($query_updOrder) or die(mysql_error()); 
}

$query_delHeadingLT = "DELETE FROM ML_HeadingLT WHERE LID='".$lid."' ;";
$result_delHeadingLT = mysql_query($query_delHeadingLT);

header('Location: _admEditModule-L.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='); 
?>