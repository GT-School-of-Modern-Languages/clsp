<?php

require ("config.php");
$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$input_language = $_REQUEST["ULANGUAGE"] ;
$login = $_REQUEST["LOGIN"] ;

if ( $input_language == "" ){
  header('Location: index.php'); 
}

$msg = ( $login == "0" ) ? "<font color='#800000' size='1'>Account and password are not match,  or, this account has expired. </br>Please check and re-enter again. </font>" : "";  
	

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Georgia Tech Critical Language Song Project</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>    
    <td width="250" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
        <img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></br>
      </a>
    </td>
    <td align="left" valign="center" bgcolor="#<?=$color1?>">

    </td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="800"><p>&nbsp;</p>
	</td>
    <td align="center" valign="top">
	<table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td>&nbsp;</td>
    	</tr>
 		<tr>
    	<td align="center" ><p></p>    
    <form name="LOGIN" method="post" action="_chkLogin.php"">
    <input name="ULANGUAGE" type="hidden" value="<?=$input_language?>">    
    <table width="600" border="0" cellspacing="0" cellpadding="10" bgcolor="#CCCC99">
	  <tr bgcolor="#FFFFFF">
	    <th colspan="2">
	    <font size="4" color="#<?=$color2?>">Please login to enter <?=$input_language?> course(s). </font>
	    </th>
      </tr>  
	  <tr bgcolor="#FFFFFF">
	    <th colspan="2">&nbsp;<?=$msg?>&nbsp;<p><p></th>
      </tr>  
	  <tr>
	    <td colspan="2"><hr noshade color="#<?=$color2?>" size="1"></td>
      </tr>      
      <tr>
        <th width="20%" valign="top"><font color="#<?=$color2?>">Account: </font></th>
        <td width="80%" valign="top">        
        	<input name="ACC_NAME" type="text" style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #CCCC99;" value="" size="50" maxlength="100">
        </td>
      </tr>
      <tr>
        <th width="20%" valign="top"><font color="#<?=$color2?>">Password: </font></th>
        <td width="80%" valign="top">        
        	<input name="ACC_PWD" type="password" style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #CCCC99;" value="" size="50" maxlength="100">
        </td>
      </tr>    
	  <tr>
	    <td colspan="2"><hr noshade color="#<?=$color2?>" size="1"></td>
      </tr>     
	  <tr bgcolor="#FFFFFF">
	    <th width="20%" valign="top">&nbsp;</th>
        <td width="80%" valign="top" align="right">                
        <input type="submit" value="SUBMIT" style="background: #<?=$color2?>; border-width: 0px; color: #FFFFFF; font-size: 10pt; font-family: Verdana; cursor: pointer; ">
        </font>
        </td>
     </tr>                  
    </table>
    </form>
    </td>
    </tr>                  
    </table>    
    </td>
  </tr>
  <tr height="25" bgcolor="#<?=$color1?>">
    <td align="center" valign="middle">&nbsp;</td>
    <td align="right" valign="middle" >
    <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
    </table>
    </td>
  </tr> 
</table>
</body>
</html>
