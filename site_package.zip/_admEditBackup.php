<?php

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$ui_location = $_POST['UI_LOCATION'];
$db_location = $_POST['DB_LOCATION'];

if(substr($ui_location, strlen($ui_location)-1) != "/") {
	$succ = -2;
	header("Location: _admBackupFiles.php?succ=" . $succ);
} else if(substr($db_location, strlen($db_location)-1) != "/") {
	$succ = -3;
	header("Location: _admBackupFiles.php?succ=" . $succ);
} else {
	$query_mainTitle = "UPDATE ML_UI SET TEXT='" . $ui_location . "' WHERE NAME='UI_LOCATION'";
	$result_mainTitle = mysql_query($query_mainTitle);

	$query_contents = "UPDATE ML_UI SET TEXT='" . $db_location. "' WHERE NAME='DB_LOCATION'";
	$result_contents = mysql_query($query_contents);

	$BASE = BACKUP_BASE_PATH;
	$UI_PATH = $ui_location;
	$DB_PATH = $db_location;
	$FILE_FORMAT = "Downloadable_";

	$UI_FPATH = $BASE . $UI_PATH;
	$DB_FPATH = $BASE . $DB_PATH;

	$date = date('mdY_His', time());

	shell_exec('mkdir ' . $UI_FPATH);        
	$output = shell_exec('zip -r ' . $UI_FPATH . $FILE_FORMAT . $date . ' ../Downloadable');
	shell_exec('mkdir ' . $DB_FPATH);
	exec('mysqldump -u ' . MYSQL_CONNECT_USER . ' --password=' . MYSQL_CONNECT_PASS . ' ' . MYSQL_DB_NAME . ' > ' . $DB_FPATH . $FILE_FORMAT . $date . '.sql');

	$output1 = shell_exec('ls ' . $UI_FPATH . '/' . $FILE_FORMAT . $date . '.zip');
	$output2 = shell_exec('ls ' . $DB_FPATH . '/' . $FILE_FORMAT . $date . '.sql');

	if($output1 != '' && $output2 != '') {
		$succ = 3;
	} 
	else if($output1 == '') {
		$succ = 1;
	} else if($output2 == '') {
		$succ = 2;
	} else {
		$succ = 0;
	}

	header("Location: _admBackupFiles.php?succ=" . $succ);

}
?>