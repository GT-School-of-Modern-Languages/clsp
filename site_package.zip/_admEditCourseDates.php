<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$cpid = $_REQUEST["CPID"];
$cid = $_REQUEST["CID"];

if ( $cpid == "" || $cid == "" ){
	header('Location:./admin/'); 
}

$strAccess_s = $_REQUEST["ACCESS_START"];
$strAccess_e = $_REQUEST["ACCESS_END"];

$access_s = ($status != "DEL" && $strAccess_s != "" ) ? substr($strAccess_s, 6, 4). "-".substr($strAccess_s, 0, 2)."-".substr($strAccess_s, 3, 2) : date("Y-m-d") ;
$access_e = ($status != "DEL" && $strAccess_e != "" ) ? substr($strAccess_e, 6, 4). "-".substr($strAccess_e, 0, 2)."-".substr($strAccess_e, 3, 2) : "9999-12-31";


$query_courseAccess="UPDATE ML_CourseAccess SET DATE_START='".$access_s."' , DATE_END='". $access_e . "' WHERE CID='" . $cid . "' AND CPID='" . $cpid . " '; ";
$result_courseAccess=mysql_query($query_courseAccess);

//echo $query_courseAccess;
header('Location: popup-access.php?acid='. $cpid);

?>