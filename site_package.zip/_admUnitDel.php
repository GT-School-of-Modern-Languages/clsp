<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_GET["ULANGUAGE"] ;
$lid = strtoupper(substr($input_language, 0, 3));
$unit_id = $_POST["UNIT_ID"] ;

//----------------- delete module info
$query_delModuleCN = "DELETE FROM ML_ModuleCN WHERE SID like'". $unit_id . "%' ;"  ;
$result_delModuleCN = mysql_query($query_delModuleCN);	

$query_delModuleDW = "DELETE FROM ML_ModuleDW WHERE SID like'". $unit_id . "%' ;"  ;
$result_delModuleDW = mysql_query($query_delModuleDW);	

$query_delModuleGE = "DELETE FROM ML_ModuleGE WHERE SID like'". $unit_id . "%' ;"  ;
$result_delModuleGE = mysql_query($query_delModuleGE);	

$query_delModuleLS = "DELETE FROM ML_ModuleLS WHERE SID like'". $unit_id . "%' ;"  ;
$result_delModuleLS = mysql_query($query_delModuleLS);	

$query_delModuleLT = "DELETE FROM ML_ModuleLT WHERE SID like'". $unit_id . "%' ;"  ;
$result_delModuleLT = mysql_query($query_delModuleLT);	

$query_delModuleQU = "DELETE FROM ML_ModuleQU WHERE SID like'". $unit_id . "%' ;"  ;
$result_delModuleQU = mysql_query($query_delModuleQU);	

//----------------- delete media files info
$query_selFile = "SELECT FILE_NAME FROM ML_Song WHERE SID like'". $unit_id . "%' ;"  ;
$result_selFile = mysql_query($query_selFile);	
$num_rows = mysql_num_rows($result_selFile);	

if ( $num_rows != 0 ) 
{

	$file_name = mysql_result($result_selFile, 0, "FILE_NAME") ;
	unlink("listenings/".  strtoupper(strtoupper(substr($input_language, 0, 3)))."/".$file_name);

	$query_delMediaUnder = "DELETE FROM ML_SongDetail WHERE FILE_NAME='". $file_name . "%' ;"  ;
	$result_delMediaUnder = mysql_query($query_delMediaUnder);	
	
}

//----------------- delete song info
$query_delSongsUnder = "DELETE FROM ML_Song WHERE SID like'". $unit_id . "%' ;"  ;
$result_delSongUnder = mysql_query($query_delSongsUnder);	

//----------------- delete unit info
$query_delUnit = "DELETE FROM ML_Unit WHERE UNIT_ID='". $unit_id . "' ;"  ;
$result_delUnit = mysql_query($query_delUnit);	

//----------------- delete unit access
$query_delUnitAccess = "DELETE FROM ML_UnitAccess WHERE UNIT_ID='". $unit_id . "' ;"  ;
$result_delUnitAccess = mysql_query($query_delUnitAccess);	

//------------------ update unit order
$query_selUnitOrd = "SELECT * FROM ML_Unit WHERE UNIT_ID like '". $lid . "%' ORDER BY UNIT_ORDER;"  ;
$result_selUnitOrd  = mysql_query($query_selUnitOrd);
$num_UnitOrd = mysql_num_rows($result_selUnitOrd);
for ( $j=0 ; $j < $num_UnitOrd ; $j++)
{
	$updUID =  mysql_result($result_selUnitOrd, $j, "UNIT_ID");	
	$query_updUnitOrd = "UPDATE ML_Unit SET UNIT_ORDER='".($j+1)."' WHERE UNIT_ID='".$updUID."'; ";
	$result_updUnitOrd = mysql_query($query_updUnitOrd);		
	echo $query_updUnitOrd."</br>";
}

//----------------- delete courseunit info
$query_delCourseUnit = "DELETE FROM ML_CourseUnit WHERE UNIT_ID='". $unit_id . "' ;"  ;
$result_delCourseUnit = mysql_query($query_delCourseUnit);	

header('Location: _admUnitList.php?language='.$input_language); 

?>