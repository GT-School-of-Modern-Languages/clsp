<?php
$saveString = $_POST["saveString"];
header('Content-disposition: attachment; filename=Result.html');
header('Content-type:application/octet-stream');
file_put_contents('php://output',$saveString);
?> 
