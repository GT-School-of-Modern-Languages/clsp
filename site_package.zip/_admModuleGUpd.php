<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$sid = $_REQUEST["SID"] ;
$cid = $_REQUEST["CID"] ;
$hid = ( $_REQUEST["HID"] == "0" || $_REQUEST["HID"] == "" ) ? "1" : $_REQUEST["HID"];
$gid = $_REQUEST["GID"] ;
$g_content = trim($_REQUEST["G_CONTENT"]);
$g_types = $_REQUEST["G_TYPES"] ;
$g_option = trim($_REQUEST["G_OPTION"]) ;

$ans = ($g_types == "8" && strlen(trim($_REQUEST["ANS"])) > 1 ) ? substr(trim($_REQUEST["ANS"]), -1) : trim($_REQUEST["ANS"]) ;
$feedback = trim($_REQUEST["FEEDBACK"]);

	switch($g_types)	
	{
		case "1":		//Open-Ended Question
			$l_option = "";
			$ans = "";
			$feedback = "";				
			break;
		case "2": 	//Fill-In Blank Question
			$g_option = "";
			$ans = "";
			$feedback = "";					
			break;
		case "3":		//Multiple-Choice Question
			$feedback = "";			
			break;
		case "4":		//Single-Choice Question
			$feedback = "";				
			break;
		case "5":		//Plain Text
			$g_option = "";
			$ans = "";
			$feedback = "";		
			break;						
		case "6": 	//Fill-In Blank Question with feedback
			$g_option = "";
			$ans = "";		
			break;
	}	


// ----------------------------------------------------------- update the ge info ------------------------------

$query_updGE = "UPDATE ML_ModuleGE SET G_CONTENT='".addslashes($g_content)."', G_TYPES='".$g_types."', G_OPTION='".addslashes($g_option)."', ANS='".addslashes($ans)."', FEEDBACK='".addslashes($feedback)."' WHERE GID='".$gid."' ;";

$result_updGE= mysql_query($query_updGE);

$query_updHeadingQU = "UPDATE ML_HeadingGE SET HID='".$hid."' WHERE GID='".$gid."' ;";
$result_updHeadingQU = mysql_query($query_updHeadingQU);

echo $query_updGE;

header('Location: _admEditModule-G.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid.'&HID='); 
?>