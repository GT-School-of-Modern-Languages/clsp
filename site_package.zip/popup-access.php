<?php

$acid = $_GET["acid"] ;
if ( $acid == "" ){
	header('Location:./admin/'); 
}


//$lid = strtoupper(substr($input_language, 0, 3));
$thisyear = date("Y"); 

require ("config.php");
include 'def/init.php';

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$color3=mysql_result($result_color, 0, "color3");

$query_coursePWD="SELECT * FROM ML_CoursePWD WHERE ACID='".$acid."'; ";
$result_coursePWD=mysql_query($query_coursePWD);
$lid=mysql_result($result_coursePWD, 0, "LID");

$query_course="SELECT * FROM ML_Course WHERE LID='".$lid."' ORDER BY CID; ";
$result_course=mysql_query($query_course);
$num_course=mysql_num_rows($result_course);

$query_courseAccess="SELECT * FROM ML_CourseAccess WHERE CPID='".$acid."' ORDER BY CID; ";
$result_courseAccess=mysql_query($query_courseAccess);
$num_courseAccess=mysql_num_rows($result_courseAccess);

$array = array();
$array_date_s = array();
$array_date_e = array();

for($i=0; $i<$num_courseAccess; $i++){ 
	$already_cid=mysql_result($result_courseAccess, $i, "CID");
	$date_s = mysql_result($result_courseAccess, $i, "DATE_START");
	$date_e = mysql_result($result_courseAccess, $i, "DATE_END");
	array_push($array, $already_cid);
	array_push($array_date_s, $date_s);
	array_push($array_date_e, $date_e);
}

$size = sizeof($array);

?>

<script type="text/javascript">
    function CloseWindow() {
        window.close();
        window.opener.location.reload();
    }
    function moveToRight(url, cpid) {
    	var e = document.getElementById("leftSelect");
    	var selected = e.options[e.selectedIndex].value;

    	document.ACCESS.CPID.value = cpid;
    	document.ACCESS.CID.value = selected;
    	document.ACCESS.action = url;
    }
    function moveToLeft(url, cpid) {
    	var e = document.getElementById("rightSelect");
    	var selected = e.options[e.selectedIndex].value;

    	document.ACCESS.CPID.value = cpid;
    	document.ACCESS.CID.value = selected;
    	document.ACCESS.action = url;
    }
    function changeDate(url, cpid) {
    	var e = document.getElementById("rightSelect");
    	var selected = e.options[e.selectedIndex].value;

    	document.ACCESS.CPID.value = cpid;
    	document.ACCESS.CID.value = selected;
    	document.ACCESS.action = url;
    }
    function rightSelected(index) {
    	document.getElementById('leftSelect').value = "";

    	var array_s = <?php echo json_encode($array_date_s);?>;
    	var array_e = <?php echo json_encode($array_date_e);?>;

    	var array_s_split = array_s[index].split("-");
    	var year_s, month_s, date_s;
    	for(i=0; i<array_s_split.length; i++){
    		if(i == 0) year_s = array_s_split[i];
    		else if(i == 1) month_s = array_s_split[i];
    		else if(i == 2) date_s = array_s_split[i];
    	}

    	var array_e_split = array_e[index].split("-");
    	var year_e, month_e, date_e;
		for(i=0; i<array_e_split.length; i++){
    		if(i == 0) year_e = array_e_split[i];
    		else if(i == 1) month_e = array_e_split[i];
    		else if(i == 2) date_e = array_e_split[i];
    	}

    	//var d_s = new Date(Date.parse(convertDate(array_s[index])));


    	document.getElementById('ACCESS_START').value = month_s + "/" + date_s + "/" + year_s;
    	document.getElementById('ACCESS_END').value = month_e + "/" + date_e + "/" + year_e;


    }

    function leftSelected() {
    	document.getElementById('rightSelect').value = "";
    	document.getElementById('ACCESS_START').value = "";
    	document.getElementById('ACCESS_END').value = "";
    }

    function convertDate(stringdate) {
    	stringdate = stringdate.replace(/-/g, "/");
	    return stringdate;
	}	
</script>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
<link rel="stylesheet" type="text/css"href="script/cal/calendar.css">
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<script language="JavaScript" type="text/javascript" src="script/cal/calendar_us.js"></script>

<table align="center">

<form name="ACCESS" method="post" action="">
<input name="CPID" type="hidden" value="">
<input name="CID" type="hidden" value="">	    
<input name="ULANGUAGE" type="hidden" value="<?=$input_language?>" readonly>	
<input name="language" type="hidden" value="<?=$input_language?>" readonly>	    
<input name="STATUS" type="hidden" value="" readonly>	
<input name="ACID" type="hidden" value="" readonly>	

</br>
</br>

<tr>
	<td align="center">
		<font size="2">DATE_START</font>
		<input name="ACCESS_START" id="ACCESS_START" type="text" style="color: #333; font-size: 9pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #BDB76B; background-color: #FFFFFF;" value="" size="10" maxlength="10" >
		<script language="JavaScript"> new tcal ({ 'formname': 'ACCESS', 'controlname': 'ACCESS_START'}); </script> 
	</td>
	<td></td>
	<td align="center">
		<font size="2">DATE_END</font>
	    <input name="ACCESS_END" id="ACCESS_END" type="text" style="color: #333; font-size: 9pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #BDB76B; background-color: #FFFFFF;" value="" size="10" maxlength="10">		
		<script language="JavaScript"> new tcal ({ 'formname': 'ACCESS', 'controlname': 'ACCESS_END'}); </script>   
	</td>
</tr>

<tr>
	<td align="center" valign="center" bgcolor="#<?=$color3?>">
	<font> Courses </font>
	</br>
	<select id="leftSelect" size="<?=$num_course?>" style="width:300px" onchange="leftSelected();">
		<?
	  	for($i=0; $i<$num_course; $i++) {
	  		$new_cid=mysql_result($result_course, $i, "CID");
			if(!in_array($new_cid, $array)) {
				?>	
				<option value="<?=$new_cid?>"><?=mysql_result($result_course, $i, "COURSE_TITLE")?></option>
				<?
			}
		}
		?>
	</select>
	</td>

	<td>
		<input type="submit" value=">>" onclick="moveToRight('_admCourseAccessAdd.php', '<?=$acid?>');" />
	</br>
		<input type="submit" value="<<" onclick="moveToLeft('_admCourseAccessDel.php', '<?=$acid?>');" />
	</td>

	<td align="center" valign="center" bgcolor='#<?=$color3?>'>
	<font> Account Courses </font>
	</br>
	<select id="rightSelect" size="<?=$num_course?>" style="width:300px" onchange="rightSelected(this.selectedIndex);">
		<?
	  	for($i=0; $i<$num_course; $i++) {
	  		$new_cid=mysql_result($result_course, $i, "CID");
	  		if(in_array($new_cid, $array)) {
				?>	
				<option value="<?=$new_cid?>"><?=mysql_result($result_course, $i, "COURSE_TITLE")?></option>
				<?
			}
		}
		?>
	</select>
	</td>


</tr>
<tr>
	<td></td>
	<td></td>
	<td><input type="submit" value="Edit Dates" onclick="changeDate('_admEditCourseDates.php', '<?=$acid?>');" /></td>	
</tr>

</form>

</table>

<asp:Button ID="btnServer" runat="server" OnClick="btnServer_Click" Text="Request server" />
</br>
</br>      
</br>  
<input type="button" value="Close Window" onclick="javascript: return CloseWindow();" />


</body>
</html>


















