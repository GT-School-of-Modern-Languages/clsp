<?php
session_start();

$input_language = $_REQUEST["ULANGUAGE"];
if ( $input_language == "" ){
header('Location:index.php'); 
}
if(!isset($_SESSION['ACID'])) {
  header("Location: login.php?ULANGUAGE=" . $input_language);
}

$acid = $_SESSION['ACID'];
$_SESSION['ACID'] = $acid;
$lid = strtoupper(substr($input_language, 0, 3));


include 'def/init.php';
require ("config.php");
$link = connectDB();

if (!$link) {
echo "database connection fail!";
exit(-1);
}
$sid = $_REQUEST["SID"] ;
$pwd = $_REQUEST["PWD"] ;
$unit_id = substr($sid, 0, 6);

$query_email="SELECT * FROM ML_FeedbackEM WHERE LANGUAGE='$input_language'";
$result_email=mysql_query($query_email);
$email=mysql_result($result_email,0, "Email");

$_SESSION['email']=$email;

$query_hid = $_REQUEST["HID"];
$query_song = "SELECT * FROM ML_Song WHERE SID='". $sid ."'; ";
$result_song = mysql_query($query_song);
$num_songs = mysql_num_rows($result_song);
$song_title = mysql_result($result_song, 0, "SONG_TITLE") ;
$len_song_title = mb_strlen($song_title,'UTF-8');
$s_song_title  = ($len_song_title > 30 ) ? substr($song_title, 0, 25) . "..." : $song_title ;

$strArbSize = ( $input_language == "Arabic" ) ? 4 : 2 ;
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$query_acc_course = "SELECT * FROM ML_Course, ".
                      "(SELECT * FROM ML_CourseAccess ".
                          "WHERE CPID='". $acid ."' ". 
                          "AND ML_CourseAccess.DATE_START <= '". date("Y-m-d") . "' ".   
                          "AND ML_CourseAccess.DATE_END > '". date("Y-m-d") . "' ".
                      ") AS courseAccess ". 
                      "WHERE ML_Course.CID=courseAccess.CID AND ML_Course.LID='".$lid."' ORDER BY ML_Course.CID; ";

$result_acc_course = mysql_query($query_acc_course);
$num_acc_course = mysql_num_rows($result_acc_course);

?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=PJ_HEAD_TITLE?></title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
     <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
        <img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></a></td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
        <font size="10" color="black"> </font></a></td>
  </tr>
</table>
<br>
<br>
<br>
<body style="background-color:#<?=$color1?>" width="100%" height="100%">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a onmouseover="this.style.cursor='pointer'" onclick="window.top.location='songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$sid?>&PWD=<?=$pwd?>'"><span class="menu_head"><font color="#<?=$color2?>"><b><?=$s_song_title?></b></font></span></div></td>
      </tr>
<?
$query_numN = "SELECT * FROM ML_ModuleCN WHERE SID='". $sid."' ;";
$result_numN = mysql_query($query_numN);
$num_n = mysql_num_rows($result_numN); 

$query_chkLyrics = "SELECT LYRICS FROM ML_Song WHERE SID='". $sid."' ;";
$result_chkLyrics = mysql_query($query_chkLyrics);
$chkLyrics = mysql_result($result_chkLyrics, 0, "LYRICS");

$num_n = ( $num_n == 0 && $chkLyrics != "" ) ? 1 : $num_n;

$query_numQ = "SELECT * FROM ML_ModuleQU WHERE SID='". $sid."' ;";
$result_numQ = mysql_query($query_numQ);
$num_q = mysql_num_rows($result_numQ);

$query_numL = "SELECT * FROM ML_ModuleLT WHERE SID='". $sid."' ;";
$result_numL = mysql_query($query_numL);
$num_l = mysql_num_rows($result_numL);

$query_numG = "SELECT * FROM ML_ModuleGE WHERE SID='". $sid."' ;";
$result_numG = mysql_query($query_numG);
$num_g = mysql_num_rows($result_numG);

$query_numW = "SELECT * FROM ML_ModuleDW WHERE SID='". $sid."' ;";
$result_numW = mysql_query($query_numW);
$num_w = mysql_num_rows($result_numW);

$query_numS = "SELECT * FROM ML_ModuleLS WHERE SID='". $sid."' ;";
$result_numS = mysql_query($query_numS);
$num_s = mysql_num_rows($result_numS);

$query_course = "SELECT * FROM ML_CourseUnit, ML_Course ".
                        "WHERE ML_CourseUnit.CID = ML_Course.CID ".
                        "AND ML_CourseUnit.UNIT_ID='".$unit_id."' ;";
                        
$result_course = mysql_query($query_course);
$current_course_title  = mysql_result($result_course, 0, "COURSE_TITLE");
$current_cid  = mysql_result($result_course, 0, "CID");

$lid = strtoupper(substr($input_language, 0, 3));
$query_module_title = "SELECT * FROM ML_ModuleTitle WHERE CID='".$current_cid."' AND LID='".$lid."';";
$result_module_title = mysql_query($query_module_title);
$mn_title = ($num_n != 0 ) ? mysql_result($result_module_title, 0, "MODULE_N") : "" ;
$mq_title  = ($num_q != 0 ) ? mysql_result($result_module_title, 0, "MODULE_Q") : "" ;
$ml_title  = ($num_l != 0 ) ? mysql_result($result_module_title, 0, "MODULE_L") : ""  ;
$mg_title  = ($num_g != 0 ) ? mysql_result($result_module_title, 0, "MODULE_G") : ""  ;
$mw_title  = ($num_w != 0 ) ? mysql_result($result_module_title, 0, "MODULE_W") : ""  ;
$ms_title  = ($num_s != 0 ) ? mysql_result($result_module_title, 0, "MODULE_S") : ""  ;

$query_module = "SELECT * FROM ML_Module ORDER BY MOD_INDEX;";
$result_module = mysql_query($query_module);
$num_module = mysql_num_rows($result_module);

for ($i=0 ; $i< $num_module ; $i++){
$page = mysql_result($result_module, $i, "MOD_PAGE");
$module = mysql_result($result_module, $i, "MODUEL");
$moduel_title = "";
$chkModule = 0 ;

switch($module)
{
	case "Listening Task":
			
			$chkModule = $num_l ;
			if($ml_title=="")
				$moduel_title = $module;
			else
				$moduel_title= $ml_title;
			break;
		case "Culture Notes":
			$chkModule = $num_n ;
			if($mn_title=="")
				$moduel_title = $module;
			else
				$moduel_title=$mn_title;
			break;
		case "Grammar Exercise":
			$chkModule = $num_g ;	
			if($mg_title=="")	
				$moduel_title = $module;
			else
				$moduel_title=$mg_title;
			break;
		case "Questions for Understanding":
			$chkModule =  $num_q ;
			if($mq_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mq_title;
			break;
		case "Discussion and Writing":
			$chkModule = $num_w ;
			if($mw_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $mw_title;
			break;
		case "Listening Suggestion": 	
			$chkModule = $num_s ;
			if($ms_title=="")
				$moduel_title = $module;
			else
				$moduel_title = $ms_title;
			break;
			}
if ( $chkModule != 0 ) {

$strHead = ( $module == "Listening Task" ) ? "<span class=\"menu_select\"><font size=\"$strArbSize\">".$moduel_title."</font></span>" :
"<a onmouseover=\"this.style.cursor='pointer'\" onclick=\"window.top.location='".$page."?ULANGUAGE=".$input_language."&SID=".$sid."&PWD=".$pwd."&HID=0'\"><span class=\"menu_head\"><font size=\"$strArbSize\" color=\"#383838\">".$moduel_title."</font></span></a>" ;
?>
      <tr>
        <td><div class="leftMenu"><?=$strHead?></div></td>
      </tr>
<?
}
}
?>  
    </table>


    
<link href="css/navstyle2.php" rel="stylesheet" type="text/css" />


<ul id="nav" >
   
<?

if($num_acc_course==1){
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;

        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {  

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>" target="_top">Navigation</a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                              "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                              "AND ML_CourseUnit.CID='".$each_cid."' ".
                                              "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);


                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>" target="_top"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);
                        for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>" target="_top"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}?>
                </ul>
           </li>
    <?}}
}
else{
    ?>
    <li><a href="#">Navigation</a>
        <ul><?
    for ( $i=0 ; $i < $num_acc_course ; $i++)
    {
        $each_cid = mysql_result($result_acc_course, $i, "CID") ;
        $course_title2 = mysql_result($result_acc_course, $i, "COURSE_TITLE") ;
        $query_courseActivation = "SELECT * FROM ML_CourseActivation WHERE CID='".$each_cid."' ; ";
        $result_activation = mysql_query($query_courseActivation);
        $activation = mysql_result($result_activation, 0, "ACTIVATION");


        if($activation == 'A') {

        ?>
            <li><a href="courseList.php?ULANGUAGE=<?=$input_language?>" target="_top"><?=$course_title2?></a>
                <ul>
                <?
                $query_courseunit2 = "SELECT * FROM ML_CourseUnit, ML_Unit ".
                                            "WHERE ML_CourseUnit.UNIT_ID = ML_Unit.UNIT_ID ".
                                            "AND ML_CourseUnit.CID='".$each_cid."' ".
                                            "ORDER BY ML_Unit.UNIT_ORDER; ";
                $result_courseunit2 = mysql_query($query_courseunit2);
                $num_courseunit2  = mysql_num_rows($result_courseunit2);

                for ( $j=0 ; $j < $num_courseunit2 ; $j++)
                {
                        $each_uid = mysql_result($result_courseunit2, $j, "UNIT_ID") ;

                        $query_unit2 = "SELECT * FROM ML_Unit WHERE UNIT_ID='".$each_uid."'; ";

                        $result_unit2 = mysql_query($query_unit2);
                        $unit_title2 = trim(mysql_result($result_unit2, 0, "UNIT_TITLE") );
                        ?>
                <li><a href="unitList.php?ULANGUAGE=<?=$input_language?>&UNIT_ID=<?=$each_uid?>" target="_top"><?=$unit_title2?></a>
                    <ul>
                        <?
                        $query_unitsong = "SELECT * FROM ML_Song WHERE SID LIKE '".$each_uid."_%'; ";
                        $result_unitsong = mysql_query($query_unitsong);
                        $num_unitsong  = mysql_num_rows($result_unitsong);



                         for ( $k=0 ; $k < $num_unitsong ; $k++)
                        {
                                $each_song_title = mysql_result($result_unitsong, $k, "SONG_TITLE") ;
                                $each_sid = mysql_result($result_unitsong, $k, "SID") ;
                        ?>
                        <li><a href="songIntro.php?ULANGUAGE=<?=$input_language?>&SID=<?=$each_sid?>" target="_top"><?=$each_song_title?></a></li>
                        <?}?>
                    </ul>

                </li>
                <?}}?>
                </ul>
           </li>

    <?}?>
   </ul> 
  </li>




<?}?>

        
</ul>

 </body>

</html>
