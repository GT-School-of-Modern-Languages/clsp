<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"];
$lid = strtoupper(substr($input_language, 0, 3));
$course_title = $_REQUEST["COURSE_TITLE"];

$strDate_S = $_REQUEST["DATE_START"];
$strDate_E = $_REQUEST["DATE_END"];

if ( $course_title != "" ) 
{
	$date_start = ($strDate_S != "") ? substr($strDate_S, 6, 4). "-".substr($strDate_S, 0, 2)."-".substr($strDate_S, 3, 2) : "9999-12-31";
	$date_end = ($strDate_E != "" ) ? substr($strDate_E, 6, 4). "-".substr($strDate_E, 0, 2)."-".substr($strDate_E, 3, 2) : "9999-12-31";

	$lid = strtoupper(substr($input_language, 0, 3));

	$query_addCourse = "INSERT INTO ML_Course VALUES ('','".addslashes($course_title)."','".$lid."');" ;
	$result_addCourse = mysql_query($query_addCourse);

	$query_thisCID = "SELECT * FROM ML_Course ORDER BY CID DESC"; 
	$result_thisCID = mysql_query($query_thisCID);
	$cid = mysql_result($result_thisCID, 0, "CID") ;	

	//$query_addAccess = "INSERT INTO ML_CourseAccess VALUES ('','','".$cid."','".$date_start."','".$date_end."');" ;
	//$result_addAccess = mysql_query($query_addAccess);
	//echo $query_addAccess;

	$query_addModuleTitleForCourse = "INSERT INTO ML_ModuleTitle VALUES ('".$lid."', '".$cid."', '', '', '', '', '', '');" ;
	$result_addModuleTitleForCourse = mysql_query($query_addModuleTitleForCourse);

	$query_deactivate = "INSERT INTO ML_CourseActivation VALUES ('".$cid."', 'D'); ";
	$result_deactivate = mysql_query($query_deactivate);

}
header('Location: _admCourse.php?language='.$input_language); 
?>