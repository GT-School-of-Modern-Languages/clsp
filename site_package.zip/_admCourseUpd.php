<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"] ;
$course_title = $_REQUEST["COURSE_TITLE"];
$new_activation = $_REQUEST["NEW_ACT"];


if($new_activation == 'A' || $new_activation == 'D') {
	$query_updActivation = "UPDATE ML_CourseActivation SET ACTIVATION='".$new_activation."' WHERE CID='".$cid."'; ";
	$result_updActivation = mysql_query($query_updActivation);
}
else {
	$query_updCourseTitle = "UPDATE ML_Course SET COURSE_TITLE='".$course_title."' WHERE CID='".$cid."'; ";
	$result_updCourseTitle = mysql_query($query_updCourseTitle);
}

header('Location: _admCourse.php?language='.$input_language.'#tr_'.$cid); 


/*
if ( strpos($date_start, "/") == 0 && strpos($date_end, "/") == 0 )
{
	$date_start = ($date_start != "") ? $date_start : "9999-12-31";
	$date_end = ($date_end != "" ) ? $date_end : "9999-12-31";
}else{
	$date_start = ($date_start != "") ? substr($date_start, 6, 4). "-".substr($date_start, 0, 2)."-".substr($date_start, 3, 2) : "9999-12-31";
	$date_end = ($date_end != "" ) ? substr($date_end, 6, 4). "-".substr($date_end, 0, 2)."-".substr($date_end, 3, 2) : "9999-12-31";	
}

// ----------------------------------------------------------- update info ------------------------------

$query_updCourse = "UPDATE ML_Course SET COURSE_TITLE='".addslashes($course_title)."' ".								
										" WHERE CID='".$cid."' ;";
$result_updCourse = mysql_query($query_updCourse);


//-- update course access
	$query_updCourseAccess = "UPDATE ML_CourseAccess SET DATE_START='".$date_start."', DATE_END='".$date_end."' ".								
										" WHERE CID='".$cid."' ;";
	$result_updCourseAccess = mysql_query($query_updCourseAccess);
echo $query_updCourseAccess;
//-- update unit access date
$query_queCourseAccess = "SELECT * FROM ML_CourseAccess, ML_CourseUnit WHERE ".
											"ML_CourseAccess.CID = ML_CourseUnit.CID ".
											"AND ML_CourseAccess.CID = '".$cid."'; ";
$result_queCourseAccess = mysql_query($query_queCourseAccess);
$num_thisCourse= mysql_num_rows($result_queCourseAccess);

echo $query_queCourseAccess."</br>";


for ( $i=0 ; $i < $num_thisCourse ; $i++)
{
	$unit_id = mysql_result($result_queCourseAccess, $i, "UNIT_ID");	


	$query_updUnitAccess = "UPDATE ML_UnitAccess SET DATE_START='".$date_start."', DATE_END='".$date_end."' ".								
										" WHERE UNIT_ID='".$unit_id."' ;";
	$result_updUnitAccess = mysql_query($query_updUnitAccess);

	echo $query_updUnitAccess."</br>";
}

*/
?>