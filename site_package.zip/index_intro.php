<?php

require ("config.php");
$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
$query_title= "SELECT * FROM Admin_Edit WHERE id='index_title'";
$result_title=mysql_query($query_title);
$index_title= mysql_result($result_title, 0, "text");

$query_subtitle1= "SELECT * FROM Admin_Edit WHERE id='index_subtitle1'";
$result_subtitle1=mysql_query($query_subtitle1);
$index_subtitle1= mysql_result($result_subtitle1, 0, "text");

$query_subtitle2= "SELECT * FROM Admin_Edit WHERE id='index_subtitle2'";
$result_subtitle2=mysql_query($query_subtitle2);
$index_subtitle2= mysql_result($result_subtitle2, 0, "text");

$query_mainTitle = "SELECT * FROM ML_UI WHERE NAME='MAIN_TITLE'";
$result_mainTitle = mysql_query($query_mainTitle);
$main_title = mysql_result($result_mainTitle, 0, "TEXT");

$query_contents = "SELECT * FROM ML_UI WHERE NAME='INTRO_CONTENTS'";
$result_contents = mysql_query($query_contents);
$intro_contents = mysql_result($result_contents, 0, "TEXT");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Georgia Tech Critical Language Song Project</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />

</head>
<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="250" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
    	     <img src="images/main_logo.png" width="250" height="120" hspace="10" vspace="10"></a></br>
	  </td>
    <td align="left" valign="center" bgcolor="#<?=$color1?>">
    	<p align="center"><font size="10"><b><?=$main_title ?></b></font></p>
    </td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="800"><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php

$query = "select * from ML_Lang ORDER BY LANGUAGE;" ;
$result = mysql_query($query);

if ( $result != FALSE)
{
	
	$num_rows = mysql_num_rows($result);
	$num_field = mysql_num_fields($result);
	
	if ( $num_rows == 0 )
	{
		print "No results. </br>";
	}
	else
	{
		for ( $i = 0; $i < $num_rows ; $i++ ){
		$language = mysql_result($result, $i);
?>
      <tr>
        <td><div class="leftMenu"><a href="login.php?ULANGUAGE=<?=$language ?>"><span class="menu_head"><?=$language?>&nbsp;</span></a></div></td>
      </tr>
<?php
		}
	}
}
?>
    </table>
	</td>
    <td align="center" valign="top">
	    <table width="85%" border="0" cellspacing="0" cellpadding="10">
	      <tr>
	      	<body>
    	    <?=$intro_contents?>
	    	</body>
		  </tr>           
    	</table>
    </td>
  	</tr>
  <tr height="25" bgcolor="#<?=$color1?>">
    <td align="center" valign="middle">&nbsp;</td>
    <td align="right" valign="middle" >
    <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
    </table>
    </td>
  </tr> 
</table>
</body>
</html>
