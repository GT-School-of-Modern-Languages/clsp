<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>_admUploadMedia.php</title>
<link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>
<script language="JavaScript" type="text/javascript" src="script/ml.js"></script>
<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$input_language = $_REQUEST["ULANGUAGE"] ;
$err = $_REQUEST["ERR"] ;
$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");
?>
<script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>">
</td>
    <td align="center" valign="center" bgcolor="#<?=$color1?>">
</td>
  </tr>
  <tr>
    <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
    <p>&nbsp;</p><p>&nbsp;</p>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><div class="leftMenu"><a href="_admCourse.php?language=<?=$input_language ?>"><span class="menu_head">Course Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admUnitList.php?language=<?=$input_language ?>"><span class="menu_head">Unit Info</span></a></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><span class="menu_select">Media Files</span></div></td>
      </tr>
      <tr>
        <td><div class="leftMenu"><a href="_admModuleList.php?language=<?=$input_language ?>"><span class="menu_head">Module Management</span></a></div></td>
      </tr>   
      <tr>
        <td><div class="leftMenu"><a href="_admAccountList.php?language=<?=$input_language ?>"><span class="menu_head">Account Management</span></a></div></td>
      </tr>         
    </table>    
</td>
    <td align="left" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">   
	<tr>
  	<td align="center" valign="top">
	  <table width="85%" border="0" cellspacing="0" cellpadding="3">
        <tr>
        <td><div class="path">
        <a href="_admMain.php">Designer's Home</a> >> <a href="_admMediaList.php?language=<?=$input_language ?>">Media List in <?=$input_language?></a> >> Update Media file</div></td>
    	</tr>	  
	    <tr>
   		<td><p>&nbsp;</p><p>&nbsp;</p>
   	   	</td>
   	   	</tr>
 	   	<tr>
       	<td align="center" valign="top">
			<font size="2">Upload Failed. </br>Fail cod: <?=$err ?></font></br></br>
			  <input type="button" value="Back to Previous Page and Upload Again." style="cursor: pointer; background: #FFFFFF; border-style: solid; border-bottom-width: 2px; border-top-width: 0px; border-right-width: 0px; border-left-width: 0px; border-color: #<?=$color2?>; color: #<?=$color2?>; font-size: 12pt; font-family: Verdana;" onclick="history.back();">  
			
    	</td>
  		</tr>
	    <tr>
   		<td align="center" valign="top"><p></br>and also </br></p>
   	   	</td>
   	   	</tr>
 	   	<tr>
       	<td align="center" valign="top">
			<font size="2">contact system assistant: <a href="mailto:sj.today@gatech.edu? » &subject=GTML_Song_Project: Media Upload Error">Szu-Chia Lu</a>
			
    	</td>
  		</tr>  		
	</table>
	</td>
</tr>
    </table></td>
  </tr>
  <tr>
    <td  height="25" colspan="2" align="right" valign="middle" bgcolor="#<?=$color1?>"><span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
  </tr>
</table>
</body>
</html>