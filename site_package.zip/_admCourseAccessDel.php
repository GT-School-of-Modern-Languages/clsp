<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}
$cpid = $_REQUEST["CPID"];
$cid = $_REQUEST["CID"];

if ( $cpid == "" || $cid == "" ){
	header('Location:./admin/'); 
}

$query_courseAccess="DELETE FROM ML_CourseAccess WHERE CPID=" . $cpid . " AND CID=" . $cid;
$result_courseAccess=mysql_query($query_courseAccess);

echo $query_courseAccess;

header('Location: popup-access.php?acid='. $cpid);


?>