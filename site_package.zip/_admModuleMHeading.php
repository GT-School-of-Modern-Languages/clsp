<?php
require ("config.php");

$link = connectDB();

if (!$link) {
	echo "database connection fail!";
	exit(-1);
}


$input_language = $_REQUEST["ULANGUAGE"];
$cid = $_REQUEST["CID"];
$mhid = $_REQUEST["MAIN_HID"] ;
$thid = $_REQUEST["TARGET_HID"] ;
$sid = $_REQUEST["SONG_ID"] ;
$module = $_REQUEST["MODULE"];

$submitLocation = "";
$column_name = "";
$column_requested = "";

switch($module)	
{
	case "QU":		 
		$submitLocation = "_admEditHeadingQ"; 
		break;
	case "LT": 
		$submitLocation = "_admEditHeadingL"; 
		break;
	case "GE":	
		$submitLocation = "_admEditHeadingG"; 
		break;
	case "DW":
		$submitLocation = "_admEditHeadingW"; 
		break;
}	


// ----------------------------------------------------------- update order info ------------------------------

//select the order of the target question
$query_mainOrder = "SELECT H_ORDER FROM ML_Heading WHERE HID='".$mhid."' ;";
$result_mainOrder = mysql_query($query_mainOrder);
$mainOrder= mysql_result($result_mainOrder, 0, "H_ORDER"); 

$query_targetOrder = "SELECT H_ORDER FROM ML_Heading WHERE HID='".$thid."' ;";
$result_targetOrder = mysql_query($query_targetOrder);
$targetOrder= mysql_result($result_targetOrder, 0, "H_ORDER"); 

$query_updOrder_main= "UPDATE ML_Heading SET H_ORDER='".$targetOrder."' WHERE HID='".$mhid."' ;";
$result_updOrder_main = mysql_query($query_updOrder_main) or die(mysql_error()); 

$query_updOrder_target= "UPDATE ML_Heading SET H_ORDER='".$mainOrder."' WHERE HID='".$thid."' ;";
$result_updOrder_target = mysql_query($query_updOrder_target) or die(mysql_error()); 

//echo $query_updOrder_main ."</br>" . $result_updOrder_target ;
header('Location:'.$submitLocation.'.php?ULANGUAGE='.$input_language.'&CID='.$cid.'&SONG_ID='.$sid); 
?>