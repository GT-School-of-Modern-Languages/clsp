<?php
require ("config.php");
$link = connectDB();
if (!$link) {
	echo "database connection fail!";
	exit(-1);
}

$succ = -1;
if(isset($_REQUEST['succ'])) {
  $succ = $_REQUEST['succ'];
}

$colorquery="SELECT * FROM ML_Color WHERE id=1";
$result_color=mysql_query($colorquery);
$color1=mysql_result($result_color, 0, "color1");
$color2=mysql_result($result_color, 0, "color2");

$query_ui_loc = "SELECT * FROM ML_UI WHERE NAME='UI_LOCATION'";
$result_ui_loc = mysql_query($query_ui_loc);
$ui_location = mysql_result($result_ui_loc, 0, "TEXT");

$query_db_loc = "SELECT * FROM ML_UI WHERE NAME='DB_LOCATION'";
$result_db_loc = mysql_query($query_db_loc);
$db_location = mysql_result($result_db_loc, 0, "TEXT");

function ireadDirs($where, $bkdir_which, $thisYear, $thisMonth) {
  $dirHandle = opendir($where);
  while($file = readdir($dirHandle)){
    if(is_dir($where . $file) && $file != '.' && $file != '..'){
      ireadDirs($where . $file, $bkdir_which, $thisYear, $thisMonth);
    }
    else{
      if( substr($file, 0, 1) != "." && substr($file, 17, 4) == $thisYear && intval(substr($file, 13, 2)) == $thisMonth ){
        $strLen = strlen($file);
        if($bkdir_which == "UI" && substr($file, $strLen-3, $strLen) == 'zip')
          echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"$where/$file\">$file</a></td></tr>";
        else if($bkdir_which == "DB" && substr($file, $strLen-3, $strLen) == 'sql')
          echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"$where/$file\">$file</a></td></tr>";
      }       
    }
  } 
  closedir($dirHandle);
}

?>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Critical Languages Song Project</title>
  <link rel="stylesheet" type="text/css" href="css/style.php" />
</head>

<body>
  <script language="JavaScript" type="text/javascript" src="script/wz_tooltip.js"></script>

  <table width="100%" border="0" cellpadding="0" cellspacing="0" >
    <tr>
      <td width="300" height="120" align="center" valign="top" bgcolor="#<?=$color2?>"></td>
      <td align="center" valign="center" bgcolor="#<?=$color1?>">
        <a href="http://mlg-grant.iac.gatech.edu/">
          <font size="10" color="black"> </font>
        </a>
      </td>
    </tr>
    <tr>
      <td align="right" valign="top" bgcolor="#<?=$color1?>" height="720">
        <p>&nbsp;</p><p>&nbsp;</p>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><div class="leftMenu"><a href="_admMain.php"><span class="menu_head">Admin Main Page</span></a></div></td>
          </tr> 
          <tr>
            <td><div class="leftMenu"><a href="index.php"><span class="menu_head">Students Main Page</span></a></div></td>
          </tr>      
          <tr>
             <td><div class="leftMenu"><a href="_admFront.php"><span class="menu_head">Modify Front Page</span></a></div></td>
          </tr>           
          <tr>
            <td><div class="leftMenu"><a href="_admChangeColor.php"><span class="menu_head">Change Theme</span></a></div></td>
          </tr>    
          <tr>
            <td><div class="leftMenu"><span class="menu_select">Back Up UI/DB</span></div></td>
          </tr>              
        </table>
      </td>
      <td align="center" valign="top"><p>&nbsp;</p><p>&nbsp;</p>
        <form name="COURSE" method="post" action="_admEditBackup.php">

          <table width="650" border="0" cellspacing="3" cellpadding="5">
            <tr>
              <td>UI Backup Location:  
                <input name="UI_LOCATION" value="<?=$ui_location?>" type="text" style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="50" maxlength="100">
                &nbsp;
              </td> 
            </tr> 
            <tr>
              <td>DB Backup Location:  <input name="DB_LOCATION" value="<?=$db_location?>" type="text" style="color: #000000; font-size: 12pt; font-family: Verdana; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; border-bottom-style: solid; border-bottom-width: 1px; border-color: #<?=$color2?>; background-color: #FFFFFF;" size="50" maxlength="100">
              </td> 
            </tr> 
            <tr>
              <td>
                <input type="submit" value="Back Up" style="background: #<?=$color2?>; border-width: 1px; color: #FFFFFF; font-size: 8pt; font-family: Verdana; cursor: pointer; ">
                &nbsp;
                  <?
                    if($succ == '3') {
                      echo '<font style="color: #0066FF;">Both Backup Successfully Completed!</font>';
                    } else if($succ == '2') {
                      echo '<font style="color: #FF0000;">DB Backup Failed!</font>';
                    } else if($succ == '1') {
                      echo '<font style="color: #FF0000;">UI Backup Failed!</font>';
                    } else if($succ == '0') {
                      echo '<font style="color: #FF0000;">Both Backup Failed!</font>';
                    } else if($succ == '-2') {
                      echo '<font style="color: #FF0000;">Missing \' / \' at the end</font>';
                    } else if($succ == '-3') {
                      echo '<font style="color: #FF0000;">Missing \' / \' at the end</font>';
                    }
                  ?>
              </td>
            </tr>

          </table>
        </form>



<?php

//-- basic director set up
$bkdir_path = "../backups/";

$bkdir_which = "UI";
if(isset($_REQUEST['WHICH'])) {
  $bkdir_which = $_REQUEST['WHICH'];
}
 
$where = $bkdir_path;

//-- date operation
$currenrYear = date("Y");
$currenrMonth = intval( date("m") );
$arrMonth = array("January","Febuary","March","April","May","June","July","August","September","October","November","December");
$monthCount = 12;

$thisYear = $currenrYear ;
$thisMonth = $currenrMonth ;

$str_SITE = ( $bkdir_which == "UI" ) ? 
"<font class=\"diron\">&nbsp;&nbsp;INTERFACE&nbsp;&nbsp;</font>" : "<font class=\"diroff\"><a href=\"_admBackupFiles.php?succ=-1&WHICH=UI\">&nbsp;&nbsp;INTERFACE&nbsp;&nbsp;</a></font>" ;
$str_DB = ( $bkdir_which == "DB" ) ? 
"<font class=\"diron\">&nbsp;&nbsp;DATABASE&nbsp;&nbsp;</font>" : "<font class=\"diroff\"><a href=\"_admBackupFiles.php?succ=-1&WHICH=DB\">&nbsp;&nbsp;DATABASE&nbsp;&nbsp;</a></font>" ;

echo "<table class=\"bkadm\" border=\"1\">";
echo "<tr><th><font size=\"4\">Current Backup Type: ".$str_SITE." &nbsp;&nbsp;". $str_DB ."</font></p></th></tr>";

  for ( $i=1 ; $i <= $monthCount ; $i++)
  {       
    echo "<tr><td>". $thisYear." ".$arrMonth[($thisMonth-1)] ."</td></tr>";

    ireadDirs($where, $bkdir_which, $thisYear, $thisMonth);

    $thisMonth = ( ( $currenrMonth - $i ) < 1 ) ? 12 + ( $currenrMonth - $i) : $currenrMonth - $i;
    $thisYear = ( ( $currenrMonth - $i ) < 1 ) ? $currenrYear - 1 : $currenrYear;
  }
echo "</table>";

?>

      </td>
    </tr>
    <tr height="25" bgcolor="#<?=$color1?>">
      <td align="center" valign="middle">&nbsp;</td>
      <td align="right" valign="middle" >
      <span class="rights">Interface Copyright &copy; Georgia Tech :: Ivan Allen College</span></td>
    </tr>  
  </table>


</body>
</html>